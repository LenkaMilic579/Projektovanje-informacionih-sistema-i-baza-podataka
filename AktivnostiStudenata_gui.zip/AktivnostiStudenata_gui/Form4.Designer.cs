﻿namespace AktivnostiStudenata_gui
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.showInfoButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet2 = new AktivnostiStudenata_gui.AplikacijaDataSet2();
            this.addStudentButton = new System.Windows.Forms.Button();
            this.addBasicButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.acceptInfoButton = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.acceptStructureButton = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.addColonButton = new System.Windows.Forms.Button();
            this.addStructureButton = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.createTableButton = new System.Windows.Forms.Button();
            this.sqlUpit = new System.Windows.Forms.RichTextBox();
            this.ImePredmeta = new System.Windows.Forms.Label();
            this.basic = new System.Windows.Forms.GroupBox();
            this.takeMeBackButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.changeStructureButton = new System.Windows.Forms.Button();
            this.predmetTableAdapter1 = new AktivnostiStudenata_gui.AplikacijaDataSet2TableAdapters.PredmetTableAdapter();
            this.grades = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.basic.SuspendLayout();
            this.SuspendLayout();
            // 
            // showInfoButton
            // 
            this.showInfoButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showInfoButton.Location = new System.Drawing.Point(12, 108);
            this.showInfoButton.Name = "showInfoButton";
            this.showInfoButton.Size = new System.Drawing.Size(130, 37);
            this.showInfoButton.TabIndex = 0;
            this.showInfoButton.Text = "Prikazi informacije o predmetu";
            this.showInfoButton.UseVisualStyleBackColor = true;
            this.showInfoButton.Click += new System.EventHandler(this.showInfoButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28});
            this.dataGridView1.DataSource = this.predmetBindingSource1;
            this.dataGridView1.GridColor = System.Drawing.Color.LightGray;
            this.dataGridView1.Location = new System.Drawing.Point(183, 56);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(790, 71);
            this.dataGridView1.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn21.DataPropertyName = "ime";
            this.dataGridViewTextBoxColumn21.HeaderText = "Ime Predmeta";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.Width = 89;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn22.DataPropertyName = "ESP";
            this.dataGridViewTextBoxColumn22.HeaderText = "ESP";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.Width = 53;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn23.DataPropertyName = "status";
            this.dataGridViewTextBoxColumn23.HeaderText = "Status";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Width = 62;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn24.DataPropertyName = "semestar";
            this.dataGridViewTextBoxColumn24.HeaderText = "Semestar";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Width = 76;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn25.DataPropertyName = "opis";
            this.dataGridViewTextBoxColumn25.HeaderText = "Opis";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.Width = 53;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn26.DataPropertyName = "uslov";
            this.dataGridViewTextBoxColumn26.HeaderText = "Uslov za predmet";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.Width = 70;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "teorijskaNastava";
            this.dataGridViewTextBoxColumn27.HeaderText = "Broj casova teorijske nastave";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "prakticnaNastava";
            this.dataGridViewTextBoxColumn28.HeaderText = "Broj casova prakticne nastave";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // predmetBindingSource1
            // 
            this.predmetBindingSource1.DataMember = "Predmet";
            this.predmetBindingSource1.DataSource = this.aplikacijaDataSet2;
            // 
            // aplikacijaDataSet2
            // 
            this.aplikacijaDataSet2.DataSetName = "AplikacijaDataSet2";
            this.aplikacijaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addStudentButton
            // 
            this.addStudentButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addStudentButton.Location = new System.Drawing.Point(12, 194);
            this.addStudentButton.Name = "addStudentButton";
            this.addStudentButton.Size = new System.Drawing.Size(130, 37);
            this.addStudentButton.TabIndex = 2;
            this.addStudentButton.Text = "Dodaj sudente";
            this.addStudentButton.UseVisualStyleBackColor = true;
            this.addStudentButton.Click += new System.EventHandler(this.addStudentButton_Click);
            // 
            // addBasicButton
            // 
            this.addBasicButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBasicButton.Location = new System.Drawing.Point(12, 50);
            this.addBasicButton.Name = "addBasicButton";
            this.addBasicButton.Size = new System.Drawing.Size(130, 52);
            this.addBasicButton.TabIndex = 3;
            this.addBasicButton.Text = "Unesi osnovne informacije o predmetu";
            this.addBasicButton.UseVisualStyleBackColor = true;
            this.addBasicButton.Click += new System.EventHandler(this.addBasicButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ukupno ESP bodova za predmet:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "status predmeta:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.acceptInfoButton);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.richTextBox2);
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(183, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 252);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Osnovne informacije :";
            // 
            // acceptInfoButton
            // 
            this.acceptInfoButton.Location = new System.Drawing.Point(709, 223);
            this.acceptInfoButton.Name = "acceptInfoButton";
            this.acceptInfoButton.Size = new System.Drawing.Size(75, 23);
            this.acceptInfoButton.TabIndex = 13;
            this.acceptInfoButton.Text = "Prihvati";
            this.acceptInfoButton.UseVisualStyleBackColor = true;
            this.acceptInfoButton.Click += new System.EventHandler(this.acceptInfoButton_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(263, 134);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 21);
            this.textBox4.TabIndex = 24;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(263, 80);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 23;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(533, 141);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(244, 55);
            this.richTextBox2.TabIndex = 22;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(533, 33);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(244, 89);
            this.richTextBox1.TabIndex = 21;
            this.richTextBox1.Text = "";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(263, 52);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 20;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(263, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 19;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(263, 161);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 21);
            this.textBox5.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(185, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "broj casova prakticne nastave:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(416, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "uslov za predmet:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "semestar na kome se predmet slusa:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "broj casova teorijske nastave:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(416, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "opis predmeta:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView2);
            this.groupBox2.Controls.Add(this.acceptStructureButton);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.addColonButton);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(183, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(598, 248);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kreiranje strukture predmeta";
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView2.Location = new System.Drawing.Point(0, 31);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(584, 71);
            this.dataGridView2.TabIndex = 4;
            // 
            // acceptStructureButton
            // 
            this.acceptStructureButton.Location = new System.Drawing.Point(517, 219);
            this.acceptStructureButton.Name = "acceptStructureButton";
            this.acceptStructureButton.Size = new System.Drawing.Size(75, 23);
            this.acceptStructureButton.TabIndex = 3;
            this.acceptStructureButton.Text = "Prihvati";
            this.acceptStructureButton.UseVisualStyleBackColor = true;
            this.acceptStructureButton.Click += new System.EventHandler(this.acceptStructureButton_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(34, 161);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(133, 21);
            this.textBox6.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Ime kolone:";
            // 
            // addColonButton
            // 
            this.addColonButton.Location = new System.Drawing.Point(194, 159);
            this.addColonButton.Name = "addColonButton";
            this.addColonButton.Size = new System.Drawing.Size(96, 23);
            this.addColonButton.TabIndex = 0;
            this.addColonButton.Text = "Dodaj kolonu";
            this.addColonButton.UseVisualStyleBackColor = true;
            this.addColonButton.Click += new System.EventHandler(this.addColonButton_Click);
            // 
            // addStructureButton
            // 
            this.addStructureButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addStructureButton.Location = new System.Drawing.Point(12, 151);
            this.addStructureButton.Name = "addStructureButton";
            this.addStructureButton.Size = new System.Drawing.Size(130, 37);
            this.addStructureButton.TabIndex = 13;
            this.addStructureButton.Text = "Definisi strukturu predmeta";
            this.addStructureButton.UseVisualStyleBackColor = true;
            this.addStructureButton.Click += new System.EventHandler(this.addStructureButton_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // createTableButton
            // 
            this.createTableButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createTableButton.Location = new System.Drawing.Point(446, 311);
            this.createTableButton.Name = "createTableButton";
            this.createTableButton.Size = new System.Drawing.Size(98, 23);
            this.createTableButton.TabIndex = 16;
            this.createTableButton.Text = "Kreiraj tabelu";
            this.createTableButton.UseVisualStyleBackColor = true;
            this.createTableButton.Click += new System.EventHandler(this.createTableButton_Click);
            // 
            // sqlUpit
            // 
            this.sqlUpit.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqlUpit.Location = new System.Drawing.Point(304, 24);
            this.sqlUpit.Name = "sqlUpit";
            this.sqlUpit.Size = new System.Drawing.Size(385, 284);
            this.sqlUpit.TabIndex = 17;
            this.sqlUpit.Text = "";
            // 
            // ImePredmeta
            // 
            this.ImePredmeta.AutoSize = true;
            this.ImePredmeta.Font = new System.Drawing.Font("Verdana", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImePredmeta.ForeColor = System.Drawing.Color.Navy;
            this.ImePredmeta.Location = new System.Drawing.Point(471, 30);
            this.ImePredmeta.Name = "ImePredmeta";
            this.ImePredmeta.Size = new System.Drawing.Size(54, 14);
            this.ImePredmeta.TabIndex = 18;
            this.ImePredmeta.Text = "default";
            // 
            // basic
            // 
            this.basic.Controls.Add(this.takeMeBackButton);
            this.basic.Controls.Add(this.logOutButton);
            this.basic.Controls.Add(this.ImePredmeta);
            this.basic.Location = new System.Drawing.Point(1, 330);
            this.basic.Name = "basic";
            this.basic.Size = new System.Drawing.Size(992, 69);
            this.basic.TabIndex = 19;
            this.basic.TabStop = false;
            // 
            // takeMeBackButton
            // 
            this.takeMeBackButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.takeMeBackButton.Location = new System.Drawing.Point(871, 11);
            this.takeMeBackButton.Name = "takeMeBackButton";
            this.takeMeBackButton.Size = new System.Drawing.Size(115, 23);
            this.takeMeBackButton.TabIndex = 21;
            this.takeMeBackButton.Text = "Prethodna strana";
            this.takeMeBackButton.UseVisualStyleBackColor = true;
            this.takeMeBackButton.Click += new System.EventHandler(this.takeMeBackButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutButton.Location = new System.Drawing.Point(871, 40);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(115, 23);
            this.logOutButton.TabIndex = 21;
            this.logOutButton.Text = "Izlogujte se";
            this.logOutButton.UseVisualStyleBackColor = true;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // changeStructureButton
            // 
            this.changeStructureButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeStructureButton.Location = new System.Drawing.Point(12, 151);
            this.changeStructureButton.Name = "changeStructureButton";
            this.changeStructureButton.Size = new System.Drawing.Size(130, 37);
            this.changeStructureButton.TabIndex = 20;
            this.changeStructureButton.Text = "Resetuj strukturu predmeta";
            this.changeStructureButton.UseVisualStyleBackColor = true;
            this.changeStructureButton.Click += new System.EventHandler(this.changeStructureButton_Click);
            // 
            // predmetTableAdapter1
            // 
            this.predmetTableAdapter1.ClearBeforeFill = true;
            // 
            // grades
            // 
            this.grades.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grades.ForeColor = System.Drawing.Color.DarkBlue;
            this.grades.Location = new System.Drawing.Point(12, 287);
            this.grades.Name = "grades";
            this.grades.Size = new System.Drawing.Size(130, 37);
            this.grades.TabIndex = 21;
            this.grades.Text = "Ocenjivanje";
            this.grades.UseVisualStyleBackColor = true;
            this.grades.Click += new System.EventHandler(this.grades_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(991, 399);
            this.ControlBox = false;
            this.Controls.Add(this.grades);
            this.Controls.Add(this.changeStructureButton);
            this.Controls.Add(this.sqlUpit);
            this.Controls.Add(this.createTableButton);
            this.Controls.Add(this.basic);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.addStructureButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.addBasicButton);
            this.Controls.Add(this.addStudentButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.showInfoButton);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Podesavanje predmeta";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.basic.ResumeLayout(false);
            this.basic.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showInfoButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPredmetaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn semestarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uslovDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teorijskaNastavaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProfesoraDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button addStudentButton;
        private System.Windows.Forms.Button addBasicButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button acceptInfoButton;
        
     
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn prakticnaNastavaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Button addStructureButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button acceptStructureButton;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button addColonButton;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button createTableButton;
       
        
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
       
        
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.RichTextBox sqlUpit;
        private System.Windows.Forms.Label ImePredmeta;
        private System.Windows.Forms.GroupBox basic;
        private System.Windows.Forms.Button changeStructureButton;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.Button takeMeBackButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private AplikacijaDataSet2 aplikacijaDataSet2;
        private System.Windows.Forms.BindingSource predmetBindingSource1;
        private AplikacijaDataSet2TableAdapters.PredmetTableAdapter predmetTableAdapter1;
        private System.Windows.Forms.Button grades;
    }
}