﻿namespace AktivnostiStudenata_gui
{
    partial class Form3_
    {


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.classAddButton = new System.Windows.Forms.Button();
            this.classDeleteButton = new System.Windows.Forms.Button();
            this.classAddBox = new System.Windows.Forms.GroupBox();
            this.classAcceptButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dodajAsistentaBox = new System.Windows.Forms.GroupBox();
            this.acceptAssistentButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.userNameBox = new System.Windows.Forms.TextBox();
            this.imePredmetaBox = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.imeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet3 = new AktivnostiStudenata_gui.AplikacijaDataSet3();
            this.classDeleteBox = new System.Windows.Forms.GroupBox();
            this.classAcceptButton2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.unregisterMeBox = new System.Windows.Forms.GroupBox();
            this.unregisterButton2 = new System.Windows.Forms.Button();
            this.imePredmetaBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.showClassButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.logOutButton = new System.Windows.Forms.Button();
            this.takeMeBackButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.imeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet = new AktivnostiStudenata_gui.AplikacijaDataSet();
            this.predmetTableAdapter = new AktivnostiStudenata_gui.AplikacijaDataSetTableAdapters.PredmetTableAdapter();
            this.changePassword = new System.Windows.Forms.Button();
            this.changePasswordBox = new System.Windows.Forms.GroupBox();
            this.newPassword2 = new System.Windows.Forms.TextBox();
            this.newPassword1 = new System.Windows.Forms.TextBox();
            this.newPasswordLabel2 = new System.Windows.Forms.Label();
            this.newPasswordLabel1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.currentPassword = new System.Windows.Forms.TextBox();
            this.currentPasswordLabel = new System.Windows.Forms.Label();
            this.welcomeLablel = new System.Windows.Forms.Label();
            this.predmetTableAdapter1 = new AktivnostiStudenata_gui.AplikacijaDataSet3TableAdapters.PredmetTableAdapter();
            this.addAssistentButton = new System.Windows.Forms.Button();
            this.predmetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet4 = new AktivnostiStudenata_gui.AplikacijaDataSet4();
            this.predmetTableAdapter2 = new AktivnostiStudenata_gui.AplikacijaDataSet4TableAdapters.PredmetTableAdapter();
            this.UnregisterButton = new System.Windows.Forms.Button();
            this.deleteAssistentButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.OdjaviAsistentaButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.imeAsistenta2Box = new System.Windows.Forms.TextBox();
            this.imePredmeta2Box = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet5 = new AktivnostiStudenata_gui.AplikacijaDataSet5();
            this.predmetTableAdapter3 = new AktivnostiStudenata_gui.AplikacijaDataSet5TableAdapters.PredmetTableAdapter();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.imeDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.aplikacijaDataSet6 = new AktivnostiStudenata_gui.AplikacijaDataSet6();
            this.predmetBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.predmetTableAdapter4 = new AktivnostiStudenata_gui.AplikacijaDataSet6TableAdapters.PredmetTableAdapter();
            this.classAddBox.SuspendLayout();
            this.dodajAsistentaBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet3)).BeginInit();
            this.classDeleteBox.SuspendLayout();
            this.unregisterMeBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet)).BeginInit();
            this.changePasswordBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet4)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet5)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // classAddButton
            // 
            this.classAddButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classAddButton.Location = new System.Drawing.Point(12, 62);
            this.classAddButton.Name = "classAddButton";
            this.classAddButton.Size = new System.Drawing.Size(124, 23);
            this.classAddButton.TabIndex = 0;
            this.classAddButton.Text = "Dodaj predmet";
            this.classAddButton.UseVisualStyleBackColor = true;
            this.classAddButton.Click += new System.EventHandler(this.classAddButton_Click);
            // 
            // classDeleteButton
            // 
            this.classDeleteButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classDeleteButton.Location = new System.Drawing.Point(12, 97);
            this.classDeleteButton.Name = "classDeleteButton";
            this.classDeleteButton.Size = new System.Drawing.Size(124, 23);
            this.classDeleteButton.TabIndex = 1;
            this.classDeleteButton.Text = "Obrisi predmet";
            this.classDeleteButton.UseVisualStyleBackColor = true;
            this.classDeleteButton.Click += new System.EventHandler(this.classDeleteButton_Click);
            // 
            // classAddBox
            // 
            this.classAddBox.Controls.Add(this.classAcceptButton);
            this.classAddBox.Controls.Add(this.textBox1);
            this.classAddBox.Controls.Add(this.label1);
            this.classAddBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classAddBox.Location = new System.Drawing.Point(183, 56);
            this.classAddBox.Name = "classAddBox";
            this.classAddBox.Size = new System.Drawing.Size(315, 99);
            this.classAddBox.TabIndex = 2;
            this.classAddBox.TabStop = false;
            this.classAddBox.Text = "Dodaj predmet";
            // 
            // classAcceptButton
            // 
            this.classAcceptButton.Location = new System.Drawing.Point(117, 70);
            this.classAcceptButton.Name = "classAcceptButton";
            this.classAcceptButton.Size = new System.Drawing.Size(75, 23);
            this.classAcceptButton.TabIndex = 3;
            this.classAcceptButton.Text = "Prihvati";
            this.classAcceptButton.UseVisualStyleBackColor = true;
            this.classAcceptButton.Click += new System.EventHandler(this.classAcceptButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(113, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 21);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime predmeta:";
            // 
            // dodajAsistentaBox
            // 
            this.dodajAsistentaBox.Controls.Add(this.acceptAssistentButton);
            this.dodajAsistentaBox.Controls.Add(this.label3);
            this.dodajAsistentaBox.Controls.Add(this.userNameBox);
            this.dodajAsistentaBox.Controls.Add(this.imePredmetaBox);
            this.dodajAsistentaBox.Controls.Add(this.dataGridView2);
            this.dodajAsistentaBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dodajAsistentaBox.Location = new System.Drawing.Point(183, 56);
            this.dodajAsistentaBox.Name = "dodajAsistentaBox";
            this.dodajAsistentaBox.Size = new System.Drawing.Size(437, 168);
            this.dodajAsistentaBox.TabIndex = 15;
            this.dodajAsistentaBox.TabStop = false;
            this.dodajAsistentaBox.Text = "Prijava novog asistenta";
            // 
            // acceptAssistentButton
            // 
            this.acceptAssistentButton.Location = new System.Drawing.Point(356, 142);
            this.acceptAssistentButton.Name = "acceptAssistentButton";
            this.acceptAssistentButton.Size = new System.Drawing.Size(75, 23);
            this.acceptAssistentButton.TabIndex = 4;
            this.acceptAssistentButton.Text = "Prihvati";
            this.acceptAssistentButton.UseVisualStyleBackColor = true;
            this.acceptAssistentButton.Click += new System.EventHandler(this.acceptAssistentButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Username";
            // 
            // userNameBox
            // 
            this.userNameBox.Location = new System.Drawing.Point(22, 107);
            this.userNameBox.Name = "userNameBox";
            this.userNameBox.Size = new System.Drawing.Size(125, 21);
            this.userNameBox.TabIndex = 2;
            // 
            // imePredmetaBox
            // 
            this.imePredmetaBox.Location = new System.Drawing.Point(175, 107);
            this.imePredmetaBox.Name = "imePredmetaBox";
            this.imePredmetaBox.Size = new System.Drawing.Size(256, 21);
            this.imePredmetaBox.TabIndex = 1;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.imeDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.predmetBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(175, 28);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(256, 73);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // imeDataGridViewTextBoxColumn1
            // 
            this.imeDataGridViewTextBoxColumn1.DataPropertyName = "ime";
            this.imeDataGridViewTextBoxColumn1.HeaderText = "ime";
            this.imeDataGridViewTextBoxColumn1.Name = "imeDataGridViewTextBoxColumn1";
            // 
            // predmetBindingSource1
            // 
            this.predmetBindingSource1.DataMember = "Predmet";
            this.predmetBindingSource1.DataSource = this.aplikacijaDataSet3;
            // 
            // aplikacijaDataSet3
            // 
            this.aplikacijaDataSet3.DataSetName = "AplikacijaDataSet3";
            this.aplikacijaDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // classDeleteBox
            // 
            this.classDeleteBox.Controls.Add(this.classAcceptButton2);
            this.classDeleteBox.Controls.Add(this.textBox2);
            this.classDeleteBox.Controls.Add(this.label2);
            this.classDeleteBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classDeleteBox.Location = new System.Drawing.Point(183, 56);
            this.classDeleteBox.Name = "classDeleteBox";
            this.classDeleteBox.Size = new System.Drawing.Size(315, 99);
            this.classDeleteBox.TabIndex = 3;
            this.classDeleteBox.TabStop = false;
            this.classDeleteBox.Text = "Obrisi predmet";
            // 
            // classAcceptButton2
            // 
            this.classAcceptButton2.Location = new System.Drawing.Point(117, 70);
            this.classAcceptButton2.Name = "classAcceptButton2";
            this.classAcceptButton2.Size = new System.Drawing.Size(75, 23);
            this.classAcceptButton2.TabIndex = 3;
            this.classAcceptButton2.Text = "Prihvati";
            this.classAcceptButton2.UseVisualStyleBackColor = true;
            this.classAcceptButton2.Click += new System.EventHandler(this.classAcceptButton2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(113, 36);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(196, 21);
            this.textBox2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ime predmeta:";
            // 
            // unregisterMeBox
            // 
            this.unregisterMeBox.Controls.Add(this.unregisterButton2);
            this.unregisterMeBox.Controls.Add(this.imePredmetaBox2);
            this.unregisterMeBox.Controls.Add(this.label4);
            this.unregisterMeBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unregisterMeBox.Location = new System.Drawing.Point(183, 56);
            this.unregisterMeBox.Name = "unregisterMeBox";
            this.unregisterMeBox.Size = new System.Drawing.Size(315, 99);
            this.unregisterMeBox.TabIndex = 18;
            this.unregisterMeBox.TabStop = false;
            this.unregisterMeBox.Text = "Odjava profesora sa predmeta";
            // 
            // unregisterButton2
            // 
            this.unregisterButton2.Location = new System.Drawing.Point(117, 70);
            this.unregisterButton2.Name = "unregisterButton2";
            this.unregisterButton2.Size = new System.Drawing.Size(75, 23);
            this.unregisterButton2.TabIndex = 3;
            this.unregisterButton2.Text = "Prihvati";
            this.unregisterButton2.UseVisualStyleBackColor = true;
            this.unregisterButton2.Click += new System.EventHandler(this.unregisterButton2_Click);
            // 
            // imePredmetaBox2
            // 
            this.imePredmetaBox2.Location = new System.Drawing.Point(113, 36);
            this.imePredmetaBox2.Name = "imePredmetaBox2";
            this.imePredmetaBox2.Size = new System.Drawing.Size(196, 21);
            this.imePredmetaBox2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Ime predmeta:";
            // 
            // showClassButton
            // 
            this.showClassButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showClassButton.Location = new System.Drawing.Point(12, 132);
            this.showClassButton.Name = "showClassButton";
            this.showClassButton.Size = new System.Drawing.Size(124, 23);
            this.showClassButton.TabIndex = 5;
            this.showClassButton.Text = "Prikazi predmete";
            this.showClassButton.UseVisualStyleBackColor = true;
            this.showClassButton.Click += new System.EventHandler(this.showClassButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.sendButton);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(183, 230);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 50);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Izaberi predmet";
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(175, 19);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(75, 23);
            this.sendButton.TabIndex = 1;
            this.sendButton.Text = "Prihvati";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 19);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(142, 21);
            this.textBox3.TabIndex = 0;
            // 
            // logOutButton
            // 
            this.logOutButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.logOutButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutButton.Location = new System.Drawing.Point(622, 335);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(115, 23);
            this.logOutButton.TabIndex = 9;
            this.logOutButton.Text = "Izlogujte se";
            this.logOutButton.UseVisualStyleBackColor = true;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // takeMeBackButton
            // 
            this.takeMeBackButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.takeMeBackButton.Location = new System.Drawing.Point(622, 364);
            this.takeMeBackButton.Name = "takeMeBackButton";
            this.takeMeBackButton.Size = new System.Drawing.Size(115, 23);
            this.takeMeBackButton.TabIndex = 10;
            this.takeMeBackButton.Text = "Prethodna strana";
            this.takeMeBackButton.UseVisualStyleBackColor = true;
            this.takeMeBackButton.Click += new System.EventHandler(this.takeMeBackButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.imeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.predmetBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(183, 56);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(437, 150);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // imeDataGridViewTextBoxColumn
            // 
            this.imeDataGridViewTextBoxColumn.DataPropertyName = "ime";
            this.imeDataGridViewTextBoxColumn.HeaderText = "ime";
            this.imeDataGridViewTextBoxColumn.Name = "imeDataGridViewTextBoxColumn";
            // 
            // predmetBindingSource
            // 
            this.predmetBindingSource.DataMember = "Predmet";
            this.predmetBindingSource.DataSource = this.aplikacijaDataSet;
            // 
            // aplikacijaDataSet
            // 
            this.aplikacijaDataSet.DataSetName = "AplikacijaDataSet";
            this.aplikacijaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // predmetTableAdapter
            // 
            this.predmetTableAdapter.ClearBeforeFill = true;
            // 
            // changePassword
            // 
            this.changePassword.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePassword.Location = new System.Drawing.Point(622, 306);
            this.changePassword.Name = "changePassword";
            this.changePassword.Size = new System.Drawing.Size(115, 23);
            this.changePassword.TabIndex = 12;
            this.changePassword.Text = "Promeni sifru";
            this.changePassword.UseVisualStyleBackColor = true;
            this.changePassword.Click += new System.EventHandler(this.changePassword_Click);
            // 
            // changePasswordBox
            // 
            this.changePasswordBox.Controls.Add(this.newPassword2);
            this.changePasswordBox.Controls.Add(this.newPassword1);
            this.changePasswordBox.Controls.Add(this.newPasswordLabel2);
            this.changePasswordBox.Controls.Add(this.newPasswordLabel1);
            this.changePasswordBox.Controls.Add(this.button1);
            this.changePasswordBox.Controls.Add(this.currentPassword);
            this.changePasswordBox.Controls.Add(this.currentPasswordLabel);
            this.changePasswordBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePasswordBox.Location = new System.Drawing.Point(183, 56);
            this.changePasswordBox.Name = "changePasswordBox";
            this.changePasswordBox.Size = new System.Drawing.Size(327, 129);
            this.changePasswordBox.TabIndex = 13;
            this.changePasswordBox.TabStop = false;
            this.changePasswordBox.Text = "Promena sifre";
            // 
            // newPassword2
            // 
            this.newPassword2.Location = new System.Drawing.Point(118, 72);
            this.newPassword2.Name = "newPassword2";
            this.newPassword2.Size = new System.Drawing.Size(196, 21);
            this.newPassword2.TabIndex = 7;
            // 
            // newPassword1
            // 
            this.newPassword1.Location = new System.Drawing.Point(118, 49);
            this.newPassword1.Name = "newPassword1";
            this.newPassword1.Size = new System.Drawing.Size(196, 21);
            this.newPassword1.TabIndex = 6;
            // 
            // newPasswordLabel2
            // 
            this.newPasswordLabel2.AutoSize = true;
            this.newPasswordLabel2.Location = new System.Drawing.Point(4, 75);
            this.newPasswordLabel2.Name = "newPasswordLabel2";
            this.newPasswordLabel2.Size = new System.Drawing.Size(116, 13);
            this.newPasswordLabel2.TabIndex = 5;
            this.newPasswordLabel2.Text = "Nova sifra ponovo:";
            // 
            // newPasswordLabel1
            // 
            this.newPasswordLabel1.AutoSize = true;
            this.newPasswordLabel1.Location = new System.Drawing.Point(4, 52);
            this.newPasswordLabel1.Name = "newPasswordLabel1";
            this.newPasswordLabel1.Size = new System.Drawing.Size(70, 13);
            this.newPasswordLabel1.TabIndex = 4;
            this.newPasswordLabel1.Text = "Nova sifra:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(234, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Prihvati";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // currentPassword
            // 
            this.currentPassword.Location = new System.Drawing.Point(117, 19);
            this.currentPassword.Name = "currentPassword";
            this.currentPassword.Size = new System.Drawing.Size(196, 21);
            this.currentPassword.TabIndex = 1;
            // 
            // currentPasswordLabel
            // 
            this.currentPasswordLabel.AutoSize = true;
            this.currentPasswordLabel.Location = new System.Drawing.Point(5, 22);
            this.currentPasswordLabel.Name = "currentPasswordLabel";
            this.currentPasswordLabel.Size = new System.Drawing.Size(91, 13);
            this.currentPasswordLabel.TabIndex = 0;
            this.currentPasswordLabel.Text = "Trenutna sifra:";
            // 
            // welcomeLablel
            // 
            this.welcomeLablel.AutoSize = true;
            this.welcomeLablel.Font = new System.Drawing.Font("Verdana", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLablel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.welcomeLablel.Location = new System.Drawing.Point(14, 9);
            this.welcomeLablel.Name = "welcomeLablel";
            this.welcomeLablel.Size = new System.Drawing.Size(94, 18);
            this.welcomeLablel.TabIndex = 14;
            this.welcomeLablel.Text = "Dobrodosli";
            // 
            // predmetTableAdapter1
            // 
            this.predmetTableAdapter1.ClearBeforeFill = true;
            // 
            // addAssistentButton
            // 
            this.addAssistentButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addAssistentButton.Location = new System.Drawing.Point(12, 167);
            this.addAssistentButton.Name = "addAssistentButton";
            this.addAssistentButton.Size = new System.Drawing.Size(124, 23);
            this.addAssistentButton.TabIndex = 16;
            this.addAssistentButton.Text = "Prijavi asistenta";
            this.addAssistentButton.UseVisualStyleBackColor = true;
            this.addAssistentButton.Click += new System.EventHandler(this.addAssistentButton_Click);
            // 
            // predmetBindingSource2
            // 
            this.predmetBindingSource2.DataMember = "Predmet";
            this.predmetBindingSource2.DataSource = this.aplikacijaDataSet4;
            // 
            // aplikacijaDataSet4
            // 
            this.aplikacijaDataSet4.DataSetName = "AplikacijaDataSet4";
            this.aplikacijaDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // predmetTableAdapter2
            // 
            this.predmetTableAdapter2.ClearBeforeFill = true;
            // 
            // UnregisterButton
            // 
            this.UnregisterButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnregisterButton.Location = new System.Drawing.Point(12, 237);
            this.UnregisterButton.Name = "UnregisterButton";
            this.UnregisterButton.Size = new System.Drawing.Size(124, 35);
            this.UnregisterButton.TabIndex = 17;
            this.UnregisterButton.Text = "Odjava sa predmeta";
            this.UnregisterButton.UseVisualStyleBackColor = true;
            this.UnregisterButton.Click += new System.EventHandler(this.UnregisterButton_Click);
            // 
            // deleteAssistentButton
            // 
            this.deleteAssistentButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteAssistentButton.Location = new System.Drawing.Point(12, 202);
            this.deleteAssistentButton.Name = "deleteAssistentButton";
            this.deleteAssistentButton.Size = new System.Drawing.Size(124, 23);
            this.deleteAssistentButton.TabIndex = 19;
            this.deleteAssistentButton.Text = "Odjavi asistenta";
            this.deleteAssistentButton.UseVisualStyleBackColor = true;
            this.deleteAssistentButton.Click += new System.EventHandler(this.deleteAssistentButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.OdjaviAsistentaButton);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.imeAsistenta2Box);
            this.groupBox2.Controls.Add(this.imePredmeta2Box);
            this.groupBox2.Controls.Add(this.dataGridView3);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(183, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(437, 168);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Odjava asistenta";
            // 
            // OdjaviAsistentaButton
            // 
            this.OdjaviAsistentaButton.Location = new System.Drawing.Point(356, 142);
            this.OdjaviAsistentaButton.Name = "OdjaviAsistentaButton";
            this.OdjaviAsistentaButton.Size = new System.Drawing.Size(75, 23);
            this.OdjaviAsistentaButton.TabIndex = 4;
            this.OdjaviAsistentaButton.Text = "Prihvati";
            this.OdjaviAsistentaButton.UseVisualStyleBackColor = true;
            this.OdjaviAsistentaButton.Click += new System.EventHandler(this.OdjaviAsistentaButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Username";
            // 
            // imeAsistenta2Box
            // 
            this.imeAsistenta2Box.Location = new System.Drawing.Point(22, 107);
            this.imeAsistenta2Box.Name = "imeAsistenta2Box";
            this.imeAsistenta2Box.Size = new System.Drawing.Size(125, 21);
            this.imeAsistenta2Box.TabIndex = 2;
            // 
            // imePredmeta2Box
            // 
            this.imePredmeta2Box.Location = new System.Drawing.Point(175, 107);
            this.imePredmeta2Box.Name = "imePredmeta2Box";
            this.imePredmeta2Box.Size = new System.Drawing.Size(256, 21);
            this.imePredmeta2Box.TabIndex = 1;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.predmetBindingSource3;
            this.dataGridView3.Location = new System.Drawing.Point(175, 28);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(256, 73);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ime";
            this.dataGridViewTextBoxColumn1.HeaderText = "ime";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // predmetBindingSource3
            // 
            this.predmetBindingSource3.DataMember = "Predmet";
            this.predmetBindingSource3.DataSource = this.aplikacijaDataSet5;
            // 
            // aplikacijaDataSet5
            // 
            this.aplikacijaDataSet5.DataSetName = "AplikacijaDataSet5";
            this.aplikacijaDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // predmetTableAdapter3
            // 
            this.predmetTableAdapter3.ClearBeforeFill = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.dataGridView4);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(183, 56);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(437, 168);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Odjava svih asistenata";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(356, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Prihvati";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(102, 108);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(256, 21);
            this.textBox5.TabIndex = 1;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.imeDataGridViewTextBoxColumn2});
            this.dataGridView4.DataSource = this.predmetBindingSource5;
            this.dataGridView4.Location = new System.Drawing.Point(102, 22);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(256, 73);
            this.dataGridView4.TabIndex = 0;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // imeDataGridViewTextBoxColumn2
            // 
            this.imeDataGridViewTextBoxColumn2.DataPropertyName = "ime";
            this.imeDataGridViewTextBoxColumn2.HeaderText = "ime";
            this.imeDataGridViewTextBoxColumn2.Name = "imeDataGridViewTextBoxColumn2";
            // 
            // predmetBindingSource5
            // 
            this.predmetBindingSource5.DataMember = "Predmet";
            this.predmetBindingSource5.DataSource = this.aplikacijaDataSet6;
            // 
            // aplikacijaDataSet6
            // 
            this.aplikacijaDataSet6.DataSetName = "AplikacijaDataSet6";
            this.aplikacijaDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // predmetTableAdapter4
            // 
            this.predmetTableAdapter4.ClearBeforeFill = true;
            // 
            // Form3_
            // 
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.CancelButton = this.logOutButton;
            this.ClientSize = new System.Drawing.Size(749, 399);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.deleteAssistentButton);
            this.Controls.Add(this.unregisterMeBox);
            this.Controls.Add(this.dodajAsistentaBox);
            this.Controls.Add(this.UnregisterButton);
            this.Controls.Add(this.addAssistentButton);
            this.Controls.Add(this.classDeleteBox);
            this.Controls.Add(this.changePasswordBox);
            this.Controls.Add(this.classAddBox);
            this.Controls.Add(this.welcomeLablel);
            this.Controls.Add(this.changePassword);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.takeMeBackButton);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.showClassButton);
            this.Controls.Add(this.classDeleteButton);
            this.Controls.Add(this.classAddButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form3_";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.classAddBox.ResumeLayout(false);
            this.classAddBox.PerformLayout();
            this.dodajAsistentaBox.ResumeLayout(false);
            this.dodajAsistentaBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet3)).EndInit();
            this.classDeleteBox.ResumeLayout(false);
            this.classDeleteBox.PerformLayout();
            this.unregisterMeBox.ResumeLayout(false);
            this.unregisterMeBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet)).EndInit();
            this.changePasswordBox.ResumeLayout(false);
            this.changePasswordBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet5)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aplikacijaDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Button classAddButton;
        private System.Windows.Forms.Button classDeleteButton;
        private System.Windows.Forms.GroupBox classAddBox;
        private System.Windows.Forms.Button classAcceptButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox classDeleteBox;
        private System.Windows.Forms.Button classAcceptButton2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button showClassButton;
      
        private System.ComponentModel.IContainer components;
       
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.Button takeMeBackButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private AplikacijaDataSet aplikacijaDataSet;
        private System.Windows.Forms.BindingSource predmetBindingSource;
        private AplikacijaDataSetTableAdapters.PredmetTableAdapter predmetTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button changePassword;
        private System.Windows.Forms.GroupBox changePasswordBox;
        private System.Windows.Forms.Label newPasswordLabel2;
        private System.Windows.Forms.Label newPasswordLabel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox currentPassword;
        private System.Windows.Forms.Label currentPasswordLabel;
        private System.Windows.Forms.TextBox newPassword2;
        private System.Windows.Forms.TextBox newPassword1;
        private System.Windows.Forms.Label welcomeLablel;
        private System.Windows.Forms.GroupBox dodajAsistentaBox;
        private System.Windows.Forms.DataGridView dataGridView2;
        private AplikacijaDataSet3 aplikacijaDataSet3;
        private System.Windows.Forms.BindingSource predmetBindingSource1;
        private AplikacijaDataSet3TableAdapters.PredmetTableAdapter predmetTableAdapter1;
        private System.Windows.Forms.Button acceptAssistentButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox userNameBox;
        private System.Windows.Forms.TextBox imePredmetaBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button addAssistentButton;
        private AplikacijaDataSet4 aplikacijaDataSet4;
        private System.Windows.Forms.BindingSource predmetBindingSource2;
        private AplikacijaDataSet4TableAdapters.PredmetTableAdapter predmetTableAdapter2;
        private System.Windows.Forms.GroupBox unregisterMeBox;
        private System.Windows.Forms.Button unregisterButton2;
        private System.Windows.Forms.TextBox imePredmetaBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button UnregisterButton;
        private System.Windows.Forms.Button deleteAssistentButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button OdjaviAsistentaButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox imeAsistenta2Box;
        private System.Windows.Forms.TextBox imePredmeta2Box;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private AplikacijaDataSet5 aplikacijaDataSet5;
        private System.Windows.Forms.BindingSource predmetBindingSource3;
        private AplikacijaDataSet5TableAdapters.PredmetTableAdapter predmetTableAdapter3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource predmetBindingSource4;
        private AplikacijaDataSet6 aplikacijaDataSet6;
        private System.Windows.Forms.BindingSource predmetBindingSource5;
        private AplikacijaDataSet6TableAdapters.PredmetTableAdapter predmetTableAdapter4;
        private System.Windows.Forms.DataGridViewTextBoxColumn imeDataGridViewTextBoxColumn2;
    }
}