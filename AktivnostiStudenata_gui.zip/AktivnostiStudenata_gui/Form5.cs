﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public partial class Form5 : Form
    {
        Predmet predmetOnUpdate;
        public List<KeyValuePair<string, KeyValuePair<string, string>>> studenti = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
        int idPredmeta;
        string imeStrukture = string.Empty;
        int idStrukture = 0;
        public Form5(Predmet predmetOnShare)
        {
            InitializeComponent();
            Predmet predmet = new Predmet();
            StringBuilder builder = new StringBuilder();
            this.predmetOnUpdate = predmetOnShare;
            this.idPredmeta = predmet.getClassID(predmetOnShare);
            ukloniGresku.Hide();
            if (ListAllStudents())
                listBox1.DataSource = studenti;            
            else
            {
                builder.Append("Redosled studenata koji unosite bice zapamcen.");
                listBox1.DataSource = null;
            }
            this.listBox1.MouseDoubleClick += new MouseEventHandler(listBox1_MouseDoubleClick);

            if (predmet.StructureExist(this.idPredmeta))  //ako ima studente - ispitaj da li predmet ima definisanu strukturu
            {
                this.idStrukture = predmet.getClass_StuctureId(this.idPredmeta);
                if (idStrukture != 0) //ukoliko ima
                    this.imeStrukture = predmet.getStructureName(idStrukture);                
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            bool checkUnregister = false;
            bool checkDelete = false;
            bool checkDelete2 = false;
            bool checkInsert = false;
            int studentExist = 0;
            bool structureExist = false;
            bool registerinStrAgain = false;
            bool registerAgain = false;
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            int index = this.listBox1.IndexFromPoint(e.Location);
            if (index != ListBox.NoMatches)
            {
                //take id studenta
                string brojIndeksa = studenti[index].Key.ToString();
                DialogResult result = MessageBox.Show("Da li ste sigurni da zelite obrisati ovog studenta?", "", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    if (this.idPredmeta != 0)
                    {
                        int idStudenta = student.getStudentID(new Student(brojIndeksa));
                        if (idStudenta != 0)
                        {
                            checkUnregister = student.unregisterStudent(this.idPredmeta, idStudenta);
                            if (checkUnregister)
                            {
                                builder.Append("Student sa brojem indeksa " + brojIndeksa + " je uspesno odjavljen sa predmeta.\n");
                                //zatim ispitaj da li se nalazi u strukturi
                                if (this.imeStrukture != string.Empty) //definisano je ime strukture
                                {
                                    structureExist = true;
                                    studentExist = student.StudentRegistredInStructure(idStudenta, idPredmeta, imeStrukture);
                                    if (studentExist != 0) //ako je student prijavljen u strukturu
                                    {
                                        string sqlQuery2 = "DELETE " + imeStrukture + " WHERE idStudenta = " + idStudenta + " AND idPredmeta = " + idPredmeta;
                                        checkDelete2 = instance.Delete(sqlQuery2);
                                        if (checkDelete2)
                                            builder.Append("Student sa brojem indeksa " + brojIndeksa + " je uspesno odjavljen iz strukture.\n");
                                        else
                                            builder.Append("Student sa brojem indeksa " + brojIndeksa + " je neuspesno odjavljen iz strukture.\n");
                                    }
                                    else
                                        builder.Append("Student sa brojem indeksa " + brojIndeksa + " nije pripadao strukturi.\n");
                                }
                                else
                                {
                                    structureExist = false;
                                }
                                if ((studentExist == 0) || checkDelete2) 
                                {
                                    //ako je sve ok obrisi ga iz niza + obrisi studenta
                                    this.studenti.RemoveAt(index);
                                    listBox1.DataSource = null;
                                    listBox1.DataSource = studenti;
                                    //obrisi studenta ako ne slusa ni jedan predmet vise
                                    string sqlQuery = "SELECT COUNT(*) FROM Slusa WHERE ([idStudenta] = @id)";
                                    if (instance.HasElements(idStudenta, sqlQuery) == 0) //ako ne slusa vise nijedan predmet
                                    {
                                        string sqlQuery2 = "DELETE Student WHERE idStudenta = " + idStudenta;
                                        checkDelete = instance.Delete(sqlQuery2);
                                        if (checkDelete)
                                        {
                                            builder.Append("Student sa brojem indeksa " + brojIndeksa + " je obrisan jer nije slusao vise nijedan predmet.\n");
                                            registerAgain = false;
                                        }
                                        else
                                        {
                                            builder.Append("Brisanje studenta sa brojem indeksa " + brojIndeksa + " je proslo neuspesno.\n");
                                            registerAgain = true;
                                        }
                                    }
                                    else  //ako slusa jos neki predmet nemoj da ga obrises
                                        builder.Append("Student sa brojem indeksa " + brojIndeksa + " nije obrisan jer slusa druge predmete.\n");
                                }
                                else if (registerAgain == true)
                                {
                                    KeyValuePair<string, string> imeIprezime = student.getStudentNameAndSurname(idStudenta);
                                    if (imeIprezime.Equals(new KeyValuePair<string, string>()))
                                    {
                                        studenti.Add(new KeyValuePair<string, KeyValuePair<string, string>>(brojIndeksa, imeIprezime));
                                        listBox1.DataSource = null;
                                        listBox1.DataSource = studenti;
                                    }
                                }
                                else
                                {
                                    builder.Append("Student sa brojem indeksa " + brojIndeksa + " nece biti obrisan. Doslo je do greske.\n");
                                    checkInsert = student.RegisterStudent(this.idPredmeta, idStudenta);
                                    if (checkInsert)
                                    {
                                        if (studentExist != 0) //ako je postojao u strukturi
                                        {
                                            builder.Append("Student sa brojem indeksa " + brojIndeksa + " je opet priavljen da slusa ovaj predmet.\n");
                                            List<int> ids = new List<int>();
                                            ids.Add(idStudenta);
                                            registerinStrAgain = student.InsertStudentsIntoStructure(ids, idPredmeta, imeStrukture);
                                            if (registerinStrAgain)
                                                builder.Append("Student je ponovo pridruzen strukturi.\n");
                                            else
                                                builder.Append("Student je neuspesno pridruzen strukturi.\n");
                                        }
                                        else
                                            builder.Append("Student nije pripadao strukturi i nije dodat ponovo.\n");
                                    }
                                    else
                                        builder.Append("Student sa brojem indeksa " + brojIndeksa + " je neuspesno prijavljen da slusa ovaj predmet.\n");
                                }
                            }
                            else
                                builder.Append("Student sa brojem indeksa " + brojIndeksa + " je neuspesno odjavljen sa predmeta.\nMolimo vas pokusajte ponovo.\n");
                        }
                        else
                            builder.Append("Neuspesno preuzimanje identifikacionog broja studenta.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                        builder.Append("Neuspesno preuzimanje identifikacionog broja predmeta.\nMolimo vas pokusajte ponovo.\n");
                }
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public int tryParse(string val)
        {
            int outVal = 0;

            if (Int32.TryParse(val, out outVal))
                return outVal;
            else
                return -1;
        }
        private void acceptStudentButton_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            Student student = new Student();
            Singleton instance = Singleton.getInstance();
            string ime = textBox1.Text;
            string prezime = textBox2.Text;
            string indeks = textBox3.Text;
            Student studentOnCreate = new Student(ime, prezime, indeks);
            int idStudenta;
            bool exist = false;
            bool uniqueID = false;
            bool checkInsert = false;
            bool checkInsertInSlusa = false;
            bool checkDuplicatesInSlusa = false;
            bool checkAll = false;
            bool ids = false;
            bool idp = false;
            if (ime != string.Empty && prezime != string.Empty && indeks != string.Empty)
            {
                //check ids of class
                if (this.idPredmeta != 0)
                    idp = true;
                else
                    idp = false;
                if (idp) // samo u slucaju da imamo validne podatke za identifikacione brojeve studenta i predmeta
                {
                    uniqueID = student.uniqueIndex(studentOnCreate);
                    if (!uniqueID) // ako ne postoji student sa istim indeksom  - indeks nije primarni kljuc u tablei pa je potrebno ispitivanje  
                    {
                        exist = student.studentExist(studentOnCreate);
                        if (!exist) //ako ne postoji student sa istim indeksom, imenom i prezimenom
                        {
                            //kreiraj studenta
                            checkInsert = student.CreateStudent(studentOnCreate);
                            if (checkInsert)
                            {
                                builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " je kreiran.\n");
                                //preuzmi id kreiranog studenta
                                idStudenta = student.getStudentID(studentOnCreate);
                                if (idStudenta != 0)
                                    ids = true;
                                else
                                    ids = false;
                                if (ids)
                                {
                                    //prijavi studenta da slusa predmet
                                    checkInsertInSlusa = student.RegisterStudent(this.idPredmeta, idStudenta);
                                    if (checkInsertInSlusa)
                                    {
                                        builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " je prijavljen da slusa predmet " + this.predmetOnUpdate.ime + ".\n");
                                        checkAll = true;
                                        clear();
                                    }
                                    else
                                    {
                                        builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije prijavljen da slusa predmet " + this.predmetOnUpdate.ime + ".\n");
                                        builder.Append("Molimo vas pokusajte ponovo.\n");
                                    }
                                }
                                else
                                {
                                    builder.Append("Neuspesno preuzimanje identifikacionog broja studenta.\n");
                                    builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije prijavljen na predmet " + predmetOnUpdate.ime + ".\n");
                                    builder.Append("Molimo vas pokusajte ponovo.\n");
                                }
                            }
                            else
                            {
                                builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije kreiran.\n");
                                builder.Append("Molimo vas pokusajte ponovo.\n");
                            }
                        }
                    }
                    else //ako ovakav student postoji 
                    {
                        builder.Append("Student sa brojem indeksa " + studentOnCreate.indeks + " postoji.\n");
                        //preuzmi id kreiranog studenta
                        idStudenta = student.getStudentID(studentOnCreate);
                        Console.WriteLine(idStudenta.ToString());
                        if (idStudenta != 0)
                            ids = true;
                        else
                            ids = false;
                        if (ids)
                        {
                            //proveri da li slusa ovaj predmet:
                            checkDuplicatesInSlusa = student.studentExistOnClass(this.idPredmeta, idStudenta);
                            if (!checkDuplicatesInSlusa) //ako student ne slusa predmet
                            {
                                checkInsertInSlusa = student.RegisterStudent(this.idPredmeta, idStudenta);
                                if (checkInsertInSlusa)
                                {
                                    builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " je prijavljen da slusa predmet " + this.predmetOnUpdate.ime + ".\n");
                                    checkAll = true;
                                    clear();
                                }
                                else
                                {
                                    builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije prijavljen da slusa predmet " + this.predmetOnUpdate.ime + ".\n");
                                    builder.Append("Molimo vas pokusajte ponovo.\n");
                                }
                            }
                            else //ako ovaj student vec slusa predmet
                            {
                                builder.Append("Student sa brojem indeksa " + studentOnCreate.indeks + " - " + studentOnCreate.indeks + " je vec prijavljen da slusa predmet " + this.predmetOnUpdate.ime + ".\n");
                                builder.Append("Molimo vas pokusajte ponovo.\n");
                            }
                        }
                        else
                        {
                            builder.Append("Neuspesno preuzimanje identifikacionog broja studenta.\n");
                            builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije prijavljen na predmet " + predmetOnUpdate.ime + ".\n");
                            builder.Append("Molimo vas pokusajte ponovo.\n");
                        }
                    }
                }
                else
                {
                    builder.Append("Neuspesno preuzimanje identifikacionog broja predmeta ili studenta.\n");
                    builder.Append("Student " + studentOnCreate.ime + " " + studentOnCreate.prezime + " - " + studentOnCreate.indeks + " nije prijavljen na predmet " + predmetOnUpdate.ime + "\n");
                    builder.Append("Molimo vas pokusajte ponovo.\n");
                }
            }
            else
            {
                builder.Append("Sva polja moraju biti popunjena.\n");
                builder.Append("Molimo vas pokusajte ponovo.\n");
            }
            //finally
            if (checkAll)
            {
                KeyValuePair<string, string> imeIprezime = new KeyValuePair<string, string>(studentOnCreate.ime, studentOnCreate.prezime);
                studenti.Add(new KeyValuePair<string, KeyValuePair<string, string>>(studentOnCreate.indeks, imeIprezime));
            }
            listBox1.DataSource = null;
            listBox1.DataSource = studenti;
            //finally
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public void clear()
        {
            this.textBox1.Clear();
            this.textBox2.Clear();
            this.textBox3.Clear();
        }
        public bool ListAllStudents()
        {
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            bool studentExist = false;
            List<int> IDs = student.getAllStudentsIdOnAClass(this.idPredmeta, ref studentExist);
            if (!studentExist)
            {
                builder.Append("Ne postoje prijavljeni studenti na ovom predmetu.\n");
                if (builder.Length > 0)
                    MessageBox.Show(builder.ToString());
                return false;
            }
            else
            {
                if (IDs.Count() != 0)
                {
                    List<KeyValuePair<string, KeyValuePair<string, string>>> studentInfo = student.getAllStudentNameSurnameAndIndex(this.idPredmeta, IDs);
                    if (studentInfo.Count() != 0)
                    {
                        foreach (var studentObj in studentInfo)
                            this.studenti.Add(studentObj);                        
                        if (builder.Length > 0)
                            MessageBox.Show(builder.ToString());
                        return true;
                    }
                    else
                    {
                        builder.Append("Neuspesno preuzimanje studenata koji slusaju ovaj predmet.\n");
                        if (builder.Length > 0)
                            MessageBox.Show(builder.ToString());
                        return false;
                    }
                }
                else
                {
                    builder.Append("Neuspesno preuzimanje identifikacionih brojeva studenata koji slusaju ovaj predmet.\n");
                    if (builder.Length > 0)
                        MessageBox.Show(builder.ToString());
                    return false;
                }
            }
        }
        private void finalizeButton_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            Predmet predmet = new Predmet();
            Student student = new Student();
            bool studentExist = false;
            bool stayOnPage = false;
            //Ispitaj da li je profesor prijavio neke studente
            if (this.studenti.Count() != 0)
            {
                if (predmet.StructureExist(this.idPredmeta))  //ako ima studente - ispitaj da li predmet ima definisanu strukturu
                {
                    this.imeStrukture = predmet.getStructureName(idStrukture); //preuzmi ime te strukture bog upisa u istu.
                    List<int> idStudenata = new List<int>();
                    if (this.imeStrukture != string.Empty)
                    {
                        List<int> IDs = student.getAllStudentsIdOnAClass(this.idPredmeta, ref studentExist);
                        if (studentExist)
                        {
                            if (IDs.Count() != 0)
                            {
                                bool insert = student.InsertStudentsIntoStructure(IDs, this.idPredmeta, this.imeStrukture);
                                if (insert)
                                    builder.Append("Studenti su uspesno dodati.\nSada mozete ocenjivati studente.\n");
                                else
                                {
                                    stayOnPage = true;
                                    builder.Append("Studenti nisu uspesno dodati.\n");
                                    bool undo = student.Undo_InsertStudentsIntoStructure(this.idPredmeta, this.imeStrukture);
                                    if (undo)
                                        builder.Append("Molimo vas pokusajte ponovo.\n");
                                    else
                                    {
                                        builder.Append("Doslo je do greske.\nMolimo vas da kliknete na dugme 'Odjavi studente'\n");
                                        ukloniGresku.Show();
                                    }
                                }
                            }
                            else
                            {
                                stayOnPage = true;
                                builder.Append("Neuspesno preuzimanje identifikacionih brojeva studenata.\nMolimo vas pokusajte ponovo.\n");
                            }
                        }
                        else
                            builder.Append("Ne postoje prijavljeni studenti na ovom predmetu.\n");
                    }
                    else
                    {
                        stayOnPage = true;
                        builder.Append("Neuspesno preuzimanje imena strukture koji ovaj predmet ima.\nMolimo vas pokusajte ponovo.\n");
                    }
                }
                else
                    builder.Append("Definisite strukturu predmeta kako mogli da ocenjujete studente,\nzatim ponovo izvrsite ovu operaciju klikom na dugme 'ZAVRSI'\n");
            }
            else
                builder.Append("Studenti na ovom predmetu nisu definisani\n");
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
            if (!stayOnPage)
            {
                this.Hide();
                Form4 form4 = new Form4(this.predmetOnUpdate);
                form4.Show();
            }            
        }
        private void logOutButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            Form5 form = this;
            instance.logOut(form);
        }
        private void ukloniGresku_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            Predmet predmet = new Predmet();
            Student student = new Student();

            bool undo = student.Undo_InsertStudentsIntoStructure(this.idPredmeta, this.imeStrukture);
            if (undo)
            {
                builder.Append("Pokusajte ponovo klikom na dugme 'ZAVRSI'\n");
                ukloniGresku.Hide();
            }                
            else
                builder.Append("Doslo je do greske.\nMolimo vas da kliknete na dugme 'Odjavi studente'\n");
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }        
    }
}
