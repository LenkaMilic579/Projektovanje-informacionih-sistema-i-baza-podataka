﻿using System;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public partial class Form1 : Form 
    {
        public Form1()
        {
            InitializeComponent();
        }
      
        //login check
        private void submitloginButton_Click_1(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            string username = usernameBox.Text;
            string password = passwordBox.Text;
            username = username.ToLower();
            password = password.ToLower();
            User user = new User();
            User userOnLogin = new User(username, password);
            Singleton instance = Singleton.getInstance();
            if (userOnLogin.username.Length > 0 && userOnLogin.password.Length > 0)
            {
                if (user.userExist(userOnLogin, true))
                {
                    //Save user name and surname  of user on login
                    Set.setNameofLoggedUser(userOnLogin);
                    //save id of user on login
                    Set.setUseridOnLogin(userOnLogin);
                    int idOnLogin = Set.getUserid();
                    if (idOnLogin != 0)
                    {
                        builder.Append("Korisnik " + userOnLogin.username + " je uspesno ulogovan.\n");
                        if (Set.admin)
                        {
                            this.Hide();
                            Form2 f2 = new Form2();
                            f2.Show();
                        }
                        else
                        {
                            this.Hide();
                            Form3_ f3 = new Form3_();
                            f3.Show();
                        }
                    }
                    else
                    {
                        builder.Append("Korisnik " + userOnLogin.username + " je neuspesno ulogovan.\nMolimo vas pokusajte ponovo.\n");
                        usernameBox.Clear();
                        passwordBox.Clear();
                    }
                }
                else
                {
                    builder.Append("Korisnicko ime ili sifra ne odgovaraju nijednom nalogu.\nMolimo vas pokusajte ponovo.\n");
                    passwordBox.Clear();
                }
            }
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
    }
}
