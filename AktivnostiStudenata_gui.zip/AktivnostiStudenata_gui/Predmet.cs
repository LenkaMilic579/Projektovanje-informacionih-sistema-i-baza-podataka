﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public class Predmet
    {
        public string ime;
        public int ESP;
        public string status;
        public int semestar;
        public string opis;
        public string uslov;
        public int tNastava;
        public int pNastava;
        public string literatura;
        public Predmet()
        {}
        public Predmet(string ime)
        {
            this.ime = ime;
        }
        public Predmet(int esp, string status, int semestar,string opis, string uslov, int tn, int pn )
        {
            this.ESP = esp;
            this.status = status;
            this.semestar = semestar;
            this.uslov = uslov;
            this.tNastava = tn;
            this.pNastava = pn;
            this.opis = opis;
        }
        //check existance of faculty class in database
        public bool classExist(Predmet predmet)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Predmet] WHERE ([ime] = @name)", instance.connection);
            command.Parameters.AddWithValue("@name", predmet.ime);
            int exist = (int)command.ExecuteScalar();
            if (exist > 0)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public int getClassID(Predmet predmet)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            int id = 0;
            SqlCommand command = new SqlCommand("SELECT idPredmeta FROM [Predmet] WHERE ([ime] = @name)", instance.connection);
            SqlDataReader sReader;
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@name", predmet.ime);
            sReader = command.ExecuteReader();
            if (sReader.HasRows)
            {
                sReader.Read();
                id = sReader.GetInt32(sReader.GetOrdinal("idPredmeta"));
                Console.WriteLine(id);
                if (id != 0)
                {
                    sReader.Close();
                    instance.Disconnect();
                    return id;
                }
                else
                {
                    sReader.Close();
                    instance.Disconnect();
                    MessageBox.Show("identifikacioni broj korisnika je neuspesno preuzet iz baze podataka.\n");
                    return 0;
                }
            }
            else
                return 0;            
        }
        public bool isAuthorized(Predmet predmetOnDelete)
        {
            User user = new User();            
            User userOnLogin = Set.getUser(); //preuzmi korisnika na loginu
            List<int> IDsUsers = user.getAllUserClassIDs(userOnLogin); // preuzmi sve idjeve predmeta koji predaje korisnik na loginu
            int idPredmetaOnDelete = getClassID(predmetOnDelete); //preuzmi id predmeta koji je korisnik odabrao da obrise.
            if (idPredmetaOnDelete != 0)
            {
                if (IDsUsers.Count != 0)
                {
                    if (IDsUsers.Contains(idPredmetaOnDelete))
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
            else
            {
                MessageBox.Show("Neuspesno preuzimanje idektifikacionog broja predmeta koji zelite da obrisete.\n");
                return false;
            }            
        }
        public bool isAuthorized2(int idPredmeta, int idUsera)
        {
            Singleton instance = Singleton.getInstance();
            User user = new User(); //preuzmi id predmeta koji je korisnik odabrao da obrise.
            instance.Connect();
            string sqlQuery1 = "SELECT COUNT(*) FROM Predaje WHERE ([idPredmeta] = @id) AND ([idProfesora] = @idProfesora)";
            SqlCommand command = new SqlCommand(sqlQuery1, instance.connection);
            command.Parameters.AddWithValue("@id", idPredmeta);
            command.Parameters.AddWithValue("@idProfesora", idUsera);
            int exist = (int)command.ExecuteScalar();
            if (exist == 1)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public bool Update(Predmet predmet, string classname)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            bool update = false;
            try
            {
                SqlCommand command = new SqlCommand("UPDATE Predmet SET " +
                    "ESP = CASE WHEN '" + predmet.ESP + "' != '" + 0 + "' AND '" + predmet.ESP + "' != '" + -1 + "' THEN '" + predmet.ESP + "' ELSE ESP END, " +
                    "status = CASE WHEN '" + predmet.status + "' = '" + "obavezan" + "' OR  '" + predmet.status + "' = '" + "izborni" + "' THEN '" + predmet.status + "' ELSE status END, " +
                    "semestar = CASE WHEN '" + predmet.semestar + "' != '" + 0 + "' AND '" + predmet.semestar + "' != '" + -1 + "' AND '" + predmet.semestar + "' > '" + 0 + "' THEN '" + predmet.semestar + "' ELSE semestar END, " +
                    "opis = CASE WHEN '" + predmet.opis + "' != '" + "" + "' THEN '" + predmet.opis + "' ELSE opis END, " +
                    "uslov = CASE WHEN '" + predmet.uslov + "' != '" + "" + "' THEN '" + predmet.uslov + "' ELSE uslov END, " +
                    "teorijskaNastava = CASE WHEN '" + predmet.tNastava + "' != '" + 0 + "' AND '" + predmet.tNastava + "' != '" + -1 + "'  AND '" + predmet.tNastava + "' > '" + 0 + "' THEN '" + predmet.tNastava + "' ELSE teorijskaNastava END, " +
                    "prakticnaNastava = CASE WHEN '" + predmet.pNastava + "' != '" + 0 + "' AND '" + predmet.pNastava + "' != '" + -1 + "' AND '" + predmet.pNastava + "' > '" + 0 + "' THEN '" + predmet.pNastava + "' ELSE prakticnaNastava END " +
                    "WHERE ime = '" + classname + "'", instance.connection);
                instance.adapter.UpdateCommand = command;
                instance.adapter.UpdateCommand.ExecuteNonQuery();
                command.Dispose();
                update = true;                
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                update = false;
            }
            instance.Disconnect();
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return update;
        }        
        public string getClassName(int id)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT ime FROM [Predmet] WHERE ([idPredmeta] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", id);           
            using (var reader = command.ExecuteReader())
            {          
                while (reader.Read())
                {
                    string imePredmeta = reader.GetString(reader.GetOrdinal("ime"));
                    instance.Disconnect();
                    return imePredmeta;
                }
                instance.Disconnect();
                return string.Empty;
            }
        }
        public string getStructureName(int idStrukture)
        {
            Singleton instance = Singleton.getInstance();
            string imeStr = string.Empty;
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT imeStrukture FROM [ListaStruktura] WHERE ([idStrukture] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", idStrukture);
            using (var reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    reader.Read();
                    imeStr = reader.GetString(reader.GetOrdinal("imeStrukture"));
                }
                instance.Disconnect();
            }
            return imeStr;
        }
        public int getClass_StuctureId(int idPredmeta)
        {
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            try
            {
                string req = "SELECT idStrukture FROM [Predmet] WHERE ([idPredmeta] = @id)";
                using (var command = new SqlCommand(req, instance.connection))
                {
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@id", idPredmeta);
                    int idStrukture = 0;
                    var reader = command.ExecuteScalar();
                    if (reader != null && reader != DBNull.Value && int.TryParse(reader.ToString(), out idStrukture))
                    {
                        instance.Disconnect();
                        return idStrukture;
                    }
                    else if (reader != null || reader != DBNull.Value)
                    {
                        instance.Disconnect();
                        return 0;
                    }
                }
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return 0;
        }
        public List<int> getAllClassStudentsIDs(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            List<int> IDs = new List<int>();
            //firstcheck if this user already has reported classes
            string sqlQuery = "SELECT COUNT(*) AS IsExists FROM Slusa WHERE ([idPredmeta] = @id)";
            Int32 exist = instance.HasElements(idPredmeta, sqlQuery);
                if (exist != 0)
                {
                    instance.Connect();
                    SqlCommand command = new SqlCommand("SELECT idStudenta FROM [Slusa] WHERE ([idPredmeta] = @idPredmeta)", instance.connection);
                    SqlDataReader sReader;
                    //take idsStudenta from 'Slusa'
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@idPredmeta", idPredmeta);
                    sReader = command.ExecuteReader();
                    while (sReader.Read())
                    {
                        int id = sReader.GetInt32(sReader.GetOrdinal("idStudenta"));
                            if (id != 0)
                            {
                                Console.WriteLine(id);
                                IDs.Add(id);
                            }
                            else
                            {
                                sReader.Close();
                                instance.Disconnect();
                                MessageBox.Show("identifikacioni broj studenta je neuspesno preuzet iz baze podataka.");
                                return new List<int>();
                            }                    
                    }
                    sReader.Close();
                    instance.Disconnect();
                    return IDs;
                }
                else
                {
                    instance.Disconnect();
                    return new List<int>();
                }
        }
        public bool StructureExist(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            Console.WriteLine(idPredmeta);
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Predmet] WHERE ([idPredmeta] = @idP) AND ([idStrukture] IS NOT NULL)", instance.connection);
            command.Parameters.AddWithValue("@idP", idPredmeta);
            int exist = (int)command.ExecuteScalar();
            if (exist == 1)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public int SameStructureExist(DataTable table)
        {
            var ColumnNames = new List<string>(); //ime kolona koje sadrzi tabela koju kreiramo
            var TableNames = new List<string>();  //imena postojecih kolona u bazi 
            Singleton instance = Singleton.getInstance();
            Predmet predmet = new Predmet();
            List<int> IDstrukture = new List<int>();
            int count = 0;
            int countAllColumns = 0;
            string names = string.Empty;
            string result = string.Empty;
            string sqlQuery;
            int ID = 0;
            foreach (DataColumn dc in table.Columns)
            {
                if(count > 1) // do not check first 2 columns. These colums are default columns for every table for creating
                    ColumnNames.Add(dc.ColumnName);
                count++;
            }            
            //get all table names
            TableNames = GetTableNames();
            count = ColumnNames.Count();
            countAllColumns = count + 2;

            if (TableNames.Count != 0)
            {
                instance.Connect();
                foreach (string name in TableNames)
                {
                    StringBuilder sql = new StringBuilder();
                    sql.Append("IF " + count + " = (select count(*) Name from sys.columns where Name in (");
                    for (int i = 0; i < ColumnNames.Count; i++)
                        names += " '" + ColumnNames[i] + "', ";
                    //remove last appirance of string "," in sql
                    var index = names.LastIndexOf(',');
                    if (index >= 0)
                        result = names.Substring(0, index);
                    sql.Append(result);
                    sql.Append(")");
                    sql.Append(" AND Object_ID = Object_ID(N'" + name + "')) " +
                        "if " + countAllColumns + " = (select count(*) Name from sys.columns WHERE Object_ID = Object_ID(N'" + name + "'))" +
                        "select [idStrukture] FROM [dbo].[ListaStruktura] WHERE imeStrukture = '" + name + "' ");
                    sqlQuery = sql.ToString();
                    SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                    SqlDataReader sReader;
                    sReader = command.ExecuteReader();
                    sReader.Read();
                    if (sReader.HasRows)
                        ID = sReader.GetInt32(sReader.GetOrdinal("idStrukture"));
                    sReader.Close();
                    if (ID != 0)
                    {
                        instance.Disconnect();
                        break;
                    }
                }
                instance.Disconnect();
                return ID;
            }
            else
                return 0;                                    
        }        
        public List<string> GetTableNames()
        {
            string sqlQuery = "USE Aplikacija SELECT name FROM sys.Tables";                
            Singleton instance = Singleton.getInstance();
            var TableNames = new List<string>();
            //get count of tables in database
            int countT = GetTablesCount();
            if (countT != -1)
            {
                instance.Connect();
                SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                SqlDataReader sReader;
                sReader = command.ExecuteReader();
                if (sReader.HasRows)
                {
                    int dbFields = sReader.FieldCount;
                    int count = countT;
                    string name = string.Empty;
                    while (sReader.Read())
                    {
                        name = sReader.GetString(sReader.GetOrdinal("name"));
                        if(name != "Predaje" && name != "Profesor" && name != "Slusa" && name != "Student" && name != "ListaStruktura" && name != "Predmet" && name != "sysdiagrams")
                            TableNames.Add(name);
                    }
                    sReader.Close();
                    instance.Disconnect();
                    if (TableNames.Count != 0)
                        return TableNames;
                    else
                        return new List<string>();
                }
                else
                {
                    sReader.Close();
                    instance.Disconnect();
                    return new List<string>();
                }
            }
            else
            {
                instance.Disconnect();
                MessageBox.Show("Racunanje broja tablela iz baze je proslo neuspesno.\n");
                return new List<string>();
            }
        }
        public int GetTablesCount()
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("USE Aplikacija SELECT COUNT(*) FROM sys.Tables", instance.connection);
            int count = (int)command.ExecuteScalar();
            if (count> 0)
            {
                instance.Disconnect();
                return count;
            }
            else
            {
                instance.Disconnect();
                return -1;
            }
        }
        public List<string> FindColumnNames()
        {
            Singleton instance = Singleton.getInstance();
            List<string> ColumnNames = new List<string>();            
                instance.Connect();
                SqlCommand command = new SqlCommand("select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'ListaStruktura'", instance.connection);
                SqlDataReader sReader;
                sReader = command.ExecuteReader();
                while (sReader.Read())
                {
                    string imePredmeta = sReader.GetString(sReader.GetOrdinal("column_name"));
                    ColumnNames.Add(imePredmeta);
                }
                sReader.Close();
                instance.Disconnect();
                return ColumnNames;
        }
        public List<string> FindMissingColumnNames(DataTable table)
        {
            var ImenaKolona = new List<string>();
            var ImenaTrenutnihKolona = new List<string>();
            Singleton instance = Singleton.getInstance();
            Predmet predmet = new Predmet();
            List<string> nedostajucaImenaKolona = new List<string>();
            //imena kolona tabele koja treba da se insertuje
            foreach (DataColumn dc in table.Columns)
                ImenaKolona.Add(dc.ColumnName);
            //imena kolona koja su trenutno u bazi
            ImenaTrenutnihKolona = FindColumnNames();
            foreach (string CName in ImenaKolona)
            {
                if (CName != "idStudenta" && CName != "idPredmeta")
                    if (!ImenaTrenutnihKolona.Contains(CName))
                        nedostajucaImenaKolona.Add(CName);
            }
            return nedostajucaImenaKolona;
        }
        public void AlterTable(List<string> nedostajuceKolone)
        {
            Singleton instance = Singleton.getInstance();                        
            foreach (string kolona in nedostajuceKolone)
            {
                StringBuilder sql = new StringBuilder();
                instance.Connect();
                sql.AppendFormat("ALTER TABLE ListaStruktura ADD {0} VARCHAR(50) NULL", kolona);
                string sqlQuery = sql.ToString();
                SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                SqlDataReader sReader;
                sReader = command.ExecuteReader();
                instance.Disconnect();
            }
        }
        public void UndoAlter(DataTable table, List<string> nedostajuceKolone)
        {
            Singleton instance = Singleton.getInstance();
            foreach (var kolona in nedostajuceKolone)
            {
                StringBuilder sql = new StringBuilder();
                instance.Connect();
                sql.AppendFormat("ALTER TABLE ListaStruktura DROP COLUMN {0}", kolona);
                string sqlQuery = sql.ToString();
                MessageBox.Show(sqlQuery+"  ovo je sql query");
                SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                SqlDataReader sReader;
                sReader = command.ExecuteReader();
                instance.Disconnect();
            }
        }
        public bool InsertIntoListaStruktura(DataTable table)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder sql = new StringBuilder();
            List<string> imenaKolona = new List<string>();
            bool checkInsert = false;
            int count = 0;
            sql.AppendFormat("INSERT INTO ListaStruktura(imeStrukture,");
            foreach (DataColumn kolona in table.Columns)
            {
                if (count > 1) //ne uzimaj u obzir default kolone idStudenta/idPredmeta
                    imenaKolona.Add(kolona.ColumnName);
                count++;
            }
            string LastElement = imenaKolona.Last();
            count = imenaKolona.Count();
            foreach (string kolona in imenaKolona)
            {
                if (kolona == LastElement)
                    sql.AppendFormat("{0}", kolona);
                else
                    sql.AppendFormat("{0},", kolona);
            }
            sql.AppendFormat(") VALUES (");
            for (int i = 0; i < count + 1; i++)
            {
                if (i == 0)
                    sql.AppendFormat("'" + table.TableName + "',");
                else if (i == count)
                    sql.AppendFormat("1");
                else
                    sql.AppendFormat("1,");
            }
            sql.AppendFormat(")");
            string sqlQuery = sql.ToString();
            //take all column names from this table
            checkInsert = instance.Insert(sqlQuery);
            return checkInsert;
        }
        public bool UndoInsertInListaStruktura(DataTable table)
        {
            Singleton instance = Singleton.getInstance();
            bool checkDelete = false;
            String sqlQuery = "DELETE FROM [dbo].[ListaStruktura] WHERE imeStrukture = '"+table.TableName+"'";
            checkDelete = instance.Delete(sqlQuery);
            return checkDelete;
        }
        public int FindStructureID(string TableName)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            int idStr = 0;
            SqlCommand command = new SqlCommand("SELECT * FROM [ListaStruktura] WHERE ([imeStrukture] = @name)", instance.connection);
            SqlDataReader sReader;
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@name", TableName);
            sReader = command.ExecuteReader();
            if (sReader.HasRows)
            {
                sReader.Read();
                idStr = sReader.GetInt32(sReader.GetOrdinal("idStrukture"));
                if (idStr != 0)
                {
                    sReader.Close();
                    instance.Disconnect();
                    return idStr;
                }
                else
                {
                    sReader.Close();
                    instance.Disconnect();
                    MessageBox.Show("id strukture je neuspesno preuzet iz baze podataka");
                    return 0;
                }
            }
            else
            {
                instance.Disconnect();
                return 0;
            }
        }
        public bool AlterStructureInPredmet(DataTable table, int idPredmeta, int idStrukture) //kreirana tabela, predmet id, idStrukture
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            bool update = false;
            if (idStrukture != 0)
            {
                try
                {
                    instance.Connect();
                    SqlCommand command = new SqlCommand("UPDATE Predmet SET " +
                       "idStrukture = '" + idStrukture + "' " +
                        "WHERE idPredmeta = '" + idPredmeta + "'", instance.connection);
                    instance.adapter.UpdateCommand = command;
                    instance.adapter.UpdateCommand.ExecuteNonQuery();
                    command.Dispose();
                    update = true;
                }
                catch (SqlException sqlException)
                {
                    builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                    builder.Append("Sql Error: " + sqlException.Message);
                    update = false;
                }
                instance.Disconnect();
                if (builder.Length > 0)
                    MessageBox.Show(builder.ToString());
                return update;
            }
            else
            {
                if (builder.Length > 0)
                    MessageBox.Show(builder.ToString());
                return false;
            }
        }
        public bool UndoAlterStructureInPredmet(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            bool update = false;
            try
            {
                instance.Connect();
                SqlCommand command = new SqlCommand("UPDATE Predmet SET idStrukture = NULL WHERE idPredmeta = " + idPredmeta, instance.connection);
                instance.adapter.UpdateCommand = command;
                instance.adapter.UpdateCommand.ExecuteNonQuery();
                command.Dispose();
                update = true;
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                update = false;
            }
            instance.Disconnect();
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return update;
        }
        public bool DeletePredmet(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            bool checkPredmetDelete = false;
            string sqlQuery7 = "DELETE Predmet WHERE idPredmeta = " + idPredmeta;
            checkPredmetDelete = instance.Delete(sqlQuery7);
            if (checkPredmetDelete)
                return true;
            else
                return false;
        }
        public bool ReturnStructureIdExistOnClass(int idStrukture)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Predmet] WHERE ([idStrukture] = @id)", instance.connection);
            command.Parameters.AddWithValue("@id", idStrukture);
            int exist = (int)command.ExecuteScalar();
            instance.Disconnect();
            if (exist != 0)
                return true;
            else
                return false;            
        }
        public List<string> FindColumnNamesInTable(string imeTabele)
        {
            Singleton instance = Singleton.getInstance();
            List<string> ColumnNames = new List<string>();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT sys.columns.name FROM sys.columns JOIN sys.tables ON sys.columns.object_id = tables.object_id WHERE sys.tables.name = '"+imeTabele+"' AND sys.columns.name != 'idStudenta' AND sys.columns.name != 'idPredmeta'", instance.connection);
            SqlDataReader sReader;
            sReader = command.ExecuteReader();
            while (sReader.Read())
            {
                string imeKolone = sReader.GetString(sReader.GetOrdinal("name"));
                ColumnNames.Add(imeKolone);
            }
            sReader.Close();
            instance.Disconnect();
            return ColumnNames;
        }
    }
}
