﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    class Singleton
    {
        public static Singleton instance = null;        
        const string connectionString = @"Data Source=DESKTOP-CRRD44A\APLIKACIJA;Initial Catalog=Aplikacija;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public SqlConnection connection;
        public SqlDataAdapter adapter;
        //constructor of class
        private Singleton()
        {}
        // Return the same instance of SINGLETON class every time method is called
        public static Singleton getInstance()
        {            
            if (instance == null)
            {
                instance = new Singleton();
            }
            return instance;
        }
        //Disconnect from SQL server
        public void Disconnect()
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                connection.Close();
                Console.WriteLine("Diskonektovali ste se sa SQL servera");
            }
            catch(SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        //Connect to SQL server
        public void Connect()
        {
            StringBuilder builder = new StringBuilder();
            adapter = new SqlDataAdapter();
            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                Console.WriteLine("Konektovali ste se na SQL server");
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public bool Insert(string sqlQuery)
        {
            StringBuilder builder = new StringBuilder();
            bool output = false;
            instance.Connect();            
            try
            {
                SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                instance.adapter.InsertCommand = command;
                instance.adapter.InsertCommand.ExecuteNonQuery();
                command.Dispose();
                output = true;
            }
            catch(SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                output = false;
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            instance.Disconnect();
            return output;
        }
        public bool Delete(string sqlQuery)
        {
            StringBuilder builder = new StringBuilder();
            bool output = false;
            instance.Connect();
            
            try
            {
                SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
                instance.adapter.DeleteCommand = command;
                instance.adapter.DeleteCommand.ExecuteNonQuery();
                command.Dispose();
                output = true;
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                output = false;
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            instance.Disconnect();
            return output;
        }
        public Int32 HasElements(int id, string sqlQuery)
        {
            StringBuilder builder = new StringBuilder();
            Int32 exist = 0;
            this.Connect();
            SqlCommand command = new SqlCommand(sqlQuery, this.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", id);
            try
            {
                exist = (Int32)command.ExecuteScalar();
            }
            catch (Exception sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            this.Disconnect();
            return exist;
        }
        public void logOut<T>(T f) where T : Form
        {
            User emptyUser = new User("empty");
            //Save user name and surname  of user on login
            Set.setNameofLoggedUser(emptyUser);
            //save id of user on login
            Set.setUseridOnLogin(emptyUser);
            Set.admin = false;
            f.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
        public List<string> TakeColumnNames(string imeTabele)
        {
            Singleton instance = Singleton.getInstance();
            List<string> listaImenaKolona = new List<string>();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '"+imeTabele+"' AND COLUMN_NAME != 'idStrukture' AND COLUMN_NAME != 'imeStrukture'", instance.connection);
            using (var reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string imeKolone = reader.GetString(reader.GetOrdinal("COLUMN_NAME"));
                        listaImenaKolona.Add(imeKolone);
                    }
                    instance.Disconnect();
                }
                else
                {
                    this.Disconnect();
                    return new List<string>();
                }
            }
            if (listaImenaKolona.Count() != 0)
                return listaImenaKolona;
            else
                return new List<string>();
        }
        public Int32 NullValuesInColumn(string ImeTabele, string ImeKolone)
        {
            StringBuilder builder = new StringBuilder();
            Int32 exist = 0;
            this.Connect();
            string sqlQuery = "SELECT count(*) FROM ["+ ImeTabele + "] WHERE " + ImeKolone + " IS NOT NULL";
            SqlCommand command = new SqlCommand(sqlQuery, this.connection);
            command.Parameters.Clear();
            try
            {
                exist = (Int32)command.ExecuteScalar();
            }
            catch (Exception sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            this.Disconnect();
            return exist;
        }
        public bool AlterTableDropColumn(string imeTabele, string imeKolone)
        {
            StringBuilder builder = new StringBuilder();
            string sql = "ALTER TABLE " + imeTabele + " DROP COLUMN " + imeKolone;
            SqlCommand command = new SqlCommand(sql, this.connection);
            this.Connect();
            try
            {
                command.Connection.Open();
                command.ExecuteNonQuery();
                this.Disconnect();
                return true;
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                MessageBox.Show(builder.ToString());
                this.Disconnect();
                return false;
            }
        }
        public bool DropTable(string tableName)
        {
            StringBuilder builder = new StringBuilder();
            string sql = "DROP TABLE "+tableName;
            SqlCommand command = new SqlCommand(sql, this.connection);
            this.Connect();
            try
            {
                command.Connection.Open();
                command.ExecuteNonQuery();
                this.Disconnect();
                return true;
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                MessageBox.Show(builder.ToString());
                this.Disconnect();
                return false;
            }
        }
    }
}
