﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public class Student
    {
        public string ime;
        public string prezime;
        public string indeks;
        public Student() { }
        public Student(string ime, string prezime, string index)
        {
            this.ime = ime;
            this.prezime = prezime;
            this.indeks = index;
        }
        public Student(string index)
        {
           this.indeks = index;
        }
        public int getStudentID(Student studentOnSearch)    
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            int id = 0;
            SqlCommand command = new SqlCommand("SELECT * FROM [Student] WHERE ([BrojIndeksa] = @indeks)", instance.connection);
            SqlDataReader sReader;
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@indeks", studentOnSearch.indeks);
            sReader = command.ExecuteReader();
            sReader.Read();
            id = sReader.GetInt32(sReader.GetOrdinal("idStudenta"));            
            if (id != 0)
            {
                sReader.Close();
                instance.Disconnect();
                return id;
            }
            else
            {
                sReader.Close();
                instance.Disconnect();
                return 0;
            }
        }
        public bool studentExist(Student student)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Student] WHERE ([BrojIndeksa] = @indeks) AND ([ImeStudenta] = @ime) AND ([PrezimeStudenta] = @prezime)", instance.connection);
            command.Parameters.AddWithValue("@indeks", student.indeks);
            command.Parameters.AddWithValue("@ime", student.ime);
            command.Parameters.AddWithValue("@prezime", student.prezime);
            int exist = (int)command.ExecuteScalar();
            if (exist > 0)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public bool uniqueIndex(Student student)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Student] WHERE ([BrojIndeksa] = @indeks)", instance.connection);
            command.Parameters.AddWithValue("@indeks", student.indeks);
            int exist = (int)command.ExecuteScalar();
            if (exist > 0)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public bool studentExistOnClass(int idP, int idS)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Slusa] WHERE ([idPredmeta] = @idP) AND ([idStudenta] = @idS)", instance.connection);
            command.Parameters.AddWithValue("@idP", idP);
            command.Parameters.AddWithValue("@idS", idS);
            int exist = (int)command.ExecuteScalar();
            if (exist > 0)
            {
                instance.Disconnect();
                return true;
            }
            else
            {
                instance.Disconnect();
                return false;
            }
        }
        public Int32 studentCountInSlusa(int idP)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Slusa] WHERE ([idPredmeta] = @idP)", instance.connection);
            command.Parameters.AddWithValue("@idP", idP);
            int exist = (Int32)command.ExecuteScalar();
            instance.Disconnect();
            return exist;
        }
        public bool CreateStudent(Student studentOnCreate)
        {
            Singleton instance = Singleton.getInstance();
            bool checkInsert = false;           
            String sqlQuery = "INSERT INTO Student(ImeStudenta, PrezimeStudenta, BrojIndeksa) VALUES ('" + studentOnCreate.ime + "','" + studentOnCreate.prezime + "','" + studentOnCreate.indeks + "')";
            checkInsert = instance.Insert(sqlQuery);
            return checkInsert;
        }
        public bool RegisterStudent(int idPredmeta, int idStudenta)
        {
            Singleton instance = Singleton.getInstance();
            bool checkInsert = false;
            String sqlQuery = "INSERT INTO Slusa(idPredmeta, idStudenta) VALUES (" + idPredmeta + "," + idStudenta + ")";
            checkInsert = instance.Insert(sqlQuery);
            return checkInsert;
        }
        public bool unregisterStudent(int idPredmeta, int idStudenta)
        {
            Singleton instance = Singleton.getInstance();
            bool checkDelete = false;
            String sqlQuery = "DELETE Slusa WHERE idStudenta = " + idStudenta + " AND idPredmeta = " + idPredmeta;
            checkDelete = instance.Delete(sqlQuery);
            return checkDelete;
        }
        public string getStudentName(int id)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT ImeStudenta FROM [Student] WHERE ([idStudenta] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", id);
            using (var reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    reader.Read();
                    string ime = reader.GetString(reader.GetOrdinal("ImeStudenta"));
                    if (ime != string.Empty)
                    {
                        instance.Disconnect();
                        return ime;
                    }
                    instance.Disconnect();
                    return string.Empty;
                }
                else
                    return string.Empty;
            }
        }
        public KeyValuePair<string,string> getStudentNameAndSurname(int id)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT * FROM [Student] WHERE ([idStudenta] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", id);
            using (var reader = command.ExecuteReader())
            {
                reader.Read();
                string ime = reader.GetString(reader.GetOrdinal("ImeStudenta"));
                string prezime = reader.GetString(reader.GetOrdinal("PrezimeStudenta"));
                if (ime != string.Empty && prezime != string.Empty)
                {
                    instance.Disconnect();
                    KeyValuePair<string, string> student = new KeyValuePair<string, string>(ime, prezime);
                    return student;
                }
                instance.Disconnect();
                return new KeyValuePair<string, string>();
            }
        }
        public List<KeyValuePair<string, KeyValuePair<string, string>>> getAllStudentNameSurnameAndIndex(int idPredmeta, List<int> IDs)
        {
            Singleton instance = Singleton.getInstance();
            List<KeyValuePair<string, KeyValuePair<string, string>>> studenti = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            foreach (int idS in IDs)
            {
                instance.Connect();
                SqlCommand command = new SqlCommand("SELECT ImeStudenta, PrezimeStudenta, BrojIndeksa FROM [Student] WHERE ([idStudenta] = @idS)", instance.connection);
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@idS", idS);
                using (var reader = command.ExecuteReader())
                {
                    reader.Read();
                    string ime = reader.GetString(reader.GetOrdinal("ImeStudenta"));
                    string prezime = reader.GetString(reader.GetOrdinal("PrezimeStudenta"));
                    string indeks = reader.GetString(reader.GetOrdinal("BrojIndeksa"));
                    reader.Close();
                    if (ime != string.Empty && prezime != string.Empty && indeks != string.Empty)
                    {
                        KeyValuePair<string, string> studentInfo = new KeyValuePair<string, string>(ime, prezime);
                        studenti.Add(new KeyValuePair<string, KeyValuePair<string, string>>(indeks, studentInfo));
                    }
                    else
                    {
                        instance.Disconnect();
                        return new List<KeyValuePair<string, KeyValuePair<string, string>>>();
                    }
                }
                instance.Disconnect();
            }            
            if (studenti.Count() != 0)
                return studenti;
            else
                return new List<KeyValuePair<string, KeyValuePair<string, string>>>();
        }
        public List<int> getAllStudentsIdOnAClass(int idPredmeta, ref bool exist) //OK
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            List<int> IDs = new List<int>();
            SqlCommand command = new SqlCommand("SELECT idStudenta FROM [Slusa] WHERE ([idPredmeta] = @idP)", instance.connection);
            command.Parameters.AddWithValue("@idP", idPredmeta);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                exist = true;
                while (reader.Read())
                {
                    int id = reader.GetInt32(reader.GetOrdinal("idStudenta"));
                    if (id != 0)
                        IDs.Add(id);
                    else
                    {
                        reader.Close();
                        instance.Disconnect();
                        return new List<int>();
                    }
                }
            }
            else
            {
                reader.Close();
                instance.Disconnect();
                return new List<int>();
            }
            reader.Close();
            instance.Disconnect();
            if (IDs.Count != 0)
                return IDs;
            else
                return new List<int>();
        }
        public Int32 StudentsRegistredInStructure(int idPredmeta, string ImeTabele)
        {
            Int32 exist = 0;
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            string sqlQuery = "SELECT count(*) FROM " + ImeTabele + " WHERE ([idPredmeta] = @idPredmeta)";
            SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@idPredmeta", idPredmeta);
            try
            {
                exist = (Int32)command.ExecuteScalar();
            }
            catch (Exception sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            instance.Disconnect();
            return exist;
        }
        public Int32 StudentRegistredInStructure(int idStudenta, int idPredmeta, string ImeTabele)
        {
            Int32 exist = 0;
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            string sqlQuery = "SELECT count(*) FROM " + ImeTabele + " WHERE ([idStudenta] = @ids) AND ([idPredmeta] = @idp)";
            SqlCommand command = new SqlCommand(sqlQuery, instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@ids", idStudenta);
            command.Parameters.AddWithValue("@idp", idPredmeta);
            try
            {
                exist = (Int32)command.ExecuteScalar();
            }
            catch (Exception sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            instance.Disconnect();
            return exist;
        }
        public bool InsertStudentsIntoStructure(List<int> idStudentsOnInsert, int idPredmeta, string imeStrukture) //posalji idStudenata koji slusaju predmet + idPredmeta - vrati true ako su svi upisani
        {
            Singleton instance = Singleton.getInstance();
            bool checkInsert = false;
            int count = 0;
            foreach (int IDs in idStudentsOnInsert)
            {
                string sqlQuery = "If Not Exists(SELECT [idStudenta],[idPredmeta] FROM "+ imeStrukture +
                    " where ([idStudenta] = "+ IDs + ") AND ([idPredmeta] = "+ idPredmeta + ")) " +
                    "Begin " +
                    "insert into "+imeStrukture+"(idStudenta, idPredmeta) values("+ IDs + ", "+ idPredmeta + ") " +
                    "End";
                checkInsert = instance.Insert(sqlQuery);
                count += 1;
            }
            if (count == idStudentsOnInsert.Count())
                return true;
            else
                return false;
        }
        public bool Undo_InsertStudentsIntoStructure(int idPredmeta, string imeStrukture)
        {
            Singleton instance = Singleton.getInstance();
            bool checkStudentsDelete = false;
            string sqlQuery = "DELETE "+ imeStrukture + " WHERE idPredmeta = " + idPredmeta;
            checkStudentsDelete = instance.Delete(sqlQuery);
            if (checkStudentsDelete)
                return true;
            else
                return false;
        }
        public bool Update(string ImeStrukture, int idPredmeta, string Kolona, List<KeyValuePair<int, double>> studenti_ocene)
        {
            Singleton instance = Singleton.getInstance();
            Predmet predmet = new Predmet();
            StringBuilder builder = new StringBuilder();
            List<string> ImenaKolonaUTabeli = new List<string>();
            bool update = false;
            int count = 0;
            ImenaKolonaUTabeli = predmet.FindColumnNamesInTable(ImeStrukture);
            if (ImenaKolonaUTabeli != new List<string>())
            {
                string sqlquery = "UPDATE " + ImeStrukture + " SET ";
                foreach (KeyValuePair<int, double> student_ocena in studenti_ocene)
                {
                    sqlquery += Kolona + " = CASE WHEN " + student_ocena.Value + " > -1 OR "+ student_ocena.Value + " IS NOT NULL THEN " + student_ocena.Value + " ELSE " + Kolona + " END " +
                        "WHERE idPredmeta = " + idPredmeta + " AND idStudenta = " + student_ocena.Key;
                    instance.Connect();
                    try
                    {
                        SqlCommand command = new SqlCommand(sqlquery, instance.connection);

                        instance.adapter.UpdateCommand = command;
                        instance.adapter.UpdateCommand.ExecuteNonQuery();
                        command.Dispose();
                        count++;

                    }
                    catch (SqlException sqlException)
                    {
                        builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                        builder.Append("Sql Error: " + sqlException.Message);
                    }
                    instance.Disconnect();
                }
                if (studenti_ocene.Count() == count)
                    update = true;
            }
            else
                builder.Append("Ocenjivanje je proslo neuspesno.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return update;
        }
        public List<KeyValuePair<int, double>> getStudentsGrades(int idPredmeta, string ImeStrukture, string KolonaOcena, int idKolone)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            List<KeyValuePair<int, double>> studenti_ocene = new List<KeyValuePair<int, double>>();
            instance.Connect();
            double ocena = 0;
            int idStudenta = 0;
            SqlCommand command = new SqlCommand("SELECT * FROM [" + ImeStrukture + "] WHERE ([idPredmeta] = @idPredmeta)", instance.connection);
            SqlDataReader sReader;
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@idPredmeta", idPredmeta);
            sReader = command.ExecuteReader();
            if (sReader.HasRows)
            {
                while (sReader.Read())
                {
                    if (sReader.IsDBNull(idKolone+2))
                    {
                        idStudenta = sReader.GetInt32(sReader.GetOrdinal("idStudenta"));
                        if (idStudenta != 0)
                        {
                            KeyValuePair<int, double> student_ocena = new KeyValuePair<int, double>(idStudenta, 0);
                            studenti_ocene.Add(student_ocena);
                        }
                        else
                        {
                            builder.Append("Neuspesno preuzimanje informacija o studentima.\n");
                            MessageBox.Show(builder.ToString());
                            sReader.Close();
                            instance.Disconnect();
                            return new List<KeyValuePair<int, double>>();
                        }
                    }
                    else
                    {
                        ocena = sReader.GetDouble(sReader.GetOrdinal(KolonaOcena));
                        idStudenta = sReader.GetInt32(sReader.GetOrdinal("idStudenta"));
                        if (idStudenta != 0)
                        {
                            KeyValuePair<int, double> student_ocena = new KeyValuePair<int, double>(idStudenta, ocena);
                            studenti_ocene.Add(student_ocena);
                        }
                        else
                        {
                            builder.Append("Neuspesno preuzimanje informacija o studentima2.\n");
                            MessageBox.Show(builder.ToString());
                            sReader.Close();
                            instance.Disconnect();
                            return new List<KeyValuePair<int, double>>();
                        }
                    }
                }
                sReader.Close();
                instance.Disconnect();
                return studenti_ocene;
            }
            else
            {
                builder.Append("Ne postoje podaci u bazi definisani sa ovim upitom.\n");
                if(builder.Length > 0)
                    MessageBox.Show(builder.ToString());
                sReader.Close();
                instance.Disconnect();
                return new List<KeyValuePair<int, double>>();
            }
        }
        public bool GradeStudents(List<KeyValuePair<int, double>> idStudenata_ocene,string imeTabele,string ImeKolone, int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            int count = 0;
            bool update = false;
            string sqlquery = "UPDATE " + imeTabele + " SET ["+ ImeKolone + "] = ";
            if (idStudenata_ocene.Count() != 0)
            {
                foreach (var element in idStudenata_ocene)
                {
                    string ocena = element.Value.ToString();
                    ocena = ocena.Replace(",", ".");
                    sqlquery += ocena + " WHERE idPredmeta = " + idPredmeta + " AND idStudenta = " + element.Key;
                    instance.Connect();
                    try
                    {
                        SqlCommand command = new SqlCommand(sqlquery, instance.connection);

                        instance.adapter.UpdateCommand = command;
                        instance.adapter.UpdateCommand.ExecuteNonQuery();
                        command.Dispose();
                        count++;
                        sqlquery = "UPDATE " + imeTabele + " SET [" + ImeKolone + "] = ";
                    }
                    catch (SqlException sqlException)
                    {
                        builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                        builder.Append("Sql Error: " + sqlException.Message);
                        sqlquery = "UPDATE " + imeTabele + " SET [" + ImeKolone + "] = ";
                    }
                    instance.Disconnect();
                }
                if (idStudenata_ocene.Count() == count)
                    update = true;
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return update;
        }
    }
}
