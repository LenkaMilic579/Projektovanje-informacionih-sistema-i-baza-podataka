﻿namespace AktivnostiStudenata_gui
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addUserButton = new System.Windows.Forms.Button();
            this.removeUserButton = new System.Windows.Forms.Button();
            this.addUserBox = new System.Windows.Forms.GroupBox();
            this.acceptUserButton = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.deleteUserBox = new System.Windows.Forms.GroupBox();
            this.deleteUserButton = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.changePasswordBox1 = new System.Windows.Forms.GroupBox();
            this.newPassword2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.newPassword1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.userName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ClassButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.changeUserPassword = new System.Windows.Forms.Button();
            this.addUserBox.SuspendLayout();
            this.deleteUserBox.SuspendLayout();
            this.changePasswordBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // addUserButton
            // 
            this.addUserButton.BackColor = System.Drawing.SystemColors.Window;
            this.addUserButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserButton.Location = new System.Drawing.Point(12, 97);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Size = new System.Drawing.Size(119, 23);
            this.addUserButton.TabIndex = 1;
            this.addUserButton.Text = "Dodaj korisnika";
            this.addUserButton.UseVisualStyleBackColor = false;
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // removeUserButton
            // 
            this.removeUserButton.BackColor = System.Drawing.SystemColors.Window;
            this.removeUserButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeUserButton.Location = new System.Drawing.Point(12, 132);
            this.removeUserButton.Name = "removeUserButton";
            this.removeUserButton.Size = new System.Drawing.Size(119, 23);
            this.removeUserButton.TabIndex = 3;
            this.removeUserButton.Text = "Ukloni korisnika";
            this.removeUserButton.UseVisualStyleBackColor = false;
            this.removeUserButton.Click += new System.EventHandler(this.removeUserButton_Click);
            // 
            // addUserBox
            // 
            this.addUserBox.Controls.Add(this.acceptUserButton);
            this.addUserBox.Controls.Add(this.textBox3);
            this.addUserBox.Controls.Add(this.textBox2);
            this.addUserBox.Controls.Add(this.textBox1);
            this.addUserBox.Controls.Add(this.label3);
            this.addUserBox.Controls.Add(this.label2);
            this.addUserBox.Controls.Add(this.label1);
            this.addUserBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserBox.Location = new System.Drawing.Point(200, 56);
            this.addUserBox.Name = "addUserBox";
            this.addUserBox.Size = new System.Drawing.Size(381, 147);
            this.addUserBox.TabIndex = 4;
            this.addUserBox.TabStop = false;
            this.addUserBox.Text = "Kreiranje novog korisnika";
            // 
            // acceptUserButton
            // 
            this.acceptUserButton.BackColor = System.Drawing.SystemColors.Window;
            this.acceptUserButton.Location = new System.Drawing.Point(300, 116);
            this.acceptUserButton.Name = "acceptUserButton";
            this.acceptUserButton.Size = new System.Drawing.Size(75, 23);
            this.acceptUserButton.TabIndex = 5;
            this.acceptUserButton.Text = "Prihvati";
            this.acceptUserButton.UseVisualStyleBackColor = false;
            this.acceptUserButton.Click += new System.EventHandler(this.acceptUserButton_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(150, 82);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(195, 21);
            this.textBox3.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(150, 57);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(195, 21);
            this.textBox2.TabIndex = 7;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(150, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(195, 21);
            this.textBox1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "password again :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "password : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "username : ";
            // 
            // deleteUserBox
            // 
            this.deleteUserBox.Controls.Add(this.deleteUserButton);
            this.deleteUserBox.Controls.Add(this.textBox4);
            this.deleteUserBox.Controls.Add(this.label4);
            this.deleteUserBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteUserBox.Location = new System.Drawing.Point(200, 56);
            this.deleteUserBox.Name = "deleteUserBox";
            this.deleteUserBox.Size = new System.Drawing.Size(381, 147);
            this.deleteUserBox.TabIndex = 6;
            this.deleteUserBox.TabStop = false;
            this.deleteUserBox.Text = "Ukloni korisnika";
            // 
            // deleteUserButton
            // 
            this.deleteUserButton.BackColor = System.Drawing.SystemColors.Window;
            this.deleteUserButton.Location = new System.Drawing.Point(300, 118);
            this.deleteUserButton.Name = "deleteUserButton";
            this.deleteUserButton.Size = new System.Drawing.Size(75, 23);
            this.deleteUserButton.TabIndex = 7;
            this.deleteUserButton.Text = "Prihvati";
            this.deleteUserButton.UseVisualStyleBackColor = false;
            this.deleteUserButton.Click += new System.EventHandler(this.deleteUserButton_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(150, 61);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(195, 21);
            this.textBox4.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Korisnicko ime :";
            // 
            // changePasswordBox1
            // 
            this.changePasswordBox1.Controls.Add(this.newPassword2);
            this.changePasswordBox1.Controls.Add(this.label8);
            this.changePasswordBox1.Controls.Add(this.newPassword1);
            this.changePasswordBox1.Controls.Add(this.label6);
            this.changePasswordBox1.Controls.Add(this.button1);
            this.changePasswordBox1.Controls.Add(this.userName);
            this.changePasswordBox1.Controls.Add(this.label5);
            this.changePasswordBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePasswordBox1.Location = new System.Drawing.Point(200, 56);
            this.changePasswordBox1.Name = "changePasswordBox1";
            this.changePasswordBox1.Size = new System.Drawing.Size(381, 147);
            this.changePasswordBox1.TabIndex = 9;
            this.changePasswordBox1.TabStop = false;
            this.changePasswordBox1.Text = "Promena sifre odredjenom korisniku";
            // 
            // newPassword2
            // 
            this.newPassword2.Location = new System.Drawing.Point(150, 82);
            this.newPassword2.Name = "newPassword2";
            this.newPassword2.Size = new System.Drawing.Size(195, 21);
            this.newPassword2.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Nova sifra ponovo:";
            // 
            // newPassword1
            // 
            this.newPassword1.Location = new System.Drawing.Point(150, 56);
            this.newPassword1.Name = "newPassword1";
            this.newPassword1.Size = new System.Drawing.Size(195, 21);
            this.newPassword1.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Nova sifra:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(300, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Prihvati";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // userName
            // 
            this.userName.Location = new System.Drawing.Point(150, 27);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(195, 21);
            this.userName.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Korisnicko ime :";
            // 
            // ClassButton
            // 
            this.ClassButton.BackColor = System.Drawing.SystemColors.Window;
            this.ClassButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassButton.Location = new System.Drawing.Point(12, 62);
            this.ClassButton.Name = "ClassButton";
            this.ClassButton.Size = new System.Drawing.Size(119, 22);
            this.ClassButton.TabIndex = 7;
            this.ClassButton.Text = "Predmeti";
            this.ClassButton.UseVisualStyleBackColor = false;
            this.ClassButton.Click += new System.EventHandler(this.ClassButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.BackColor = System.Drawing.SystemColors.Window;
            this.logOutButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.logOutButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutButton.Location = new System.Drawing.Point(621, 364);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(116, 23);
            this.logOutButton.TabIndex = 8;
            this.logOutButton.Text = "Izlogujte se";
            this.logOutButton.UseVisualStyleBackColor = false;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // changeUserPassword
            // 
            this.changeUserPassword.BackColor = System.Drawing.SystemColors.Window;
            this.changeUserPassword.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeUserPassword.Location = new System.Drawing.Point(12, 167);
            this.changeUserPassword.Name = "changeUserPassword";
            this.changeUserPassword.Size = new System.Drawing.Size(119, 23);
            this.changeUserPassword.TabIndex = 9;
            this.changeUserPassword.Text = "Resetuj sifru korisnika";
            this.changeUserPassword.UseVisualStyleBackColor = false;
            this.changeUserPassword.Click += new System.EventHandler(this.changeUserPassword_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.CancelButton = this.logOutButton;
            this.ClientSize = new System.Drawing.Size(749, 399);
            this.Controls.Add(this.changePasswordBox1);
            this.Controls.Add(this.changeUserPassword);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.ClassButton);
            this.Controls.Add(this.deleteUserBox);
            this.Controls.Add(this.addUserBox);
            this.Controls.Add(this.removeUserButton);
            this.Controls.Add(this.addUserButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin stranica";
            this.addUserBox.ResumeLayout(false);
            this.addUserBox.PerformLayout();
            this.deleteUserBox.ResumeLayout(false);
            this.deleteUserBox.PerformLayout();
            this.changePasswordBox1.ResumeLayout(false);
            this.changePasswordBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button addUserButton;
        private System.Windows.Forms.Button removeUserButton;
        private System.Windows.Forms.GroupBox addUserBox;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button acceptUserButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox deleteUserBox;
        private System.Windows.Forms.Button deleteUserButton;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button ClassButton;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.GroupBox changePasswordBox1;
        private System.Windows.Forms.TextBox newPassword2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox newPassword1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button changeUserPassword;
    }
}