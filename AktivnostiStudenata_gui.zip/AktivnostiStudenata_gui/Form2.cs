﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            addUserBox.Hide();
            deleteUserBox.Hide();
            changePasswordBox1.Hide();
        }
        private void addUserButton_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            deleteUserBox.Hide();
            changePasswordBox1.Hide();
            textBox4.Clear();
            addUserBox.Show();
        }
        private void removeUserButton_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
            addUserBox.Hide();
            changePasswordBox1.Hide();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            deleteUserBox.Show();
        }
        private void changeUserPassword_Click(object sender, EventArgs e)
        {
            userName.Clear();
            newPassword1.Clear();
            newPassword2.Clear();
            addUserBox.Hide();
            deleteUserBox.Hide();
            changePasswordBox1.Show();
        }
        private void ClassButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3_ f3 = new Form3_();
            f3.ShowDialog();
        }
        private void acceptUserButton_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            string passwordAgain = textBox3.Text;
            bool checkInsert = false;
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            if (checkInput(username, password, passwordAgain))
            {
                User user = new User(username, password);
                String sqlQuery = "INSERT INTO Profesor(Sifra, KorisnickoIme) VALUES ('" + user.password + "','" + user.username + "')";
                if (!user.userExist2(user))
                {
                    //insert new user
                    checkInsert = instance.Insert(sqlQuery);
                    //check insert for user
                    if (checkInsert != false)
                        builder.Append("Korisnik "+ user.username + " je uspesno sacuvan");
                    else
                        builder.Append("Doslo je do greske pri cuvanju korisnika.\n Molimo vas pokusajte ponovo.\n");
                }
                else
                    builder.Append("Korisnik " +user.username+ " vec postoji.\n Molimo vas pokusajte ponovo.\n");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                addUserBox.Hide();
                if (builder.Length > 0)
                    MessageBox.Show(builder.ToString());
            }            
        }
        private void deleteUserButton_Click(object sender, EventArgs e)
        {
            string username = textBox4.Text;

            bool checkProfesorDelete = false;
            bool checkPredajeDelete = false;
            bool checkPredmetDelete = false;
            bool checkSlusaDelete = false;
            bool checkStudentDelete = false;
            bool checkClassName = false;
            Singleton instance = Singleton.getInstance();
            User user = new User();
            Predmet predmet = new Predmet();
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            if (username.Length > 0)
            {
                User userOnDelete = new User(username);
                if (user.userExist2(userOnDelete))
                {
                    //take id of user on delete
                    int idProfesora = user.getuserID(username);
                    //take all ids of reported classes from this user.
                    var IDsPredmeta = new List<int>();
                    IDsPredmeta = user.getAllUserClassIDs(userOnDelete);
                    //check if this user has any clases
                    if (IDsPredmeta.Count != 0)
                    {
                        var IDsStudenta = new List<int>();
                        foreach (int idPredmeta in IDsPredmeta)
                        {
                            string classname = predmet.getClassName(idPredmeta);
                            if (classname != string.Empty)
                            {
                                //odjavi profesora sa predmeta - 'Predaje'
                                string sqlQuery2 = "DELETE Predaje WHERE idPredmeta = " + idPredmeta + " AND idProfesora = " + idProfesora;
                                checkPredajeDelete = instance.Delete(sqlQuery2);
                                if (checkPredajeDelete)
                                    builder.Append("Profesor " + userOnDelete.username + " vise ne predaje predmet " + classname + ".\n");
                                
                                else
                                    builder.Append("Odjavljivanje profesora " + userOnDelete.username + " sa predmeta " + classname + " je proslo neuspesno.\n");
                                checkClassName = true;
                            }
                            else
                                checkClassName = false;

                            if (checkClassName)
                            {
                                //sada proveri da li postoji jos neki profesor koji predaje ovaj predmet
                                //ako ne postoji odjavi studente sa predmeta, obrisi studenta ako ne slusa vise nijedan predmet i obrisi predmet
                                string sqlQuery3 = "SELECT COUNT(*) FROM Predaje WHERE ([idPredmeta] = @id)";
                                if (instance.HasElements(idPredmeta, sqlQuery3) == 0)
                                {
                                    builder.Append("Predmet " + classname + " je predavao samo profesor " + userOnDelete.username + ".\n");
                                    //odjavi studente sa predmeta
                                    //take all ids of reported students from this class.
                                    IDsStudenta = predmet.getAllClassStudentsIDs(idPredmeta);
                                    //check if this class has any students
                                    if (IDsStudenta.Count != 0)
                                    {
                                        //Odjavi studente koji slusaju ovaj predmet
                                        string sqlQuery4 = "DELETE Slusa WHERE idPredmeta = " + idPredmeta;
                                        checkSlusaDelete = instance.Delete(sqlQuery4);
                                        if (checkSlusaDelete)
                                        {
                                            builder.Append("Studenti na predmetu " + classname + " su uspesno odjavljeni.\n");
                                            //proveri da li postoji student koji ne slusa nijedan predmet. Ako postoji obrisi ga.
                                            foreach (int idStudenta in IDsStudenta)
                                            {
                                                KeyValuePair<string, string> imePrezime = student.getStudentNameAndSurname(idStudenta);
                                                string sqlQuery5 = "SELECT COUNT(*) FROM Slusa WHERE ([idStudenta] = @id)";
                                                if (instance.HasElements(idStudenta, sqlQuery5) == 0)
                                                {
                                                    string sqlQuery6 = "DELETE Student WHERE idStudenta = '" + idStudenta + "'";
                                                    checkStudentDelete = instance.Delete(sqlQuery6);
                                                    if (checkStudentDelete)
                                                        builder.Append("Student " + imePrezime.Key + imePrezime.Value + " je obrisan jer ne slusa vise nijedan predmet.\n");
                                                    else
                                                        builder.Append("Brisanje studenta " + imePrezime.Key + imePrezime.Value + " koji ne slusa vise nijedan predmet je proslo neuspesno.\n");
                                                }
                                                else
                                                    builder.Append("Student " + imePrezime.Key + imePrezime.Value + " nije obrisan jer slusa jos predmeta.\n");
                                            }
                                        }
                                        else
                                            builder.Append("Studenti na predmetu " + classname + " nisu uspesno odjavljeni.\n");
                                    }
                                    else
                                        builder.Append("Predmet " + classname + " nije imao prijavljene studente.\n");
                                    //pre svega odjavi strukturu iz predmeta, obrisi struktuu ako je niko ne koristi i obrisi predmet
                                    int idStr = predmet.getClass_StuctureId(idPredmeta);
                                    bool postojiDrPredmet = false;
                                    bool tableDropt = false;
                                    bool unregisteredStudentsInStructure = false;
                                    List<string> columnNames = new List<string>();
                                    if (idStr != 0)
                                    {
                                        string imeStrukture = predmet.getStructureName(idStr);
                                        if (imeStrukture != string.Empty)
                                        {
                                            //odjavi strukturu iz predmeta - za oba slucaja 
                                            bool alterPredmet = predmet.UndoAlterStructureInPredmet(idPredmeta);
                                            if (alterPredmet)
                                                builder.Append("Predmet vise nema strukturu.\n");
                                            else
                                                builder.Append("Neuspesno odjavljivanje id strukture ovom predmetu.\n");
                                            postojiDrPredmet = predmet.ReturnStructureIdExistOnClass(idStr);
                                            if (!postojiDrPredmet) // ako ne postoji vise predmet koji ima ovu strukturu
                                            {
                                                //takodje Obrisi strukturu jer je niko ne koristi
                                                if (instance.Delete("DELETE FROM ListaStruktura WHERE idStrukture = '" + idStr + "'")) //ako je obrisan red u Listi za ovu strukturu
                                                {
                                                    builder.Append("Struktura je uspesno obrisana.\n");
                                                    //obrisi kolone koje nijedna struktura ne koristi
                                                    columnNames = instance.TakeColumnNames("ListaStruktura");
                                                    if (columnNames != new List<string>()) // ako smo preuzeli imena kolona iz ListeStruktura
                                                    {
                                                        foreach (string columnname in columnNames)
                                                        {
                                                            Int32 exist = instance.NullValuesInColumn("ListaStruktura", columnname);
                                                            if (exist == 0) //ako nijedna struktura ne koristi ovu kolonu
                                                            {
                                                                if (instance.AlterTableDropColumn("ListaStruktura", columnname)) //izbaci kolonu iz tabele
                                                                    builder.Append("Kolona: '" + columnname + "' je uspesno obrisana.\n");
                                                                else
                                                                    builder.Append("Kolona: '" + columnname + "' je neuspesno obrisana.\n");
                                                            }
                                                        }
                                                    }
                                                    else
                                                        builder.Append("Nemoguce preuzeti imena kolona iz tabele ListeStruktura\n");
                                                }
                                                else
                                                    builder.Append("Struktura je neuspesno obrisana.\n");
                                                if (alterPredmet)
                                                {
                                                    if (tableDropt = instance.DropTable(imeStrukture))
                                                        builder.Append("Struktura " + imeStrukture + " je obrisana jer je nijedan predmet nije koristio.\n");
                                                    else
                                                        builder.Append("Struktura " + imeStrukture + " je neuspesno obrisana.\n");
                                                }
                                                else
                                                    builder.Append("Doslo je do greske.\n Molimo vas pokusajte ponovo\n");
                                            }
                                            else
                                            {
                                                builder.Append("Strukturu koji ovaj predmet koristi koriste i drugi predmeti. Struktura nije obrisana.\n");
                                                //sada samo odjavi studente iz strukture
                                                unregisteredStudentsInStructure = student.Undo_InsertStudentsIntoStructure(idPredmeta, imeStrukture);
                                                if (unregisteredStudentsInStructure)
                                                    builder.Append("Strukturi ovog predmeta vise pripadaju strudenti koji slusaju ovaj predmet\n");
                                                else
                                                    builder.Append("Neuspesno brisanja studenta iz strukture.\n");
                                            }
                                        }
                                        else
                                            builder.Append("Doslo je do greske.\n Molimo vas pokusajte ponovo\n");
                                    }
                                    else
                                        builder.Append("Doslo je do greske.\n Molimo vas pokusajte ponovo\n");
                                    //obrisi predmet
                                    string sqlQuery7 = "DELETE Predmet WHERE idPredmeta = '" + idPredmeta + "'";
                                    checkPredmetDelete = instance.Delete(sqlQuery7);
                                    if (checkPredmetDelete)
                                        builder.Append("Predmet " + classname + " je obrisan.\n");
                                    else
                                        builder.Append("Brisanje predmeta " + classname + " je proslo neuspesno.\n");
                                }
                                else
                                {
                                    builder.Append("Predmet " + classname + " nije obrisan.\n");
                                    builder.Append("Studenti koji slusaju predmet nisu odjavljeni jer ovaj predmet "+ classname + " predaje i drugi profesor(i)\n");
                                    DialogResult result = MessageBox.Show("Primeceno je da postoji drugi profesor/i koji predaju ovaj predemet "+ classname + ". \nDa li zelite da vidite koji profesori jos predaju ovaj predmet?", "", MessageBoxButtons.YesNo);
                                    if (result == DialogResult.Yes)
                                    {
                                        List<string> names = user.getOtherUsers(idPredmeta);
                                        int count = 1;
                                        foreach (var name in names)
                                            builder.Append(count++ + ". " + name + "\n");
                                    }
                                }
                            }
                            else
                                builder.Append("Neuspesno preuzimanje imena predmeta ciji je id = " + idPredmeta + ".\n");
                        }
                    }
                    else
                        builder.Append("Profesor " + userOnDelete.username + " nije imao prijavljene predmete.\n");
                    //obrisi profesora ako si ga prethodno odjavio
                    string sqlQuery8 = "DELETE Profesor WHERE idProfesora = '" + idProfesora + "'";
                    checkProfesorDelete = instance.Delete(sqlQuery8);
                    if (checkProfesorDelete)
                    {
                        builder.Append("Profesor " + userOnDelete.username + " je obrisan.\n");
                        deleteUserBox.Hide();
                    }
                    else
                        builder.Append("Profesor " + userOnDelete.username + " nije obrisan. Pokusajte ponovo.\n");
                }
                else
                    builder.Append("Profesor " + userOnDelete.username + " ne postoji.Pokusajte ponovo.\n");
                textBox4.Clear();
            }
            else
            {
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.");
                textBox4.Clear();
            }
            textBox4.Clear();
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private bool checkInput(string u, string p1, string p2)
        {
            if (u.Length != 0 && p1.Length != 0 && p2.Length != 0)
            {
                if (p1 == p2)
                    return true;
                else
                {
                    MessageBox.Show("Lozinke se ne podudaraju.\nMolimo vas pokusajte ponovo.\n");
                    textBox2.Clear();
                    textBox3.Clear();
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
                return false;
            }
        }
        private void logOutButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            Form2 form2 = this;
            instance.logOut(form2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string UserName = userName.Text;
            string pass1 = newPassword1.Text;
            string pass2 = newPassword2.Text;
            StringBuilder builder = new StringBuilder();
            User user = new User();
            if (UserName != string.Empty && pass1 != string.Empty && pass2 != string.Empty)
            {
                User userOnChange = new User(UserName);
                bool userExist = user.userExist2(userOnChange);
                if (userExist)
                {
                    int idUsera = user.getuserID(userOnChange.username);
                    if (idUsera != 0)
                    {
                        if (pass1 == pass2)
                        {
                            if (user.changeUserPassword(pass1, idUsera))
                            {
                                builder.Append("Sifra je uspesno promenjena.\n");
                                userName.Clear();
                                newPassword1.Clear();
                                newPassword2.Clear();
                                changePasswordBox1.Hide();
                            }
                            else
                                builder.Append("Sifra nije uspesno promenjena.\nMolimo vas pokusajte ponovo.\n");
                        }
                        else
                        {
                            newPassword1.Clear();
                            newPassword2.Clear();
                            builder.Append("Nove sifre se ne poklapaju.\nMolimo vas pokusajte ponovo.\n");
                        }
                    }
                    else
                    {
                        userName.Clear();
                        newPassword1.Clear();
                        newPassword2.Clear();
                        builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                }
                else
                {
                    userName.Clear();
                    newPassword1.Clear();
                    newPassword2.Clear();
                    builder.Append("Uneti korisnik ne postoji.\nMolimo vas pokusajte ponovo.\n");
                }
            }
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");    
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
    }
}
