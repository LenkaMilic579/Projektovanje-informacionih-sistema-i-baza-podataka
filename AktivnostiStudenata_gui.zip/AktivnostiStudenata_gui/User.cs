﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public class User
    {
        public string username;
        public string password;
        public User()
        { }
        public User(string username)
        {
            this.username = username;
        }
        public User(string un, string p)
        {
            this.username = un;
            this.password = p;
        }
        public bool userExist(User user, bool CheckAdmin = false)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Profesor] WHERE ([KorisnickoIme] = @name) AND ([Sifra] = @pass)", instance.connection);
            command.Parameters.AddWithValue("@name", user.username);
            command.Parameters.AddWithValue("@pass", user.password);
            int exist = (int)command.ExecuteScalar();
            instance.Disconnect();
            if (exist > 0)
            {                
                if (CheckAdmin == true)
                    Set.admin = isAdmin(user);
                return true;
            }
            else
                return false;
        }
        public bool userExist2(User user)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Profesor] WHERE ([KorisnickoIme] = @name)", instance.connection);
            command.Parameters.AddWithValue("@name", user.username);
            int exist = (int)command.ExecuteScalar();
            instance.Disconnect();
            if (exist > 0)
                return true;
            else
                return false;
        }
        public bool isAdmin(User user)
        {
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            Int32 exist = 0;            
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM [Profesor] WHERE ([KorisnickoIme] = @name) AND ([idProfesora] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@name", user.username);
            command.Parameters.AddWithValue("@id", 1);
            try
            {
                exist = (Int32)command.ExecuteScalar();
            }
            catch (Exception sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            if (exist != 0)
                return true;
            else
                return false;
        }
        public int getuserID(string username="default")//optional, string parameter 'username'
        {
            Singleton instance = Singleton.getInstance();
            User user;
            if (username == "default")
                user = Set.getUser();
            else
                user = new User(username);
            if (user.username != "empty")
            {
                instance.Connect();
                SqlCommand command = new SqlCommand("SELECT * FROM [Profesor] WHERE ([KorisnickoIme] = @name)", instance.connection);
                SqlDataReader sReader;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@name", user.username);
                sReader = command.ExecuteReader();
                sReader.Read();
                int id = sReader.GetInt32(sReader.GetOrdinal("idProfesora"));
                sReader.Close();
                instance.Disconnect();
                if (id != 0)
                    return id;
                else
                    return 0;
            }
            return 0;
        }
        public List<int> getAllUserClassIDs(User user)
        {
            Singleton instance = Singleton.getInstance();
            List<int> IDs = new List<int>();
            SqlDataReader sReader;
            //first take id of user you want to delete
            int idProfesora = getuserID(user.username);
            if (idProfesora != 0)
            {
                //second check if this user already has reported classes
                string sqlQuery = "SELECT COUNT(*) FROM Predaje WHERE ([idProfesora] = @id)";
                Int32 exist = instance.HasElements(idProfesora, sqlQuery);
                instance.Connect();
                if (exist != 0)
                {
                    //take idsPredmeta from 'Predaje'
                    SqlCommand command = new SqlCommand("SELECT idPredmeta FROM [Predaje] WHERE ([idProfesora] = @idProfesora)", instance.connection);
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@idProfesora", idProfesora);
                    sReader = command.ExecuteReader();
                    if (sReader.HasRows)
                    {
                        while (sReader.Read())
                        {
                            int id = sReader.GetInt32(sReader.GetOrdinal("idPredmeta"));
                            if (id != 0)
                                IDs.Add(id);                            
                            else
                            {
                                sReader.Close();
                                instance.Disconnect();
                                return new List<int>();
                            }
                        }
                    }
                    else
                    {
                        sReader.Close();
                        instance.Disconnect();
                        return new List<int>();
                    }
                    return IDs;
                }
                else
                {
                    instance.Disconnect();
                    return new List<int>();
                }
            }
            else
                return new List<int>();
        }
        public List<string> getOtherUsers(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            List<string> names = new List<string>();
            SqlDataReader sReader;
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT idProfesora FROM [Predaje] WHERE ([idPredmeta] = @idPredmeta)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@idPredmeta", idPredmeta);
            sReader = command.ExecuteReader();

            while (sReader.Read())
            {
                int id = sReader.GetInt32(sReader.GetOrdinal("idProfesora"));
                names.Add(getUserName(id));
                
            }
            sReader.Close();
            instance.Disconnect();
            return names;
        }
        public List<int> getOtherUsers2(int idPredmeta)
        {
            Singleton instance = Singleton.getInstance();
            List<int> ids = new List<int>();
            SqlDataReader sReader;
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT idProfesora FROM [Predaje] WHERE ([idPredmeta] = @idPredmeta)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@idPredmeta", idPredmeta);
            sReader = command.ExecuteReader();
            if (sReader.HasRows)
            {
                while (sReader.Read())
                    ids.Add(sReader.GetInt32(sReader.GetOrdinal("idProfesora")));
            }
            else
            {
                sReader.Close();
                instance.Disconnect();
                return new List<int>();
            }
            
            sReader.Close();
            instance.Disconnect();
            return ids;
        }
        public string getUserName(int id)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT KorisnickoIme FROM [Profesor] WHERE ([idProfesora] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", id);
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    string ime = reader.GetString(reader.GetOrdinal("KorisnickoIme"));
                    instance.Disconnect();
                    return ime;
                }
                instance.Disconnect();
                return string.Empty;
            }
        }
        public string getUserPassword(int idKorisnika)
        {
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            SqlCommand command = new SqlCommand("SELECT Sifra FROM [Profesor] WHERE ([idProfesora] = @id)", instance.connection);
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@id", idKorisnika);
            using (var reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    reader.Read();
                    string ime = reader.GetString(reader.GetOrdinal("Sifra"));
                    instance.Disconnect();
                    return ime;
                }
                else
                    return string.Empty;                
            }
        }
        public bool changeUserPassword(string newPassword, int idUsera)
        {
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            instance.Connect();
            bool update = false;
            try
            {
                SqlCommand command = new SqlCommand("UPDATE Profesor SET [Sifra] = '"+newPassword+ "' WHERE idProfesora = "+idUsera, instance.connection);
                instance.adapter.UpdateCommand = command;
                instance.adapter.UpdateCommand.ExecuteNonQuery();
                command.Dispose();
                update = true;
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                update = false;
            }
            instance.Disconnect();
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
            return update;
        }
    }
}
