﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public partial class Form4 : Form
    {
        int id;
        int idStrukture;
        int idIsteStrukture;
        int idUlogovanogKorisnika;
        string classname;
        string TableStructureName;
        DataSet dataSet = new DataSet();
        DataTable table = new DataTable();
        string newTableString;
        List<string> missingColumnNames;
        protected readonly Predmet predmetForm5;
        public Form4(Predmet predmetOnShare)
        {
            InitializeComponent();
            Predmet predmet = new Predmet();
            Student student = new Student();
            User user = new User();
            StringBuilder builder = new StringBuilder();
            List<int> idProfesoraNaPredmetu = new List<int>();
            this.id = predmet.getClassID(predmetOnShare);
            this.classname = predmetOnShare.ime;
            idUlogovanogKorisnika = Set.getUserid();
            predmetForm5 = predmetOnShare;
            dataGridView1.Hide();
            groupBox1.Hide();
            groupBox2.Hide();
            sqlUpit.Hide();
            createTableButton.Hide();
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            idProfesoraNaPredmetu = user.getOtherUsers2(this.id);
            if (idProfesoraNaPredmetu.Count != 0)
            {
                if (idProfesoraNaPredmetu[0] != idUlogovanogKorisnika)
                {
                    changeStructureButton.Enabled = false;
                    addStructureButton.Enabled = false;
                    addStudentButton.Enabled = false;
                    addBasicButton.Enabled = false;
                }
                else
                {
                    changeStructureButton.Enabled = true;
                    addStructureButton.Enabled = true;
                    addStudentButton.Enabled = true;
                    addBasicButton.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                this.Hide();
                Form3_ form = new Form3_();
                form.Show();
            }
            if (predmet.StructureExist(this.id))
            {
                this.idStrukture = predmet.getClass_StuctureId(this.id);
                this.TableStructureName = predmet.getStructureName(this.idStrukture);
                this.table.TableName = this.TableStructureName;
                changeStructureButton.Show();
                addStructureButton.Hide();
                // ukoliko postoje studenti u strukturi omoguci dugme -Ocenjivanje-
                Int32 exist = student.StudentsRegistredInStructure(this.id, this.TableStructureName);
                if (exist == 0)
                {
                    if (idProfesoraNaPredmetu[0] == idUlogovanogKorisnika)
                        builder.Append("Molimo vas prijavite studente u novu strukturu predmeta:\nDodaj studente->Zavrsi");
                    grades.Enabled = false;
                }
                else
                {
                    Int32 count = student.studentCountInSlusa(this.id);
                    if (exist == count)
                        grades.Enabled = true;
                    else
                    {
                        if (idProfesoraNaPredmetu[0] == idUlogovanogKorisnika)
                            builder.Append("Nisu svi studenti dodati.\nMolimo vas prijavite stundente u novu strukturu predmeta:\nDodaj studente->Zavrsi");
                        grades.Enabled = false;
                    }
                }
            }
            else
            {
                this.TableStructureName = String.Concat("Struktura_", this.classname);
                this.table.TableName = this.TableStructureName;
                grades.Enabled = false;
                changeStructureButton.Hide();
                addStructureButton.Show();
            }
            this.ImePredmeta.Text = predmetOnShare.ime;
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void showInfoButton_Click(object sender, EventArgs e)
        {
            clear();
            groupBox1.Hide();
            groupBox2.Hide();
            takeMeBackButton.Enabled = true;
            showInfo();
        }
        private void addBasicButton_Click(object sender, EventArgs e)
        {
            dataGridView1.Hide();
            groupBox2.Hide();
            groupBox1.Show();
            takeMeBackButton.Enabled = true;
        }
        private void addStructureButton_Click(object sender, EventArgs e)
        {
            dataGridView1.Hide();
            clear();
            groupBox1.Hide();
            FillDataSet();
            showStructure();
            groupBox2.Show();
            takeMeBackButton.Enabled = false;
        }
        private void acceptStructureButton_Click(object sender, EventArgs e)
        {
           //1. Ispitaj da li ovaj predmet ima strukturu
            Predmet predmet = new Predmet();
            StringBuilder b = new StringBuilder();
            bool checkStructure = false;
            checkStructure = predmet.StructureExist(this.id);  
            // 1.1 ako struktura na ovom predmetu ne postoji, kreiraj je
            if (!checkStructure) 
            {
                if (this.table.Columns.Count > 2)
                {
                    //2. ispitaj da li postoji struktura sa istim kolonama
                    idIsteStrukture = predmet.SameStructureExist(this.table);
                    if (idIsteStrukture != 0) //postoji
                    {
                        b.Append("Zabelezeno je da postoji ista struktura.\n");
                        this.idStrukture = idIsteStrukture;
                        definePredmet_StructureId(this.idStrukture);
                        createTableButton.Hide();
                        addBasicButton.Show();
                        showInfoButton.Show();
                        grades.Show();
                        addStudentButton.Show();
                        groupBox2.Hide();
                        addStructureButton.Hide();
                        changeStructureButton.Show();
                    }
                    else //ako ne postoji
                    {
                        b.Append("Zabelezeno je da ne postoji ista struktura.\n");
                        //1. alter table List struktura (find missing colum names and add it with default value NULL)
                        missingColumnNames = predmet.FindMissingColumnNames(this.table);
                        predmet.AlterTable(missingColumnNames); //dodaj nedostajuce kolone u tabelu ListaStruktura
                        bool checkInsert = predmet.InsertIntoListaStruktura(this.table); //insertuj 1 na mesto kolone koja postoji za ovu tabelu, inace null
                        if (checkInsert)
                        {
                            createQuery();
                            b.Append("Struktura " + this.table.TableName + " je insertovana u Tabelu 'ListaStruktura'\n");
                            int noviIdStrukture = predmet.FindStructureID(this.table.TableName);
                            if (noviIdStrukture != 0)
                                this.idStrukture = noviIdStrukture;
                        }
                        else
                            b.Append("Neuspesno insertovanje informacija o strukturi u tabelu ListaSturktura.\n");                        
                    }
                }
                else
                {
                    b.Clear();
                    b.Append("Zao nam je, ova struktura predmeta nije dozvoljena.\n ");
                }                              
            }
            else
                b.Append("Nemoguce dodati strukturu.\nPredmet "+classname+" vec ima definisanu strukturu.\n");
            if(b.Length > 0)
                MessageBox.Show(b.ToString());
        }
        public void createQuery()
        {
            GetCreateTableSql ct = new GetCreateTableSql();
            this.newTableString = GetCreateTableSql.CreateTable(this.table);
            sqlUpit.Text = this.newTableString;
            groupBox2.Hide();
            showInfoButton.Hide();
            addBasicButton.Hide();
            addStructureButton.Hide();
            changeStructureButton.Hide();
            addStudentButton.Hide();
            grades.Hide();
            sqlUpit.Show();
            createTableButton.Show();
        }
        public void showInfo()
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            clear();
            try
            {
                SqlCommand command = new SqlCommand("SELECT * FROM [Predmet] WHERE ([ime] = @name)", instance.connection);
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@name", this.classname);
                this.aplikacijaDataSet2.Predmet.Clear();
                SqlDataAdapter adapter_this = new SqlDataAdapter(command);
                adapter_this.Fill(this.aplikacijaDataSet2.Predmet);
                dataGridView1.Show();
                instance.Disconnect();
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                instance.Disconnect();
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }        
        public void clear()
        {
            this.textBox1.Clear();
            this.textBox2.Clear();
            this.textBox3.Clear();
            this.textBox4.Clear();
            this.textBox5.Clear();
            this.richTextBox1.Clear();
            this.richTextBox2.Clear();
        }
        private void acceptInfoButton_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            bool update = false;
            string esp1 = this.textBox1.Text;
            string semestar1 = this.textBox3.Text;
            string brTN1 = this.textBox4.Text;
            string brPN1 = this.textBox5.Text;
            int ESP_ = 0;
            int semestar_ = 0;
            int teorijskaNastava_ = 0;
            int prakticnaNastava_ = 0;
            if (!esp1.Equals(""))
                ESP_ = tryParse(esp1);
            if (!semestar1.Equals(""))
                semestar_ = tryParse(semestar1);
            if (!brTN1.Equals(""))
                teorijskaNastava_ = tryParse(brTN1);
            if (!brPN1.Equals(""))
                prakticnaNastava_ = tryParse(brPN1);
            string status_ = this.textBox2.Text;
            string opis_ = this.richTextBox1.Text;
            string uslov_ = this.richTextBox2.Text;
            Predmet predmetOnUpdate = new Predmet(ESP_, status_, semestar_, opis_, uslov_, teorijskaNastava_, prakticnaNastava_);
            Predmet predmet = new Predmet();
            update = predmet.Update(predmetOnUpdate, this.classname);
            if (update)
            {
                groupBox1.Hide();
                showInfo();
                //obavesti
                if (ESP_ == -1)
                    builder.Append("Za parametar 'ESP' uneti broj.\nVasa izmena nije sacuvana.\n");
                if (status_ != string.Empty)
                {
                    if (status_ != "obavezan" && status_ != "izborni")
                        builder.Append("Za parametar 'status' dozvoljene vrednosti su 'obavezan' i 'izborni'.\nVasa izmena nije sacuvana.\n");
                }
                if(semestar_ == -1)
                    builder.Append("Za parametar 'semestar' uneti broj veci od nule.\nVasa izmena nije sacuvana.\n");
                if(teorijskaNastava_ == -1)
                    builder.Append("Za parametar 'teorijskaNastava' uneti broj veci od nule.\nVasa izmena nije sacuvana.\n");
                if (prakticnaNastava_ == -1)
                    builder.Append("Za parametar 'prakticnaNastava_' uneti broj veci od nule.\nVasa izmena nije sacuvana.\n");
                clear();
            }
            else
                builder.Append("Doslo je do greske pri promeni informacija o predmetu.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public int tryParse(string val)
        {
            int outVal = 0;

            if (Int32.TryParse(val, out outVal))
                return outVal;
            else
                return -1;
        }
        private void makeBaseStructure()
        {
            DataColumn column;
            // Create first column and add to the DataTable.
            column = new DataColumn();
            column.DataType = Type.GetType("System.Int32");
            column.ColumnName = "idStudenta";
            column.Caption = "Student_id";
            column.DefaultValue = 0;
            column.AllowDBNull = false;
            this.table.Columns.Add(column);
            // Create first column and add to the DataTable.
            column = new DataColumn();
            column.DataType = Type.GetType("System.Int32");
            column.ColumnName = "idPredmeta";
            column.AllowDBNull = false;
            column.DefaultValue = 0;
            this.table.Columns.Add(column);
            // Make the ID column the primary key column.
            /* DataColumn[] PrimaryKeyColumns = new DataColumn[1];
             PrimaryKeyColumns[0] = this.table.Columns["idStudenta"];
             this.table.PrimaryKey = PrimaryKeyColumns;*/
        }
        public void showStructure()
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            try
            {
                dataGridView2.DataSource = this.dataSet.Tables[0];
                dataGridView2.Columns["idStudenta"].Visible = false;
                dataGridView2.Columns["idPredmeta"].Visible = false;
                instance.Disconnect();
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                instance.Disconnect();
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void FillDataSet()
        {
            if (this.dataSet.Tables.Count == 0)
            {
                this.dataSet.Tables.Add(this.table);
                makeBaseStructure();
            }
        }
        private void addColonButton_Click(object sender, EventArgs e) //done
        {
            StringBuilder builder = new StringBuilder();
            string imeKolone = textBox6.Text;
            string imeKoloneUBazi = string.Empty;
            if (imeKolone.Contains(" "))
                imeKoloneUBazi = imeKolone.Replace(" ", String.Empty);
            else
                imeKoloneUBazi = imeKolone;
            if (!this.table.Columns.Contains(imeKoloneUBazi)) //ako se kolona ne sadrzi vec u tableli
            {
                if (imeKoloneUBazi != string.Empty)
                {
                    DataColumn column = new DataColumn();
                    column.DataType = Type.GetType("System.Double");
                    column.ColumnName = imeKoloneUBazi;
                    column.Caption = imeKolone;
                    column.AllowDBNull = true;
                    column.DefaultValue = DBNull.Value;
                    this.table.Columns.Add(column);
                    textBox6.Clear();
                }
                else
                    builder.Append("Nedozvoljeno ime.\nMolimo vas pokusajte ponovo.\n");                
            }
            else
                builder.Append("Imena kolona ne mogu biti ista.\nMolimo vas pokusajte ponovo.\n");
            showStructure();
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void createTableButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            string[] upiti = this.newTableString.Split(';');
            instance.Connect();
            int counter = 0;
            for (int i = 0; i < upiti.Length - 1; i++)
            {
                try
                {
                    SqlCommand command = new SqlCommand(upiti[i], instance.connection);
                    command.ExecuteNonQuery();
                    counter = counter + 1;
                }
                catch (SqlException sqlException)
                {
                    builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                    builder.Append("Sql Error: " + sqlException.Message);
                }
            }
            if (counter == upiti.Count() - 1)
            {
                builder.Append("Uspesno ste kreirali tabelu.");                
                bool insert = definePredmet_StructureId(this.idStrukture);
                if (insert)
                    builder.Append("Predmet sada ima definisanu strukturu");                
                else
                    builder.Append("Predmetu nije pridruzena struktura");
            }
            instance.Disconnect();
            sqlUpit.Hide();
            createTableButton.Hide();
            addStructureButton.Hide();
            addBasicButton.Show();
            showInfoButton.Show();
            addStudentButton.Show();
            changeStructureButton.Show();
            grades.Show();
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private bool definePredmet_StructureId(int StructureId)
        {
            Predmet predmet = new Predmet();
            //insert idStrukture into Predmet
            bool checkAlter = predmet.AlterStructureInPredmet(this.table, this.id, StructureId); //kreirana tabela, predmet id, idStrukture
            return checkAlter;
        }
        private void addStudentButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 form5 = new Form5(this.predmetForm5);
            form5.Show();
            takeMeBackButton.Enabled = true;
        }
        private void logOutButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            Form4 form = this;
            instance.logOut(form);
        }
        private void takeMeBackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3_ form = new Form3_();
            form.Show();
        }
        private void changeStructureButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Da li zelite da obrisete strukturu ovog predmeta?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Predmet predmet = new Predmet();
                Singleton instance = Singleton.getInstance();
                Predmet PredmetOnChange = new Predmet(this.classname);
                Student student = new Student();
                User user = new User();
                StringBuilder builder = new StringBuilder();
                List<string> columnNames = new List<string>();
                List<string> namesOfOtherUsersOnClass = new List<string>();
                takeMeBackButton.Enabled = true;
                bool unregisteredStudentsInStructure = false;
                bool tableDropt = false;
                bool postojiDrPredmet = false;
                this.grades.Enabled = false;
                this.dataSet.Tables.Clear();
                this.table.Columns.Clear();
                this.table.Rows.Clear();
                FillDataSet();
                showStructure();
                namesOfOtherUsersOnClass = user.getOtherUsers(this.id);
                if (namesOfOtherUsersOnClass.Count() == 1)
                {
                    //ispitaj da li neko ima ovu strukturu, ako ima samo odjavi studente iz strukture, ako nema obrisi celu strukturu.
                    int idStr = predmet.getClass_StuctureId(this.id);
                    if (idStr != 0)
                    {
                        string imeStrukture = predmet.getStructureName(idStr);
                        if (imeStrukture != string.Empty)
                        {
                            //odjavi strukturu iz predmeta - za oba slucaja
                            bool alterPredmet = predmet.UndoAlterStructureInPredmet(this.id);
                            if (alterPredmet)
                                builder.Append("Predmet vise nema strukturu.\n");
                            else
                                builder.Append("Neuspesno oduzimanje strukture ovom predmetu.\n");
                            postojiDrPredmet = predmet.ReturnStructureIdExistOnClass(idStr);
                            if (!postojiDrPredmet) // ako ne postoji vise predmet koji ima ovu strukturu
                            {
                                //takodje Obrisi strukturu jer je niko ne koristi
                                if (instance.Delete("DELETE FROM ListaStruktura WHERE idStrukture = '" + idStr + "'")) //ako je obrisan red u Listi za ovu strukturu
                                {
                                    builder.Append("Struktura na ovom predmetu je uspesno obrisana.\n");
                                    //obrisi kolone koje nijedna struktura ne koristi
                                    columnNames = instance.TakeColumnNames("ListaStruktura");
                                    if (columnNames != new List<string>()) // ako smo preuzeli imena kolona iz ListeStruktura
                                    {
                                        foreach (string columnname in columnNames)
                                        {
                                            Int32 exist = instance.NullValuesInColumn("ListaStruktura", columnname);
                                            if (exist == 0) //ako nijedna struktura ne koristi ovu kolonu
                                            {
                                                if (instance.AlterTableDropColumn("ListaStruktura", columnname)) //izbaci kolonu iz tabele
                                                    builder.Append("Kolona: '" + columnname + "' je uspesno obrisana.\n");
                                                else
                                                    builder.Append("Kolona: '" + columnname + "' je neuspesno obrisana.\n");
                                            }
                                        }
                                    }
                                    else
                                        builder.Append("Nemoguce preuzeti imena kolona iz ListeStruktura\n");
                                }
                                else
                                    builder.Append("Struktura je neuspesno obrisana.\n");
                                if (alterPredmet)
                                {
                                    if (tableDropt = instance.DropTable(imeStrukture))
                                    {
                                        changeStructureButton.Hide();
                                        addStructureButton.Show();
                                        builder.Append("Struktura " + imeStrukture + " je obrisana jer je nijedan predmet nije koristio.\n");
                                    }
                                    else
                                        builder.Append("Struktura " + imeStrukture + " je neuspesno obrisana.\n");
                                }
                                else
                                    builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo\n");
                            }
                            else
                            {
                                builder.Append("Strukturu koji ovaj predmet koristi koriste i drugi predmeti.\nStruktura nije obrisana.\n");
                                //sada samo odjavi studente iz strukture
                                unregisteredStudentsInStructure = student.Undo_InsertStudentsIntoStructure(this.id, imeStrukture);
                                if (unregisteredStudentsInStructure)
                                {
                                    changeStructureButton.Hide();
                                    addStructureButton.Show();
                                    builder.Append("Strukturi ovog predmeta vise pripadaju strudenti koji slusaju ovaj predmet\n");
                                }
                                else
                                    builder.Append("Neuspesno brisanja studenta iz strukture.\n");
                            }
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo\n");
                    }
                    else
                        builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo\n");
                }
                else
                    builder.Append("Neuspesno resetovanje strukture\nPostoji drugi profesor(i) koji predaju ovaj predmet.\n");
                if (builder.Length > 0)
                    MessageBox.Show(builder.ToString());
            }            
        }
        private void grades_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form6 = new Form6(this.classname, this.id, this.TableStructureName, this.idStrukture);
            form6.Show();
        }
    }
}
