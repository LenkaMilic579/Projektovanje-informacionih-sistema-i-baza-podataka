﻿namespace AktivnostiStudenata_gui
{
    interface UserOnLogin
    {
        User user { get; }
    }
    class UserOnLoginClass : UserOnLogin
    {
        public User user { get; set; }
    }
    class Set
    {
        public static User userReturn;
        public static int UserID;
        public static bool admin = false;       
        //default constructor
        public Set() { }        
       //get user
        public static User getUser()
        {
            return userReturn;
        }
        //get user id
        public static int getUserid()
        {
            return UserID;
        }
        //set user
        public static void setNameofLoggedUser(User userParam)
        {
            UserOnLogin useronLogin = new UserOnLoginClass()
            {
                user = userParam
            };

            userReturn = useronLogin.user;
        }
        //set userid
        public static void setUseridOnLogin(User useronLogin)
        {
            User user = new User();
            int id = user.getuserID();
            UserID = id;
        }
        //set admin mode
        public static void setAdmin()
        {
            admin = true;
        }
    }
}
