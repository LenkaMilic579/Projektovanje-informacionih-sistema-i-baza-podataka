﻿namespace AktivnostiStudenata_gui
{
    partial class Form6
    {
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabelaOcena = new System.Windows.Forms.DataGridView();
            this.oceniButton = new System.Windows.Forms.Button();
            this.takeMeBackButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.ChooseBox = new System.Windows.Forms.GroupBox();
            this.InfoFinalize = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.Label();
            this.finalizeGradesButton = new System.Windows.Forms.Button();
            this.StudentOcenaBox = new System.Windows.Forms.GroupBox();
            this.nextStudent = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.OcenaLabel = new System.Windows.Forms.Label();
            this.ImeiPrezime = new System.Windows.Forms.Label();
            this.upisaneOceneBox = new System.Windows.Forms.ListBox();
            this.GoOnButton = new System.Windows.Forms.Button();
            this.checkedListBox = new System.Windows.Forms.CheckedListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ImeFajlaBox = new System.Windows.Forms.GroupBox();
            this.acceptSaveButton = new System.Windows.Forms.Button();
            this.filenameBox = new System.Windows.Forms.TextBox();
            this.pathBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.oceniStudentaBox = new System.Windows.Forms.GroupBox();
            this.Kolona = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.brojIndeksa = new System.Windows.Forms.Label();
            this.IzmenaOceneButton = new System.Windows.Forms.Button();
            this.NovaOcenaBox = new System.Windows.Forms.TextBox();
            this.StaraOcenaBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.imeStudentaLabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.savePdfBox = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.imeFajla2Box = new System.Windows.Forms.TextBox();
            this.path2Box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tabelaOcena)).BeginInit();
            this.ChooseBox.SuspendLayout();
            this.StudentOcenaBox.SuspendLayout();
            this.ImeFajlaBox.SuspendLayout();
            this.oceniStudentaBox.SuspendLayout();
            this.savePdfBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabelaOcena
            // 
            this.tabelaOcena.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabelaOcena.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelaOcena.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabelaOcena.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabelaOcena.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabelaOcena.Location = new System.Drawing.Point(0, 0);
            this.tabelaOcena.Name = "tabelaOcena";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tabelaOcena.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.tabelaOcena.Size = new System.Drawing.Size(749, 366);
            this.tabelaOcena.TabIndex = 0;
            this.tabelaOcena.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tabelaOcena_CellContentClick);
            // 
            // oceniButton
            // 
            this.oceniButton.Location = new System.Drawing.Point(12, 372);
            this.oceniButton.Name = "oceniButton";
            this.oceniButton.Size = new System.Drawing.Size(124, 23);
            this.oceniButton.TabIndex = 1;
            this.oceniButton.Text = "Oceni";
            this.oceniButton.UseVisualStyleBackColor = true;
            this.oceniButton.Click += new System.EventHandler(this.oceniButton_Click);
            // 
            // takeMeBackButton
            // 
            this.takeMeBackButton.Location = new System.Drawing.Point(142, 372);
            this.takeMeBackButton.Name = "takeMeBackButton";
            this.takeMeBackButton.Size = new System.Drawing.Size(98, 23);
            this.takeMeBackButton.TabIndex = 2;
            this.takeMeBackButton.Text = "Prethodna strana";
            this.takeMeBackButton.UseVisualStyleBackColor = true;
            this.takeMeBackButton.Click += new System.EventHandler(this.takeMeBackButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.Location = new System.Drawing.Point(246, 372);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(98, 23);
            this.logOutButton.TabIndex = 22;
            this.logOutButton.Text = "Izlogujte se";
            this.logOutButton.UseVisualStyleBackColor = true;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // ChooseBox
            // 
            this.ChooseBox.Controls.Add(this.InfoFinalize);
            this.ChooseBox.Controls.Add(this.Info);
            this.ChooseBox.Controls.Add(this.finalizeGradesButton);
            this.ChooseBox.Controls.Add(this.StudentOcenaBox);
            this.ChooseBox.Controls.Add(this.upisaneOceneBox);
            this.ChooseBox.Controls.Add(this.GoOnButton);
            this.ChooseBox.Controls.Add(this.checkedListBox);
            this.ChooseBox.Location = new System.Drawing.Point(43, 31);
            this.ChooseBox.Name = "ChooseBox";
            this.ChooseBox.Size = new System.Drawing.Size(659, 291);
            this.ChooseBox.TabIndex = 23;
            this.ChooseBox.TabStop = false;
            // 
            // InfoFinalize
            // 
            this.InfoFinalize.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InfoFinalize.Location = new System.Drawing.Point(285, 5);
            this.InfoFinalize.Name = "InfoFinalize";
            this.InfoFinalize.Size = new System.Drawing.Size(294, 40);
            this.InfoFinalize.TabIndex = 6;
            this.InfoFinalize.Text = "Prihvatanjem opcije Zavrsi sacuvacete ocene koje ste dodelili studentima";
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Info.ForeColor = System.Drawing.Color.Black;
            this.Info.Location = new System.Drawing.Point(228, 36);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(241, 16);
            this.Info.TabIndex = 5;
            this.Info.Text = "Odaberite jedan tip provere znanja";
            // 
            // finalizeGradesButton
            // 
            this.finalizeGradesButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finalizeGradesButton.Location = new System.Drawing.Point(572, 259);
            this.finalizeGradesButton.Name = "finalizeGradesButton";
            this.finalizeGradesButton.Size = new System.Drawing.Size(75, 23);
            this.finalizeGradesButton.TabIndex = 4;
            this.finalizeGradesButton.Text = "Zavrsi";
            this.finalizeGradesButton.UseVisualStyleBackColor = true;
            this.finalizeGradesButton.Click += new System.EventHandler(this.finalizeGradesButton_Click);
            // 
            // StudentOcenaBox
            // 
            this.StudentOcenaBox.Controls.Add(this.nextStudent);
            this.StudentOcenaBox.Controls.Add(this.textBox1);
            this.StudentOcenaBox.Controls.Add(this.OcenaLabel);
            this.StudentOcenaBox.Controls.Add(this.ImeiPrezime);
            this.StudentOcenaBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentOcenaBox.Location = new System.Drawing.Point(300, 40);
            this.StudentOcenaBox.Name = "StudentOcenaBox";
            this.StudentOcenaBox.Size = new System.Drawing.Size(341, 138);
            this.StudentOcenaBox.TabIndex = 3;
            this.StudentOcenaBox.TabStop = false;
            this.StudentOcenaBox.Text = "Oceni studenta";
            // 
            // nextStudent
            // 
            this.nextStudent.Location = new System.Drawing.Point(260, 109);
            this.nextStudent.Name = "nextStudent";
            this.nextStudent.Size = new System.Drawing.Size(75, 23);
            this.nextStudent.TabIndex = 3;
            this.nextStudent.Text = "Nastavi";
            this.nextStudent.UseVisualStyleBackColor = true;
            this.nextStudent.Click += new System.EventHandler(this.nextStudent_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(132, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 2;
            // 
            // OcenaLabel
            // 
            this.OcenaLabel.AutoSize = true;
            this.OcenaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OcenaLabel.Location = new System.Drawing.Point(68, 62);
            this.OcenaLabel.Name = "OcenaLabel";
            this.OcenaLabel.Size = new System.Drawing.Size(54, 16);
            this.OcenaLabel.TabIndex = 1;
            this.OcenaLabel.Text = "Ocena :";
            // 
            // ImeiPrezime
            // 
            this.ImeiPrezime.AutoSize = true;
            this.ImeiPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImeiPrezime.ForeColor = System.Drawing.Color.DarkBlue;
            this.ImeiPrezime.Location = new System.Drawing.Point(13, 22);
            this.ImeiPrezime.Name = "ImeiPrezime";
            this.ImeiPrezime.Size = new System.Drawing.Size(103, 15);
            this.ImeiPrezime.TabIndex = 0;
            this.ImeiPrezime.Text = "NameSurname";
            // 
            // upisaneOceneBox
            // 
            this.upisaneOceneBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upisaneOceneBox.FormattingEnabled = true;
            this.upisaneOceneBox.Location = new System.Drawing.Point(53, 5);
            this.upisaneOceneBox.Name = "upisaneOceneBox";
            this.upisaneOceneBox.Size = new System.Drawing.Size(216, 277);
            this.upisaneOceneBox.TabIndex = 2;
            // 
            // GoOnButton
            // 
            this.GoOnButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoOnButton.Location = new System.Drawing.Point(300, 262);
            this.GoOnButton.Name = "GoOnButton";
            this.GoOnButton.Size = new System.Drawing.Size(75, 23);
            this.GoOnButton.TabIndex = 1;
            this.GoOnButton.Text = "Nastavi";
            this.GoOnButton.UseVisualStyleBackColor = true;
            this.GoOnButton.Click += new System.EventHandler(this.GoOnButton_Click);
            // 
            // checkedListBox
            // 
            this.checkedListBox.CheckOnClick = true;
            this.checkedListBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox.FormattingEnabled = true;
            this.checkedListBox.Location = new System.Drawing.Point(171, 64);
            this.checkedListBox.Name = "checkedListBox";
            this.checkedListBox.Size = new System.Drawing.Size(319, 196);
            this.checkedListBox.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(350, 372);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "Sacuvaj Excel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ImeFajlaBox
            // 
            this.ImeFajlaBox.Controls.Add(this.acceptSaveButton);
            this.ImeFajlaBox.Controls.Add(this.filenameBox);
            this.ImeFajlaBox.Controls.Add(this.pathBox);
            this.ImeFajlaBox.Controls.Add(this.label5);
            this.ImeFajlaBox.Controls.Add(this.label4);
            this.ImeFajlaBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImeFajlaBox.Location = new System.Drawing.Point(201, 98);
            this.ImeFajlaBox.Name = "ImeFajlaBox";
            this.ImeFajlaBox.Size = new System.Drawing.Size(347, 132);
            this.ImeFajlaBox.TabIndex = 28;
            this.ImeFajlaBox.TabStop = false;
            this.ImeFajlaBox.Text = "Sacuvaj kao excel fajl";
            // 
            // acceptSaveButton
            // 
            this.acceptSaveButton.ForeColor = System.Drawing.Color.Black;
            this.acceptSaveButton.Location = new System.Drawing.Point(266, 104);
            this.acceptSaveButton.Name = "acceptSaveButton";
            this.acceptSaveButton.Size = new System.Drawing.Size(75, 23);
            this.acceptSaveButton.TabIndex = 6;
            this.acceptSaveButton.Text = "Prihvati";
            this.acceptSaveButton.UseVisualStyleBackColor = true;
            this.acceptSaveButton.Click += new System.EventHandler(this.acceptSaveButton_Click_1);
            // 
            // filenameBox
            // 
            this.filenameBox.Location = new System.Drawing.Point(140, 72);
            this.filenameBox.Name = "filenameBox";
            this.filenameBox.Size = new System.Drawing.Size(163, 21);
            this.filenameBox.TabIndex = 3;
            // 
            // pathBox
            // 
            this.pathBox.Location = new System.Drawing.Point(140, 36);
            this.pathBox.Name = "pathBox";
            this.pathBox.ReadOnly = true;
            this.pathBox.Size = new System.Drawing.Size(163, 21);
            this.pathBox.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ime fajla :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Lokacija :";
            // 
            // oceniStudentaBox
            // 
            this.oceniStudentaBox.Controls.Add(this.Kolona);
            this.oceniStudentaBox.Controls.Add(this.label3);
            this.oceniStudentaBox.Controls.Add(this.brojIndeksa);
            this.oceniStudentaBox.Controls.Add(this.IzmenaOceneButton);
            this.oceniStudentaBox.Controls.Add(this.NovaOcenaBox);
            this.oceniStudentaBox.Controls.Add(this.StaraOcenaBox);
            this.oceniStudentaBox.Controls.Add(this.label2);
            this.oceniStudentaBox.Controls.Add(this.label1);
            this.oceniStudentaBox.Controls.Add(this.imeStudentaLabel);
            this.oceniStudentaBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oceniStudentaBox.Location = new System.Drawing.Point(191, 95);
            this.oceniStudentaBox.Name = "oceniStudentaBox";
            this.oceniStudentaBox.Size = new System.Drawing.Size(382, 132);
            this.oceniStudentaBox.TabIndex = 29;
            this.oceniStudentaBox.TabStop = false;
            this.oceniStudentaBox.Text = "Nova ocena studentu:";
            // 
            // Kolona
            // 
            this.Kolona.AutoSize = true;
            this.Kolona.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kolona.Location = new System.Drawing.Point(156, 106);
            this.Kolona.Name = "Kolona";
            this.Kolona.Size = new System.Drawing.Size(40, 15);
            this.Kolona.TabIndex = 8;
            this.Kolona.Text = "empty";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Vrsite izmenu ocene za:";
            // 
            // brojIndeksa
            // 
            this.brojIndeksa.AutoSize = true;
            this.brojIndeksa.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brojIndeksa.ForeColor = System.Drawing.Color.DarkBlue;
            this.brojIndeksa.Location = new System.Drawing.Point(298, 20);
            this.brojIndeksa.Name = "brojIndeksa";
            this.brojIndeksa.Size = new System.Drawing.Size(48, 18);
            this.brojIndeksa.TabIndex = 6;
            this.brojIndeksa.Text = "empty";
            // 
            // IzmenaOceneButton
            // 
            this.IzmenaOceneButton.ForeColor = System.Drawing.Color.Black;
            this.IzmenaOceneButton.Location = new System.Drawing.Point(301, 103);
            this.IzmenaOceneButton.Name = "IzmenaOceneButton";
            this.IzmenaOceneButton.Size = new System.Drawing.Size(75, 23);
            this.IzmenaOceneButton.TabIndex = 5;
            this.IzmenaOceneButton.Text = "Prihvati";
            this.IzmenaOceneButton.UseVisualStyleBackColor = true;
            this.IzmenaOceneButton.Click += new System.EventHandler(this.IzmenaOceneButton_Click_1);
            // 
            // NovaOcenaBox
            // 
            this.NovaOcenaBox.Location = new System.Drawing.Point(217, 67);
            this.NovaOcenaBox.Name = "NovaOcenaBox";
            this.NovaOcenaBox.Size = new System.Drawing.Size(100, 21);
            this.NovaOcenaBox.TabIndex = 4;
            // 
            // StaraOcenaBox
            // 
            this.StaraOcenaBox.Location = new System.Drawing.Point(59, 67);
            this.StaraOcenaBox.Name = "StaraOcenaBox";
            this.StaraOcenaBox.ReadOnly = true;
            this.StaraOcenaBox.Size = new System.Drawing.Size(100, 21);
            this.StaraOcenaBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(214, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nova ocena :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Stara ocena :";
            // 
            // imeStudentaLabel
            // 
            this.imeStudentaLabel.AutoSize = true;
            this.imeStudentaLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imeStudentaLabel.ForeColor = System.Drawing.Color.DarkBlue;
            this.imeStudentaLabel.Location = new System.Drawing.Point(11, 20);
            this.imeStudentaLabel.Name = "imeStudentaLabel";
            this.imeStudentaLabel.Size = new System.Drawing.Size(48, 13);
            this.imeStudentaLabel.TabIndex = 0;
            this.imeStudentaLabel.Text = "empty";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(454, 372);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 23);
            this.button2.TabIndex = 30;
            this.button2.Text = "Sacuvaj PDF";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // savePdfBox
            // 
            this.savePdfBox.Controls.Add(this.button3);
            this.savePdfBox.Controls.Add(this.imeFajla2Box);
            this.savePdfBox.Controls.Add(this.path2Box);
            this.savePdfBox.Controls.Add(this.label6);
            this.savePdfBox.Controls.Add(this.label7);
            this.savePdfBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savePdfBox.Location = new System.Drawing.Point(200, 121);
            this.savePdfBox.Name = "savePdfBox";
            this.savePdfBox.Size = new System.Drawing.Size(347, 132);
            this.savePdfBox.TabIndex = 31;
            this.savePdfBox.TabStop = false;
            this.savePdfBox.Text = "Sacuvaj kao pdf fajl";
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(266, 104);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Prihvati";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // imeFajla2Box
            // 
            this.imeFajla2Box.Location = new System.Drawing.Point(140, 72);
            this.imeFajla2Box.Name = "imeFajla2Box";
            this.imeFajla2Box.Size = new System.Drawing.Size(163, 21);
            this.imeFajla2Box.TabIndex = 3;
            // 
            // path2Box
            // 
            this.path2Box.Location = new System.Drawing.Point(140, 36);
            this.path2Box.Name = "path2Box";
            this.path2Box.ReadOnly = true;
            this.path2Box.Size = new System.Drawing.Size(163, 21);
            this.path2Box.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Ime fajla :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Lokacija :";
            // 
            // Form6
            // 
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(749, 399);
            this.ControlBox = false;
            this.Controls.Add(this.oceniStudentaBox);
            this.Controls.Add(this.savePdfBox);
            this.Controls.Add(this.ImeFajlaBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ChooseBox);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.takeMeBackButton);
            this.Controls.Add(this.oceniButton);
            this.Controls.Add(this.tabelaOcena);
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ocenjivanje studenata";
            ((System.ComponentModel.ISupportInitialize)(this.tabelaOcena)).EndInit();
            this.ChooseBox.ResumeLayout(false);
            this.ChooseBox.PerformLayout();
            this.StudentOcenaBox.ResumeLayout(false);
            this.StudentOcenaBox.PerformLayout();
            this.ImeFajlaBox.ResumeLayout(false);
            this.ImeFajlaBox.PerformLayout();
            this.oceniStudentaBox.ResumeLayout(false);
            this.oceniStudentaBox.PerformLayout();
            this.savePdfBox.ResumeLayout(false);
            this.savePdfBox.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.DataGridView tabelaOcena;
        private System.Windows.Forms.Button oceniButton;
        private System.Windows.Forms.Button takeMeBackButton;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.GroupBox ChooseBox;
        private System.Windows.Forms.CheckedListBox checkedListBox;
        private System.Windows.Forms.ListBox upisaneOceneBox;
        private System.Windows.Forms.Button GoOnButton;
        private System.Windows.Forms.Button finalizeGradesButton;
        private System.Windows.Forms.GroupBox StudentOcenaBox;
        private System.Windows.Forms.Button nextStudent;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label OcenaLabel;
        private System.Windows.Forms.Label ImeiPrezime;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Label InfoFinalize;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox ImeFajlaBox;
        private System.Windows.Forms.Button acceptSaveButton;
        private System.Windows.Forms.TextBox filenameBox;
        private System.Windows.Forms.TextBox pathBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox oceniStudentaBox;
        private System.Windows.Forms.Label Kolona;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label brojIndeksa;
        private System.Windows.Forms.Button IzmenaOceneButton;
        private System.Windows.Forms.TextBox NovaOcenaBox;
        private System.Windows.Forms.TextBox StaraOcenaBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label imeStudentaLabel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox savePdfBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox imeFajla2Box;
        private System.Windows.Forms.TextBox path2Box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

