﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    class GetCreateTableSql
    {
        public static string CreateTable(DataTable table)
        {
            StringBuilder sql = new StringBuilder();
            StringBuilder alterSql = new StringBuilder();
            sql.AppendFormat("CREATE TABLE [{0}] (", table.TableName);
            for (int i = 0; i < table.Columns.Count; i++)
            {
                bool isNumeric = false;
                bool usesColumnDefault = true;
                sql.AppendFormat("[{0}]", table.Columns[i].ColumnName);
                switch (table.Columns[i].DataType.ToString().ToUpper())
                {
                    case "SYSTEM.INT16":
                        sql.Append("[smallint]");
                        isNumeric = true;
                        break;
                    case "SYSTEM.INT32":
                        sql.Append("[int]");
                        isNumeric = true;
                        break;
                    case "SYSTEM.INT64":
                        sql.Append("[bigint]");
                        isNumeric = true;
                        break;
                    case "SYSTEM.DATETIME":
                        sql.Append("[datetime]");
                        usesColumnDefault = false;
                        break;
                    case "SYSTEM.STRING":
                        sql.AppendFormat("[nvarchar]({0})", table.Columns[i].MaxLength);
                        break;
                    case "SYSTEM.SINGLE":
                        sql.Append("[single]");
                        isNumeric = true;
                        break;
                    case "SYSTEM.DOUBLE":
                        sql.Append("[float]");
                        isNumeric = true;
                        break;
                    case "SYSTEM.DECIMAL":
                        sql.AppendFormat("[decimal](18, 6)");
                        isNumeric = true;
                        break;
                    default:
                        sql.AppendFormat("[nvarchar]({0})", table.Columns[i].MaxLength);
                        break;
                }
                if (table.Columns[i].AutoIncrement)
                {
                    sql.AppendFormat(" IDENTITY({1},{1})",
                        table.Columns[i].AutoIncrementSeed,
                        table.Columns[i].AutoIncrementStep);
                }
                else
                {
                    // DataColumns will add a blank DefaultValue for any AutoIncrement column. 
                    // We only want to create an ALTER statement for those columns that are not set to AutoIncrement. 
                    if (table.Columns[i].DefaultValue == DBNull.Value)
                    {
                        if (usesColumnDefault)
                        {
                            if (isNumeric)
                            {
                                alterSql.AppendFormat("\nALTER TABLE {0} ADD CONSTRAINT [DF_{0}_{1}]  DEFAULT (NULL) FOR [{1}];",
                                    table.TableName,
                                    table.Columns[i].ColumnName);
                            }
                            else
                            {
                                alterSql.AppendFormat("\nALTER TABLE {0} ADD CONSTRAINT [DF_{0}_{1}]  DEFAULT ('{2}') FOR [{1}];",
                                    table.TableName,
                                    table.Columns[i].ColumnName,
                                    table.Columns[i].DefaultValue);
                            }
                        }
                        else
                        {
                            // Default values on Date columns, e.g., "DateTime.Now" will not translate to SQL.
                            // This inspects the caption for a simple XML string to see if there is a SQL compliant default value, e.g., "GETDATE()".
                            try
                            {
                                System.Xml.XmlDocument xml = new System.Xml.XmlDocument();

                                xml.LoadXml(table.Columns[i].Caption);

                                alterSql.AppendFormat("\nALTER TABLE {0} ADD CONSTRAINT [DF_{0}_{1}]  DEFAULT ({2}) FOR [{1}];",
                                    table.TableName,
                                    table.Columns[i].ColumnName,
                                    xml.GetElementsByTagName("defaultValue")[0].InnerText);
                            }
                            catch
                            {}
                        }
                    }
                }
                if (!table.Columns[i].AllowDBNull)
                    sql.Append(" NOT NULL");
                sql.Append(",");
            }
            var index = sql.ToString().LastIndexOf(',');
            if (index >= 0)
            {
                string result = sql.ToString().Substring(0, index);
                sql.Clear();
                sql.Append(result);
            }
            if (table.PrimaryKey.Length > 0)
            {
                //ovo sam ja dodala na original
                StringBuilder primaryKeySql = new StringBuilder();

                primaryKeySql.AppendFormat(" CONSTRAINT [PK_{0}] PRIMARY KEY CLUSTERED"
                            + "("
                            + " [{1}] ASC"
                            + ") WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]"
                            + ") ON [PRIMARY] ", table.TableName,table.Columns[0].ColumnName);
                sql.Append(primaryKeySql);
            }
                //dovde
                /*for (int i = 0; i < table.PrimaryKey.Length; i++)
                    primaryKeySql.AppendFormat("{0},", table.PrimaryKey[i].ColumnName);
                primaryKeySql.Remove(primaryKeySql.Length - 1, 1);
                primaryKeySql.Append(")");
                sql.Append(primaryKeySql);
            }
            else
                sql.Remove(sql.Length - 1, 1);
            */
            sql.AppendFormat("\n);\n{0}", alterSql.ToString());
            //Genererate Foreign Key for this table
            StringBuilder FKstring = new StringBuilder();
            FKstring.AppendFormat(
                 " ALTER TABLE [dbo].{0} WITH CHECK " +
                 "ADD CONSTRAINT [FK_{0}_Predmet] " +
                 "FOREIGN KEY([idPredmeta]) " +
                 "REFERENCES [dbo].[Predmet] ([idPredmeta]); ", table.TableName);
            //ALTER TABLE [dbo].[{0}] CHECK CONSTRAINT [FK_Predmet_{0}]; 
            FKstring.AppendFormat(
                 " ALTER TABLE [dbo].{0} WITH CHECK " +
                 "ADD CONSTRAINT [FK_{0}_Student] " +
                 "FOREIGN KEY([idStudenta]) " +
                 "REFERENCES [dbo].[Student] ([idStudenta]); ", table.TableName);
            //ALTER TABLE[dbo].[{0}] CHECK CONSTRAINT[FK_{0}_Student]; 
            sql.AppendFormat("\n\n{0}", FKstring.ToString());
            //finally
            return sql.ToString();
        }        
    }
}
