﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Spire.DataExport;

namespace AktivnostiStudenata_gui
{
    public partial class Form6 : Form
    {
        int idPredmeta;
        int idStrukture;
        int idKolone;
        string ImePredmeta;
        string ImeStrukture;
        string KolonaOcena;
        int studentCount = 0;
        string folderName;
        Predmet predmetOnShare;
        List<string> ImenaKolona;
        List<KeyValuePair<int, double>> studenti_ocene; //idStudenta,staraOcena
        List<KeyValuePair<int, double>> studenti_ocene2; //idStudenta,novaOvena
        List<KeyValuePair<KeyValuePair<string, string>, double>> studenti_noveOcene; //ime i prezime,novaOvena
        List<KeyValuePair<string, string>> student_temp; //Imena I Prezimena studenata - po parovima.
        DataSet dataSet = new DataSet();
        DataTable table = new DataTable();
        Predmet predmet = new Predmet();
        protected readonly Predmet predmetForm6;
        public Form6(string imePredmeta, int idPredmeta, string imeStrukture, int idStrukture)
        {
            InitializeComponent();
            this.ImePredmeta = imePredmeta;
            this.idPredmeta = idPredmeta;
            this.ImeStrukture = imeStrukture;
            this.idStrukture = idStrukture;
            this.idKolone = 0;
            this.predmetOnShare = new Predmet(this.ImePredmeta);
            this.studenti_ocene = new List<KeyValuePair<int, double>>();
            this.studenti_noveOcene = new List<KeyValuePair<KeyValuePair<string, string>, double>>();
            this.student_temp = new List<KeyValuePair<string, string>>();
            this.studenti_ocene2 = new List<KeyValuePair<int, double>>();
            string folderName = string.Empty;
            //pronadji imena kolona iz tabele struktura
            this.ImenaKolona = predmet.FindColumnNamesInTable(this.ImeStrukture);
            fill();
            tabelaOcena.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells); //resize column to fit the data
            checkedListBox.CheckOnClick = true;
            ChooseBox.Hide();
            ImeFajlaBox.Hide();
            savePdfBox.Hide();
            oceniStudentaBox.Hide();
            this.checkedListBox.ItemCheck += new ItemCheckEventHandler(this.checkedListBox_ItemCheck);
            GoOnButton.Enabled = false;
            this.StudentOcenaBox.MouseClick += new MouseEventHandler(this.nextStudent_Click);
        }
        public void fill()
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            string sqlquery = "SELECT Student.BrojIndeksa,Student.ImeStudenta,Student.PrezimeStudenta, ";
            foreach (string column in ImenaKolona)
            {
                if(column == ImenaKolona.Last())
                    sqlquery += this.ImeStrukture + "." + column + " ";
                else
                    sqlquery += this.ImeStrukture + "." + column + ", ";
            }
            sqlquery += "FROM [" + this.ImeStrukture + "],[Student] " +
                "WHERE Student.idStudenta = " + this.ImeStrukture + ".idStudenta AND idPredmeta = " + this.idPredmeta + "";
            try
            {
                SqlCommand command = new SqlCommand(sqlquery, instance.connection);
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@id", this.idPredmeta);
                SqlDataAdapter adapter_this = new SqlDataAdapter(command);
                this.dataSet.Clear();
                adapter_this.Fill(this.dataSet);
                tabelaOcena.DataSource = this.dataSet.Tables[0];
                tabelaOcena.ReadOnly = false;
                tabelaOcena.Show();
                instance.Disconnect();
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                instance.Disconnect();
            }
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void takeMeBackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form = new Form4(this.predmetOnShare);
            form.Show();
        }
        private void logOutButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            Form6 form = this;
            instance.logOut(form);
        }
        private void oceniButton_Click(object sender, EventArgs e)
        {
            oceniButton.Enabled = false;
            checkedListBox.Items.Clear();
            checkedListBox.Show();
            ImeFajlaBox.Hide();
            savePdfBox.Hide();
            oceniStudentaBox.Hide();
            Info.Show();
            GoOnButton.Show();
            GoOnButton.Enabled = false;
            ChooseBox.Show();
            StudentOcenaBox.Hide();
            upisaneOceneBox.Hide();
            finalizeGradesButton.Hide();
            finalizeGradesButton.Hide();
            tabelaOcena.Hide();
            InfoFinalize.Hide();
            foreach (string ime in this.ImenaKolona)
                checkedListBox.Items.Add(ime, CheckState.Unchecked);
        }
        private void checkedListBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (e.NewValue == CheckState.Checked)
            {
                if (checkedListBox.CheckedItems.Count == 1)
                    GoOnButton.Enabled = false;
                else
                    GoOnButton.Enabled = true;                                 
            }
            else
                GoOnButton.Enabled = false;            
        }
        private void GoOnButton_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            this.KolonaOcena = checkedListBox.CheckedItems[0].ToString();
            this.idKolone = checkedListBox.Items.IndexOf(checkedListBox.CheckedItems[0]);
            StudentOcenaBox.Show();
            checkedListBox.Hide();
            GoOnButton.Hide();
            Info.Hide();
            upisaneOceneBox.Show();
            List<KeyValuePair<int, double>> temp = student.getStudentsGrades(this.idPredmeta, this.ImeStrukture, this.KolonaOcena, this.idKolone);
            if (temp != new List<KeyValuePair<int, double>>())
            {
                this.studenti_ocene = temp;
                Next();
            }            
            else
                MessageBox.Show("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
        }
        private void nextStudent_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            Student student = new Student();
            bool next = false;
            string value = textBox1.Text;
            if (value != string.Empty)
            {
                double outInt = tryParse(value);
                if (outInt != -1)
                {
                    this.studenti_noveOcene.Add(new KeyValuePair<KeyValuePair<string, string>, double>(this.student_temp[this.studentCount], outInt));
                    this.studenti_ocene2.Add(new KeyValuePair<int, double>(this.studenti_ocene[this.studentCount].Key, outInt));
                    upisaneOceneBox.DataSource = null;
                    upisaneOceneBox.DataSource = this.studenti_noveOcene;
                    this.studentCount++;
                    next = true;
                }
                else
                {
                    builder.Append("Vrednost koju unosite mora biti broj.\nMolimo vas pokusajte ponovo.\n");
                    next = false;
                }
                if (next)
                {
                    if (this.studentCount != this.studenti_ocene.Count())
                        Next();
                    else
                    {
                        StudentOcenaBox.Hide();
                        finalizeGradesButton.Show();
                        InfoFinalize.Show();
                    }
                }
            }
            else
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");            
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public double tryParse(string toDouble)
        {
            toDouble = toDouble.Replace(",", "."); //Replace every comma with dot
            double number;
            if (!Double.TryParse(toDouble, out number))
            {
                MessageBox.Show("Nedozvoljena vrednost.\nMolimo vas pokusajte ponovo.\n");
                return -1;
            } 
            //Count dots in toDouble, and if there is more than one dot, throw an exception.
            //Value such as "123.123.123" can't be converted to double
            int dotCount = 0;
            foreach (char c in toDouble) if (c == '.') dotCount++; //Increments dotCount for each dot in toDouble
            if (dotCount > 1)
                return -1;
            if (toDouble.Contains("."))
            {
                string left = toDouble.Split('.')[0]; //Everything before the dot
                string right = toDouble.Split('.')[1]; //Everything after the dot
                int iLeft = int.Parse(left); //Convert strings to ints
                int iRight = int.Parse(right);
                double d = iLeft + (iRight * Math.Pow(10, -(right.Length)));
                return d;
            }
            else
                return double.Parse(toDouble);
        }
        private void Next()
        {
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            textBox1.Clear();
            this.student_temp.Add(student.getStudentNameAndSurname(this.studenti_ocene[this.studentCount].Key));
            if (student_temp[this.studentCount].Value != null && student_temp[this.studentCount].Key != null)
                ImeiPrezime.Text = this.studentCount + 1 + ". " + student_temp[this.studentCount].Key + " " + student_temp[this.studentCount].Value;
            else
            {
                builder.Append("Doslo je do greske pri preuzimanju imena i prezimena studenta");
                checkedListBox.ClearSelected();
                textBox1.Clear();
                ChooseBox.Hide();
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void finalizeGradesButton_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            bool update = student.GradeStudents(studenti_ocene2, this.ImeStrukture, this.KolonaOcena, this.idPredmeta);
            if (update)
            {
                builder.Append("Uspesno ste ocenili studente.");
                fill();
                ChooseBox.Hide();
                tabelaOcena.Show();
                oceniButton.Enabled = true;

            }
            else
                builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void tabelaOcena_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (this.tabelaOcena.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    if (e.ColumnIndex - 3 > -1)
                    {
                        oceniButton.Enabled = false;
                        tabelaOcena.Hide();
                        ChooseBox.Hide();
                        oceniStudentaBox.Show();
                        StaraOcenaBox.Text = this.tabelaOcena.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                        imeStudentaLabel.Text = this.tabelaOcena.Rows[e.RowIndex].Cells[1].Value.ToString() 
                            + " " + this.tabelaOcena.Rows[e.RowIndex].Cells[2].Value.ToString();
                        brojIndeksa.Text = this.tabelaOcena.Rows[e.RowIndex].Cells[0].Value.ToString();
                        Kolona.Text = this.ImenaKolona[e.ColumnIndex - 3];
                        this.KolonaOcena = this.ImenaKolona[e.ColumnIndex - 3];
                        NovaOcenaBox.Clear();
                    }                        
                }
            }
        }
        private void IzmenaOceneButton_Click_1(object sender, EventArgs e)
        {
            string NovaOcena = NovaOcenaBox.Text;
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            if (NovaOcena != string.Empty)
            {
                double outDouble = tryParse(NovaOcena);
                if (outDouble != -1)
                {
                    Student studentOnUpdate = new Student(brojIndeksa.Text);
                    int idStudenta = student.getStudentID(studentOnUpdate);
                    if (idStudenta != 0)
                    {
                        KeyValuePair<int, double> ID_NovaOcena = new KeyValuePair<int, double>(idStudenta, outDouble); //make new pair: id and new grade
                        studenti_ocene2 = new List<KeyValuePair<int, double>>(); //reset this if not empty
                        studenti_ocene2.Add(ID_NovaOcena); //add it in list
                        bool update = student.GradeStudents(studenti_ocene2, this.ImeStrukture, this.KolonaOcena, this.idPredmeta);
                        if (update)
                        {
                            builder.Append("Uspesno ste ocenili studenta " + imeStudentaLabel.Text + ".");
                            fill();
                            oceniStudentaBox.Hide();
                            tabelaOcena.Show();
                            oceniButton.Enabled = true;
                            studenti_ocene2 = new List<KeyValuePair<int, double>>();
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                        builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                }
            }
            else
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        private void button1_Click(object sender, EventArgs e)
        {
            tabelaOcena.Hide();
            savePdfBox.Hide();
            pathBox.Clear();
            filenameBox.Clear();
            oceniButton.Enabled = false;
            var folderBrowserDialog1 = new FolderBrowserDialog();
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                folderName = string.Empty;
                folderName = folderBrowserDialog1.SelectedPath;
                ImeFajlaBox.Show();
                pathBox.Text = folderName;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            tabelaOcena.Hide();
            ImeFajlaBox.Hide();
            imeFajla2Box.Clear();
            path2Box.Clear();
            oceniButton.Enabled = false;
            var folderBrowserDialog1 = new FolderBrowserDialog();
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                folderName = string.Empty;
                folderName = folderBrowserDialog1.SelectedPath;
                savePdfBox.Show();
                path2Box.Text = folderName;
            }
        }
        private void acceptSaveButton_Click_1(object sender, EventArgs e)
        {
            if (filenameBox.Text != string.Empty)
            {
                Spire.DataExport.XLS.CellExport cellExport = new Spire.DataExport.XLS.CellExport();
                Spire.DataExport.XLS.WorkSheet worksheet1 = new Spire.DataExport.XLS.WorkSheet();
                worksheet1.DataSource = Spire.DataExport.Common.ExportSource.DataTable;
                worksheet1.DataTable = this.tabelaOcena.DataSource as DataTable;
                worksheet1.StartDataCol = ((System.Byte)(0));
                cellExport.Sheets.Add(worksheet1);
                cellExport.ActionAfterExport = Spire.DataExport.Common.ActionType.OpenView;
                string imeFajla = folderName + "\\" + filenameBox.Text + ".xls";
                cellExport.SaveToFile(imeFajla);
                ImeFajlaBox.Hide();
                tabelaOcena.Show();
                oceniButton.Enabled = true;
            }
            else
                MessageBox.Show("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (imeFajla2Box.Text != string.Empty)
            {
                Spire.DataExport.PDF.PDFExport PDFExport = new Spire.DataExport.PDF.PDFExport();
                PDFExport.DataSource = Spire.DataExport.Common.ExportSource.DataTable;
                PDFExport.DataTable = this.tabelaOcena.DataSource as DataTable;
                PDFExport.PDFOptions.PageOptions.MarginLeft = 0.5;
                PDFExport.PDFOptions.PageOptions.MarginRight = 0.5;
                PDFExport.PDFOptions.PageOptions.MarginTop = 1;
                PDFExport.PDFOptions.PageOptions.MarginBottom = 1;
                PDFExport.PDFOptions.PageOptions.Orientation = Spire.DataExport.Common.PageOrientation.Landscape;
                PDFExport.ActionAfterExport = Spire.DataExport.Common.ActionType.OpenView;
                string imeFajla = folderName + "\\" + imeFajla2Box.Text + ".pdf";
                PDFExport.SaveToFile(imeFajla);
                savePdfBox.Hide();
                tabelaOcena.Show();
                oceniButton.Enabled = true;
            }
            else
                MessageBox.Show("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
        }
    }
}