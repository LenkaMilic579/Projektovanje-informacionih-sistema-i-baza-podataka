﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AktivnostiStudenata_gui
{
    public partial class Form3_: Form
    {
        int id;
        int idUlogovanogKorisnika;
        User userOnLogin;
        public Form3_()
        {
            InitializeComponent();
            classAddBox.Hide();
            classDeleteBox.Hide();
            groupBox3.Hide();
            dataGridView1.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            dodajAsistentaBox.Hide();
            groupBox2.Hide();
            unregisterMeBox.Hide();
            id = Set.getUserid();
            userOnLogin = Set.getUser();
            if (Set.admin)
                this.takeMeBackButton.Show();
            else
                this.takeMeBackButton.Hide();
            this.welcomeLablel.Text += " "+userOnLogin.username;
            idUlogovanogKorisnika = Set.getUserid();
        }
        private void classAddButton_Click(object sender, EventArgs e)
        {
            classDeleteBox.Hide();
            groupBox3.Hide();
            imePredmetaBox.Clear();
            groupBox2.Hide();
            userNameBox.Clear();
            dodajAsistentaBox.Hide();
            currentPassword.Clear();
            newPassword1.Clear();
            newPassword2.Clear();
            textBox1.Clear();
            classAddBox.Show();
            dataGridView1.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            unregisterMeBox.Hide();
            imePredmetaBox2.Clear();
        }
        private void classDeleteButton_Click(object sender, EventArgs e)
        {
            classAddBox.Hide();
            groupBox3.Hide();
            groupBox2.Hide();
            userNameBox.Clear();
            imePredmetaBox.Clear();
            dodajAsistentaBox.Hide();
            currentPassword.Clear();
            newPassword2.Clear();
            newPassword1.Clear();
            textBox2.Clear();
            classDeleteBox.Show();
            dataGridView1.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            unregisterMeBox.Hide();
            imePredmetaBox2.Clear();
        }
        private void showClassButton_Click(object sender, EventArgs e)
        {
            dodajAsistentaBox.Hide();
            groupBox3.Hide();
            textBox3.Clear();
            userNameBox.Clear();
            imePredmetaBox.Clear();
            groupBox2.Hide();
            currentPassword.Clear();
            newPassword2.Clear();
            newPassword1.Clear();
            classDeleteBox.Hide();
            classAddBox.Hide();
            groupBox1.Show();
            changePasswordBox.Hide();
            unregisterMeBox.Hide();
            imePredmetaBox2.Clear();
            fill();
        }
        private void changePassword_Click(object sender, EventArgs e)
        {
            dodajAsistentaBox.Hide();
            userNameBox.Clear();
            imePredmetaBox.Clear();
            classAddBox.Hide();
            classDeleteBox.Hide();
            dataGridView1.Hide();
            groupBox1.Hide();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            unregisterMeBox.Hide();
            imePredmetaBox2.Clear();
            changePasswordBox.Show();
        }
        private void addAssistentButton_Click(object sender, EventArgs e)
        {
            classAddBox.Hide();
            groupBox3.Hide();
            classDeleteBox.Hide();
            dataGridView1.Hide();
            groupBox2.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            dodajAsistentaBox.Show();
            userNameBox.Clear();
            imePredmetaBox.Clear();
            unregisterMeBox.Hide();
            imePredmetaBox2.Clear();
            fill2(this.aplikacijaDataSet3.Predmet);
        }
        private void UnregisterButton_Click(object sender, EventArgs e)
        {
            classAddBox.Hide();
            classDeleteBox.Hide();
            groupBox3.Hide();
            groupBox2.Hide();
            dataGridView1.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            dodajAsistentaBox.Hide();
            imePredmetaBox2.Clear();
            unregisterMeBox.Show();
        }
        private void deleteAssistentButton_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            classAddBox.Hide();
            classDeleteBox.Hide();
            dataGridView1.Hide();
            groupBox1.Hide();
            changePasswordBox.Hide();
            dodajAsistentaBox.Hide();

            DialogResult result = MessageBox.Show("Da li zelite da obrisete sve asistente sa predmeta?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                groupBox2.Hide();
                groupBox3.Show();
                textBox5.Clear();
                fill2(this.aplikacijaDataSet6.Predmet);
            }
            else if (result == DialogResult.No)
            {
                groupBox3.Hide();
                groupBox2.Show();
                imeAsistenta2Box.Clear();
                imePredmeta2Box.Clear();
                fill2(this.aplikacijaDataSet5.Predmet);
            }            
        }
        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                this.textBox3.Text = row.Cells[0].Value.ToString();
            }
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                this.imePredmetaBox.Text = row.Cells[0].Value.ToString();
            }
        }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView3.Rows[e.RowIndex];
                this.imePredmeta2Box.Text = row.Cells[0].Value.ToString();
            }
        }
        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView4.Rows[e.RowIndex];
                this.textBox5.Text = row.Cells[0].Value.ToString();
            }
        }
        public void fill()
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            try
            {
                SqlCommand command = new SqlCommand("SELECT * FROM [Predmet] WHERE [idPredmeta] IN (SELECT [idPredmeta] FROM [Predaje] WHERE ([idProfesora] = @id))", instance.connection);
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@id", id);
                SqlDataAdapter adapter_this = new SqlDataAdapter(command);
                this.aplikacijaDataSet.Predmet.Clear();
                adapter_this.Fill(this.aplikacijaDataSet.Predmet);
                dataGridView1.Show();
                instance.Disconnect();
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: " + sqlException.Message);
                instance.Disconnect();
            }
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
        public void fill2(DataTable dt)
        {
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            instance.Connect();
            try
            {   
                SqlCommand command = new SqlCommand("SELECT * FROM [Predmet] WHERE [idPredmeta] IN (SELECT [idPredmeta] FROM [Predaje] WHERE ([idProfesora] = @id))", instance.connection);
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@id", id);

                SqlDataAdapter adapter_this = new SqlDataAdapter(command);

                dt.Clear();
                adapter_this.Fill(dt);
                dataGridView2.Show();
                instance.Disconnect();
            }
            catch (SqlException sqlException)
            {
                builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
                builder.Append("Sql Error: "+sqlException.Message);
                instance.Disconnect();
            }
            if(builder.Length>0)
                MessageBox.Show(builder.ToString());
        }
        private void sendButton_Click(object sender, EventArgs e)
        {
            string imePredmeta = this.textBox3.Text;
            Predmet predmet = new Predmet();
            if (imePredmeta != string.Empty)
            {
                Predmet predmetOnInsert = new Predmet(imePredmeta);
                if (predmet.classExist(predmetOnInsert))
                {
                    int idPredmeta = predmet.getClassID(predmetOnInsert);
                    //da li je autorizovano brisanje predmeta
                    if (predmet.isAuthorized(predmetOnInsert))
                    {
                        Predmet predmetOnShare = new Predmet(imePredmeta);
                        Form4 form = new Form4(predmetOnShare);
                        this.Hide();
                        form.Show();
                    }
                    else
                    {
                        this.textBox3.Clear();
                        MessageBox.Show("Pristup ovom predmetu je nedozvoljen.\n");
                    }
                }
                else
                {
                    MessageBox.Show("Izabrani predmet ne postoji.\nMolimo vas pokusajte ponovo.\n");
                    this.textBox3.Clear();
                }
            }
            else
                MessageBox.Show("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");
        }

        private void classAcceptButton_Click(object sender, EventArgs e)
        {
            string imepredmeta = textBox1.Text;
            bool checkInsert = false;
            bool checkUser = false;
            bool checkClassDelete = false;
            StringBuilder builder = new StringBuilder();
            if (imepredmeta != string.Empty)
            {
                Predmet predmetOnInsert = new Predmet(imepredmeta);
                Predmet predmet = new Predmet();
                User user = new User();
                Singleton instance = Singleton.getInstance();
                //get id of user on login
                int id = Set.getUserid();
                if (id != 0)
                {
                    String sqlQuery = "INSERT INTO Predmet(ime) VALUES ( '" + predmetOnInsert.ime + "' )";

                    if (!predmet.classExist(predmetOnInsert))
                    {
                        checkInsert = instance.Insert(sqlQuery);
                        textBox1.Clear();
                        classAddBox.Hide();
                        if (checkInsert)
                        {
                            builder.Append("Predmet " + predmetOnInsert.ime + " je uspesno sacuvan.\n");
                            int idPredmeta = predmet.getClassID(predmetOnInsert);
                            if (idPredmeta != 0)
                            {
                                String sqlQuery2 = "INSERT INTO Predaje(idProfesora, idPredmeta) VALUES ( '" + id + "','" + idPredmeta + "' )";
                                checkUser = instance.Insert(sqlQuery2);
                                if (checkUser)
                                {
                                    builder.Append("Profesor " + user.getUserName(id) + " predaje predmet " + predmetOnInsert.ime + ".\n");
                                    classAddBox.Hide();
                                }
                                else
                                {
                                    builder.Append("Doslo je do greske prilikom prijavljivanja profesora " + user.getUserName(id) + " na predmet " + predmetOnInsert.ime + ".\n");
                                    //obrisi predmet jet nisi uspeo da prijavis profesora
                                    String sqlQuery3 = "DELETE Predmet WHERE ime = '" + predmetOnInsert.ime + "'";
                                    checkClassDelete = instance.Delete(sqlQuery3);
                                    if (checkClassDelete)
                                        builder.Append("Predmet " + predmetOnInsert.ime + " je obrisan.\n");
                                    else
                                    {
                                        builder.Append("Predmet " + predmetOnInsert.ime + " nije obrisan.\nMolimo vas obrisite predmet u bazi podataka\n");
                                        builder.Append("SQL upit koji treba izvrsiti rucno:\n ");
                                        builder.Append("DELETE Predmet WHERE ime = '" + predmetOnInsert.ime + "'");
                                    }
                                    classAddBox.Hide();
                                }
                            }
                        }
                        else
                        {
                            textBox1.Clear();
                            builder.Append("Doslo je do greske prilikom cuvanja predmeta '" + predmetOnInsert.ime + "'.\nMolimo vas pokusajte ponovo.\n");
                        }
                    }
                    else
                    {
                        builder.Append("Predmet '" + predmetOnInsert.ime + "' vec postoji.\nMolimo vas pokusajte ponovo.\n");
                        textBox1.Clear();
                    }
                }
                else
                    builder.Append("Neuspesno preuzimanje id Profesora.\nMolimo vas pokusajte ponovo.\n");
            }
            else
            {
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");
                textBox1.Clear();
            }
           if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }

        private void classAcceptButton2_Click(object sender, EventArgs e)
        {
            string imepredmeta = textBox2.Text;
            bool isAutorized = false;
            bool checkSlusaDelete = false;
            bool checkStukturaDelete = false;
            bool checkPredajeDelete = false;
            bool checkIDpredmeta = false;
            bool checkStudentDelete = false;
            bool checkPredmetDelete = false;
            bool structureexist = false;
            bool studentsexist = false;
            bool unregisteredStudentsInStructure = false;
            bool tableDropt = false;
            string imeStrukture = "";
            List<string> columnNames = new List<string>();
            
            int count = 0;
            var idStr = 0;
            Singleton instance = Singleton.getInstance();
            Predmet predmet = new Predmet();
            User user = new User();
            Student student = new Student();
            StringBuilder builder = new StringBuilder();
            //Proveri da li asistent pokusava da obrise predmet, ako ne nemoj da dozvolis
            if (imepredmeta != string.Empty)
            {
                Predmet predmetOnDelete = new Predmet(imepredmeta);
                //da li predmet postoji
                if (predmet.classExist(predmetOnDelete)) //ako postoji
                {
                    int idPredmeta = predmet.getClassID(predmetOnDelete);
                    //da li je autorizovano brisanje predmeta
                    if (predmet.isAuthorized(predmetOnDelete))
                    {
                        isAutorized = true;
                        if (idPredmeta != 0)
                        {
                            checkIDpredmeta = true;
                            List<int> idProfesoraNaPredmetu = new List<int>();
                            idProfesoraNaPredmetu = user.getOtherUsers2(idPredmeta);
                            if (idProfesoraNaPredmetu.Count != 0)
                            {
                                if (idProfesoraNaPredmetu[0] != idUlogovanogKorisnika)
                                {
                                    isAutorized = false;
                                    builder.Append("Nemate pravo da obrisete ovaj predmet.\n");
                                }
                                else
                                {
                                    //odjavi profesora sa predmeta - 'Predaje'
                                    string sqlQuery2 = "DELETE Predaje WHERE idPredmeta = " + idPredmeta;
                                    checkPredajeDelete = instance.Delete(sqlQuery2);
                                    if (checkPredajeDelete)
                                        builder.Append("Profesor " + userOnLogin.username + " i asistenti vise ne predaju predmet " + predmetOnDelete.ime + " .\n");
                                    else
                                        builder.Append("Odjavljivanje profesora " + userOnLogin.username + "  i asistenata sa predmeta " + predmetOnDelete.ime + " je proslo neuspesno.\n");
                                }
                            }                            
                        }
                        else
                        {
                            builder.Append("Neuspesno preuzimanje id predmeta koga zelite obrisati.\n");
                            checkIDpredmeta = false;
                        }
                    }
                    else
                    {
                        isAutorized = false;
                        builder.Append("Izvrsili ste nedozvoljno brisanje predmeta " + predmetOnDelete.ime + ".\nMolimo vas izaberite drugi predmet.\n");
                        textBox2.Clear();
                    }
                    if (isAutorized && checkIDpredmeta && checkPredajeDelete)
                    {
                        var IDsStudenta = new List<int>();
                        //sada proveri da li postoji jos neki profesor koji predaje ovaj predmet
                        //ako ne postoji odjavi studente sa predmeta, obrisi studenta ako ne slusa vise nijedan predmet i obrisi predmet
                        //preuzmi idStrukture na ovom predmetu
                        idStr = predmet.getClass_StuctureId(idPredmeta);
                        //take all ids of reported students from this class.
                        IDsStudenta = predmet.getAllClassStudentsIDs(idPredmeta);
                        if (idStr != 0)
                        {
                            structureexist = true;
                            //preuzmi ime strukture ovog predmeta
                            imeStrukture = predmet.getStructureName(idStr);
                            if (imeStrukture != string.Empty)
                            {
                                //odjavi studente iz strukture
                                string sqlQuery8 = "DELETE " + imeStrukture + " WHERE idPredmeta = " + idPredmeta;
                                checkStukturaDelete = instance.Delete(sqlQuery8);
                                if (!checkStukturaDelete) //ispitaj da li su studenti uopste prijavljeni u strukturu
                                {
                                    Int32 exist = student.StudentsRegistredInStructure(idPredmeta, imeStrukture);
                                    if (exist == 0)
                                        unregisteredStudentsInStructure = true;
                                    else
                                        unregisteredStudentsInStructure = false;
                                }
                            }
                            else
                                builder.Append("Neuspesno preuzimanje imena strukture.\n Molimo vas pokusajte ponovo\n");
                        }
                        else
                        {
                            builder.Append("Predmet nema definisanu strukturu\n");
                            structureexist = false;
                        }
                        //odjavi studente sa predmeta
                        //check if this class has any students
                        if (IDsStudenta.Count != 0) //ako postoje studenti koji slusaju ovaj predmet
                        {
                            studentsexist = true;
                            //Odjavi studente koji slusaju ovaj predmet
                            string sqlQuery4 = "DELETE Slusa WHERE idPredmeta = " + idPredmeta;
                            checkSlusaDelete = instance.Delete(sqlQuery4);
                            if (checkSlusaDelete)
                            {
                                builder.Append("Studenti na predmetu " + predmetOnDelete.ime + " su uspesno odjavljeni.\n");

                                if (checkStukturaDelete || !structureexist || unregisteredStudentsInStructure)
                                {
                                    //proveri da li postoji student koji ne slusa nijedan predmet. Ako postoji obrisi ga.
                                    foreach (int idStudenta in IDsStudenta)
                                    {
                                        KeyValuePair<string, string> imePrezime = student.getStudentNameAndSurname(idStudenta);
                                        string sqlQuery5 = "SELECT COUNT(*) AS IsExists FROM Slusa WHERE ([idStudenta] = @id)";
                                        if (instance.HasElements(idStudenta, sqlQuery5) == 0) //ne postoji- obrisi ga
                                        {
                                            string sqlQuery6 = "DELETE Student WHERE idStudenta = '" + idStudenta + "'";
                                            checkStudentDelete = instance.Delete(sqlQuery6);
                                            if (checkStudentDelete)
                                            {
                                                count += 1;
                                                builder.Append("Student " + imePrezime.Key + " " + imePrezime.Value + " je obrisan jer ne slusa vise nijedan predmet.\n");
                                            }
                                            else
                                                builder.Append("Brisanje studenta " + imePrezime.Key + " " + imePrezime.Value + " koji ne slusa vise nijedan predmet je neuspesno. \n");
                                        }
                                        else //postoji- ne brisi ga
                                            builder.Append("Student " + imePrezime.Key + " " + imePrezime.Value + " nije obrisan jer slusa jos predmeta.\n");
                                    }
                                    if (IDsStudenta.Count() == count)
                                        checkStudentDelete = true;
                                    else
                                        checkStudentDelete = false;
                                }
                                else
                                    builder.Append("Studenti na predmetu " + predmet.getClassName(idPredmeta) + " nisu odjavljeni iz strukture ili nisu bili pridruzeni strukturi\n");
                            }
                            else
                                builder.Append("Studenti na predmetu " + predmetOnDelete.ime + " nisu uspesno odjavljeni.\n");
                        }
                        else
                        {
                            studentsexist = false;
                            builder.Append("Predmet " + predmetOnDelete.ime + " nije imao prijavljene studente.\n");
                        }

                        if (checkSlusaDelete || !studentsexist)
                        {
                            if (checkPredmetDelete = predmet.DeletePredmet(idPredmeta)) //obrisi predmet
                            {
                                builder.Append("Predmet " + predmetOnDelete.ime + " je obrisan.\n");
                                classDeleteBox.Hide();
                                //Obrisi stukturu ovog predmeta ukoliko je nijedan predmet vise ne koristi.
                                if (idStr != 0)
                                {
                                    if (!predmet.ReturnStructureIdExistOnClass(idStr)) // ako ne postoji vise predmet koji ima ovu strukturu
                                    {
                                        //takodje Obrisi strukturu jer je niko ne koristi
                                        if (instance.Delete("DELETE FROM ListaStruktura WHERE idStrukture = '" + idStr + "'")) //ako je obrisan red u Listi za ovu strukturu
                                        {
                                            //obrisi kolone koje nijedna struktura ne koristi
                                            columnNames = instance.TakeColumnNames("ListaStruktura");
                                            if (columnNames != new List<string>()) // ako smo preuzeli imena kolona iz ListeStruktura
                                            {
                                                foreach (string columnname in columnNames)
                                                {
                                                    Int32 exist = instance.NullValuesInColumn("ListaStruktura", columnname);
                                                    if (exist == 0) //ako nijedna struktura ne koristi ovu kolonu
                                                    {
                                                        instance.AlterTableDropColumn("ListaStruktura", columnname);
                                                    }
                                                }
                                            }
                                            else
                                                builder.Append("Nemoguce preuzeti imena kolona iz ListeStruktura\n");
                                        }
                                        else
                                            builder.Append("Struktura je neuspesno obrisana.\n");
                                        if (tableDropt = instance.DropTable(imeStrukture))
                                            builder.Append("Struktura " + imeStrukture + " je obrisana jer je nijedan predmet nije koristio\n");
                                        else
                                            builder.Append("Struktura " + imeStrukture + " je neuspesno obrisana.\n");
                                    }
                                    else
                                        builder.Append("Strukturu koji ovaj predmet koristi koriste i drugi predmeti. Struktura nije obrisana.\n");
                                }
                                else
                                    builder.Append("Predmet nema definisanu strukturu\n");
                            }
                            else
                                builder.Append("Brisanje predmeta " + predmetOnDelete.ime + " je proslo neuspesno.\n");
                        }

                    }
                }
                else
                    builder.Append("Izabrani predmet " + predmetOnDelete.ime + " ne postoji");
                textBox2.Clear();
            }
            else
            {
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");
                textBox2.Clear();
            }
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }

        private void logOutButton_Click(object sender, EventArgs e)
        {
            Singleton instance = Singleton.getInstance();
            Form3_ form = this;
            instance.logOut(form);
        }
        private void takeMeBackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form = new Form2();
            form.Show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            User user = new User();
            string trenutnaSifra = currentPassword.Text;
            string novaSifra1 = newPassword1.Text;
            string novaSifra2 = newPassword2.Text;
            if (trenutnaSifra != string.Empty && novaSifra1 != string.Empty && novaSifra2 != string.Empty)
            {
                string SifraBase = user.getUserPassword(id);
                if (SifraBase != string.Empty)
                {
                    if (SifraBase == trenutnaSifra)
                    {
                        if (novaSifra1 == novaSifra2)
                        {
                            //update-uj sifru u tabeli Profesor
                            if (user.changeUserPassword(novaSifra1, id))
                            {
                                builder.Append("Uspesno ste promenili sifru.\n");
                                currentPassword.Clear();
                                newPassword1.Clear();
                                newPassword2.Clear();
                                changePasswordBox.Hide();
                            }
                            else
                                builder.Append("Sifra nije uspesno promenjena.\nMolimo vas pokusajte ponovo.\n");
                        }
                        else
                        {
                            builder.Append("Nove sifre se ne poklapaju.\nMolimo vas pokusajte ponovo.\n");
                            newPassword1.Clear();
                            newPassword2.Clear();
                        }
                    }
                    else
                    {
                        builder.Append("Sifra koju ste uneli je pogresna.\nMolimo vas pokusajte ponovo.\n");
                        currentPassword.Clear();
                        newPassword1.Clear();
                        newPassword2.Clear();
                    }                        
                }
                else
                    builder.Append("Doslo je do greske pri ocitavanju baze.\nMolimo vas pokusajte ponovo.\n");
            }
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
            if(builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }

        private void acceptAssistentButton_Click(object sender, EventArgs e)
        {
            string username = this.userNameBox.Text;
            string imePredmeta = this.imePredmetaBox.Text;
            User user = new User();
            User userOnAdd = new User(username);
            Predmet predmet = new Predmet();
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            if (imePredmeta != string.Empty && username != string.Empty)
            {
                Predmet predmetOnUpdate = new Predmet(imePredmeta);
                if (user.userExist2(userOnAdd))
                {
                    int idUsera = user.getuserID(userOnAdd.username);
                    if (idUsera != 0)
                    {
                        int idPredmeta = predmet.getClassID(predmetOnUpdate);
                        if (idPredmeta != 0)
                        {
                            List<int> idProfesoraNaPredmetu = new List<int>();
                            idProfesoraNaPredmetu = user.getOtherUsers2(idPredmeta);
                            if (idProfesoraNaPredmetu.Count != 0)
                            {
                                if (idProfesoraNaPredmetu[0] != idUlogovanogKorisnika)
                                    builder.Append("Nemate pravo da dodajete asistente na ovom predmetu.\n");                                
                                else
                                {
                                    //prvo ispitaj da li je profesor vec prijavio ovog asistenta
                                    string sqlQuery1 = "SELECT COUNT(*) FROM Predaje WHERE ([idProfesora] = @id) AND idPredmeta=" + idPredmeta + "";
                                    if (instance.HasElements(idUsera, sqlQuery1) == 0) //ako nije prijavio asistenta
                                    {
                                        //insertuj idPredmeta i idKorisnika u tabelu Predaje.
                                        string sqlQuery2 = "INSERT INTO [dbo].[Predaje] ([idProfesora],[idPredmeta]) VALUES (" + idUsera + ", " + idPredmeta + ")";
                                        bool checkInsert = instance.Insert(sqlQuery2);
                                        if (checkInsert)
                                        {
                                            builder.Append("Uspesno se prijavili korisnika " + username + " na predmet " + imePredmeta + ".\n");
                                            userNameBox.Clear();
                                            imePredmetaBox.Clear();
                                            dodajAsistentaBox.Hide();
                                        }
                                        else
                                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                                    }
                                    else
                                        builder.Append("Korisnik " + username + " je vec prijavljen da predaje predmet " + imePredmeta + ".\n");
                                }
                            }
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                        builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                }
                else
                    builder.Append("Izabrani korisnik ne postoji.\n");
            }
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
            MessageBox.Show(builder.ToString());
        }
        private void unregisterButton2_Click(object sender, EventArgs e)
        {
            string imepredmeta = imePredmetaBox2.Text;
            Predmet predmet = new Predmet();
            Singleton instance = Singleton.getInstance();
            StringBuilder builder = new StringBuilder();
            User user = new User();
            bool isAutorized = false;
            bool checkIDpredmeta = false;
            bool checkPredajeDelete = false;
            if (imepredmeta != string.Empty)
            {
                Predmet predmetOnDelete = new Predmet(imepredmeta);
                //da li predmet postoji
                if (predmet.classExist(predmetOnDelete)) //ako postoji
                {
                    int idPredmeta = predmet.getClassID(predmetOnDelete);
                    int idProfesora = Set.getUserid();
                    if (predmet.isAuthorized(predmetOnDelete)) //da li profesor predaje ovaj predmet
                    {
                        isAutorized = true;
                        if (idPredmeta != 0) //ako je uspesno preuzet idPredmeta iz baze
                        {
                            checkIDpredmeta = true;
                            string sqlQuery1 = "SELECT COUNT(*) FROM Predaje WHERE ([idPredmeta] = @id)";
                            if (instance.HasElements(idPredmeta, sqlQuery1) > 1)    //ako profesor nije jedini na predmetu dozvoli mu da se odjavi.
                            {
                                string sqlQuery2 = "DELETE Predaje WHERE idPredmeta = '" + idPredmeta + "' AND idProfesora = '" + idProfesora + "'";
                                checkPredajeDelete = instance.Delete(sqlQuery2); //odjavi profesora sa predmeta - 'Predaje'

                                if (checkPredajeDelete)
                                {
                                    imePredmetaBox2.Clear();
                                    unregisterMeBox.Hide();
                                    builder.Append("Vise ne predajete predmet " + predmetOnDelete.ime + ".\n");
                                    List<string> ProfesoriNaPredmetu = new List<string>();
                                    ProfesoriNaPredmetu = user.getOtherUsers(idPredmeta);
                                    if (ProfesoriNaPredmetu.Count != 0)
                                        builder.Append("Asistent koji je dobio pravo na upravljanje predmetom je " + ProfesoriNaPredmetu[0]);
                                }
                                else
                                    builder.Append("Odjavljivanje sa predmeta " + predmetOnDelete.ime + " je proslo neuspesno.\nMolimo vas pokusajte ponovo.\n");
                            }
                            else
                                builder.Append("Vi ste jedini profesor koji predaje ovaj predmet.\n" +
                                    "Obrisite predmet i aplikacija ce za Vas izvrsiti vasu odjavu sa ovog predmeta.\n");
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                    {
                        builder.Append("Vi ne predajete predmet " + predmetOnDelete.ime + ".\nMolimo vas izaberite drugi predmet.\n");
                        imePredmetaBox2.Clear();
                    }
                }
                else
                {
                    builder.Append("Trazeni predmet "+imepredmeta+" ne postoji.\nMolimo vas pokusajte ponovo.\n");
                    imePredmetaBox2.Clear();
                }
            }
            else
                builder.Append("Polje mora biti popunjeno.\nMolimo vas pokusajte ponovo.\n");
            MessageBox.Show(builder.ToString());
        }
        private void OdjaviAsistentaButton_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            User user = new User();
            Predmet predmet = new Predmet();
            bool predmetOnDelete1 = false;
            bool isAutorized = false;
            bool checkIDpredmeta = false;
            bool checkPredajeDelete = false;
            if (imeAsistenta2Box.Text != string.Empty && imePredmeta2Box.Text != string.Empty)
            {
                Predmet predmetOnDelete = new Predmet(imePredmeta2Box.Text);
                //da li predmet postoji
                if (predmet.classExist(predmetOnDelete)) //ako postoji
                {
                    int idPredmeta = predmet.getClassID(predmetOnDelete);
                    bool userExist = user.userExist2(new User(imeAsistenta2Box.Text));
                    if (userExist)
                    {
                        int idUsera = user.getuserID(imeAsistenta2Box.Text);
                        if (idUsera != 0 && idPredmeta != 0)
                        {
                            List<int> idProfesoraNaPredmetu = new List<int>();
                            idProfesoraNaPredmetu = user.getOtherUsers2(idPredmeta);
                            if (idProfesoraNaPredmetu.Count != 0)
                            {
                                if (idProfesoraNaPredmetu[0] != idUlogovanogKorisnika)
                                    builder.Append("Nemate pravo da odjavite asistenta na ovom predmetu.\n");
                                else
                                {
                                    if (predmet.isAuthorized2(idPredmeta, idUsera)) //da li profesor predaje ovaj predmet
                                    {
                                        isAutorized = true;
                                        checkIDpredmeta = true;
                                        string sqlQuery1 = "SELECT COUNT(*) FROM Predaje WHERE ([idPredmeta] = @id)";
                                        if (instance.HasElements(idPredmeta, sqlQuery1) > 1)    //ako profesor nije jedini na predmetu dozvoli mu da se odjavi.
                                        {
                                            string sqlQuery2 = "DELETE Predaje WHERE idPredmeta = '" + idPredmeta + "' AND idProfesora = '" + idUsera + "'";
                                            checkPredajeDelete = instance.Delete(sqlQuery2); //odjavi profesora sa predmeta - 'Predaje'
                                            if (checkPredajeDelete)
                                            {
                                                imePredmetaBox2.Clear();
                                                unregisterMeBox.Hide();
                                                builder.Append("Korisnik " + imeAsistenta2Box.Text + " vise ne predaje predmet " + predmetOnDelete.ime + ".\n");
                                                imeAsistenta2Box.Clear();
                                                imePredmeta2Box.Clear();
                                                groupBox2.Hide();

                                            }
                                            else
                                                builder.Append("Odjavljivanje korisnika " + imeAsistenta2Box.Text + "sa predmeta " + predmetOnDelete.ime + " je proslo neuspesno.\nMolimo vas pokusajte ponovo.\n");
                                        }
                                        else
                                            builder.Append("Vi ste jedini profesor koji predaje ovaj predmet.\n" +
                                                "Obrisite predmet i aplikacija ce za vas izvrsiti vasu odjavu sa ovog predmeta.\n");
                                    }
                                    else
                                    {
                                        builder.Append("Izabrani korisnik ne predaje predmet " + predmetOnDelete.ime + ".\nMolimo vas izaberite drugi predmet.\n");
                                        imePredmetaBox2.Clear();
                                    }
                                }
                            }
                            else
                                builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                        builder.Append("Izabrani korisnik ne postoji.\nMolimo vas pokusajte ponovo.\n");
                }
                else
                {
                    builder.Append("Trazeni predmet " + imePredmeta2Box.Text + " ne postoji.\nMolimo vas pokusajte ponovo.\n");
                    imePredmetaBox2.Clear();
                }
            }
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string imePredmeta = this.textBox5.Text;
            Predmet predmet = new Predmet();
            User user = new User();
            StringBuilder builder = new StringBuilder();
            Singleton instance = Singleton.getInstance();
            if (imePredmeta != string.Empty)
            {
                Predmet predmetOnDelete = new Predmet(imePredmeta);
                //da li predmet postoji
                if (predmet.classExist(predmetOnDelete)) //ako postoji
                {
                    int idPredmeta = predmet.getClassID(predmetOnDelete);
                    if (idPredmeta != 0)
                    {
                        List<int> idProfesoraNaPredmetu = new List<int>();
                        idProfesoraNaPredmetu = user.getOtherUsers2(idPredmeta);
                        if (idProfesoraNaPredmetu.Count != 0)
                        {
                            if (idProfesoraNaPredmetu[0] == this.idUlogovanogKorisnika) //ako je ovo glavni korisnik na predmetu dozvoli
                            {
                                string sqlQuery2 = "DELETE Predaje WHERE idPredmeta = " + idPredmeta + " AND idProfesora != " + idUlogovanogKorisnika;
                                if (instance.Delete(sqlQuery2))
                                {
                                    builder.Append("Odjavili ste sve asistente sa predmeta\n");
                                    groupBox3.Hide();
                                }
                                else
                                    builder.Append("Odjavljivanje asistenata sa predmeta je proslo neuspesno\n");
                            }
                            else
                                builder.Append("Nemate pravo da odjavite asistente na ovom predmetu.\n");
                        }
                        else
                            builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");
                    }
                    else
                        builder.Append("Doslo je do greske.\nMolimo vas pokusajte ponovo.\n");

                }
                else
                    builder.Append("Izabrani predmet ne postoji");
            }  
            else
                builder.Append("Sva polja moraju biti popunjena.\nMolimo vas pokusajte ponovo.\n");
            if (builder.Length > 0)
                MessageBox.Show(builder.ToString());
        }
    }
}
